// NashmiOps Enterprise (MVP Edition) - Resilient Disk Persistence Engine
// Persists appointments, patients, waitlist, invoices, and conversation states across server restarts & browser refreshes

import fs from 'fs';
import path from 'path';

const DATA_DIR = path.join(process.cwd(), 'data');
const PERSISTENCE_FILE = path.join(DATA_DIR, 'nashmi_db.json');

export interface PersistentSnapshot {
  clinics?: any[];
  patients?: any[];
  appointments?: any[];
  waitlist?: any[];
  invoices?: any[];
  clinic_faqs?: any[];
  conversations?: any[];
  processed_messages?: any[];
  failed_outbound_messages?: any[];
}

export function loadPersistentData(): PersistentSnapshot | null {
  try {
    if (!fs.existsSync(DATA_DIR)) {
      fs.mkdirSync(DATA_DIR, { recursive: true });
    }
    if (fs.existsSync(PERSISTENCE_FILE)) {
      const raw = fs.readFileSync(PERSISTENCE_FILE, 'utf-8');
      const parsed = JSON.parse(raw);
      console.log(
        `[DiskStore] Loaded snapshot from disk: ${parsed.appointments?.length || 0} appts, ${
          parsed.conversations?.length || 0
        } convs`
      );
      return parsed;
    }
  } catch (err) {
    console.warn('[DiskStore] Error reading persistent data:', err);
  }
  return null;
}

export function savePersistentData(data: PersistentSnapshot): void {
  try {
    if (!fs.existsSync(DATA_DIR)) {
      fs.mkdirSync(DATA_DIR, { recursive: true });
    }
    fs.writeFileSync(PERSISTENCE_FILE, JSON.stringify(data, null, 2), 'utf-8');
  } catch (err) {
    console.warn('[DiskStore] Error writing persistent data:', err);
  }
}
