// NashmiOps Enterprise (MVP Edition) - Dynamic Calendar Scheduler & Family Profiles

import { google } from 'googleapis';
import { Appointment, ServiceType } from '@/types';
import { CLINIC_CONFIG, CLINICAL_SERVICES } from '@/lib/config/constants';
import {
  tenantStore,
  createAppointment,
  findOrCreatePatient,
  recordPdplConsent,
  supabase,
} from '@/lib/db/supabase';

let googleCalendarClient: any = null;

function getCalendarClient() {
  if (googleCalendarClient) return googleCalendarClient;

  try {
    const credsRaw = process.env.GOOGLE_APPLICATION_CREDENTIALS_JSON;
    if (!credsRaw) {
      console.warn('[Calendar] GOOGLE_APPLICATION_CREDENTIALS_JSON missing, operating in simulated mode.');
      return null;
    }

    const creds = JSON.parse(credsRaw);
    const auth = new google.auth.JWT({
      email: creds.client_email,
      key: creds.private_key,
      scopes: ['https://www.googleapis.com/auth/calendar'],
    });

    googleCalendarClient = google.calendar({ version: 'v3', auth });
    return googleCalendarClient;
  } catch (err) {
    console.warn('[Calendar] Failed to initialize Google Calendar client:', err);
    return null;
  }
}

export interface BookAppointmentInput {
  clinicId?: string;
  phone: string;
  patientName: string;
  serviceType: ServiceType;
  dateStr: string; // YYYY-MM-DD
  timeStr: string; // HH:mm (e.g. 11:00, 16:30)
  familyRelation?: 'self' | 'child' | 'spouse' | 'parent';
  nationalId?: string;
  notes?: string;
  isEmergency?: boolean;
}

export interface SchedulingResult {
  success: boolean;
  appointment?: Appointment;
  googleCalendarEventId?: string;
  message: string;
  conflictDetails?: string;
}

/**
 * Validate appointment against clinic working hours and Friday closure
 */
export function validateClinicWorkingHours(
  startTime: Date,
  endTimeWithBuffer: Date
): { valid: boolean; reason?: string } {
  const day = startTime.getDay(); // 0 = Sunday, 5 = Friday, 6 = Saturday

  // Friday is weekly holiday
  if (day === 5 || !CLINIC_CONFIG.workingHours.days.includes(day)) {
    return {
      valid: false,
      reason: 'يوم الجمعة عطلة أسبوعية رسمية في مركز نشمي لطب وجراحة الأسنان. دوامنا من السبت إلى الخميس. نقترح عليك حجز الموعد يوم السبت أو الأحد القادم من الساعة 09:00 صباحاً حتى 08:00 مساءً. هل يناسبك يوم السبت أو الأحد؟ 🦷',
    };
  }

  const [startH, startM] = CLINIC_CONFIG.workingHours.start.split(':').map(Number);
  const [endH, endM] = CLINIC_CONFIG.workingHours.end.split(':').map(Number);

  const startMinutes = startTime.getHours() * 60 + startTime.getMinutes();
  const endMinutes = endTimeWithBuffer.getHours() * 60 + endTimeWithBuffer.getMinutes();

  const openMinutes = startH * 60 + startM;  // 09:00 -> 540
  const closeMinutes = endH * 60 + endM;    // 20:00 -> 1200

  if (startMinutes < openMinutes) {
    return {
      valid: false,
      reason: `الوقت المطلوب قبل بدء ساعات العمل الرسمية (نفتح من الساعة ${CLINIC_CONFIG.workingHours.start} صباحاً إلى ${CLINIC_CONFIG.workingHours.end} مساءً). بإمكانك الحجز في أقرب موعد متاح الساعة 09:30 أو 10:00 صباحاً. هل يناسبك ذلك؟ 🦷`,
    };
  }

  if (endMinutes > closeMinutes || startMinutes >= closeMinutes) {
    return {
      valid: false,
      reason: `الوقت المطلوب وفترة التعقيم يتجاوزان وقت إغلاق العيادة (نستقبل المرضى حتى الساعة ${CLINIC_CONFIG.workingHours.end} مساءً). نقترح عليك موعداً في نفس اليوم الساعة 18:30 أو 19:00 مساءً أو في صباح اليوم التالي. هل يناسبك ذلك؟ 🦷`,
    };
  }

  return { valid: true };
}

/**
 * Check slot availability including mandatory 15-minute sterilization buffer and working hours
 * Queries Supabase directly as the Single Source of Truth
 */
export async function checkSlotAvailability(
  clinicId: string,
  startTime: Date,
  endTimeWithBuffer: Date
): Promise<{ available: boolean; conflictReason?: string }> {
  // 1. Working Hours & Friday Closure Guard
  const hoursCheck = validateClinicWorkingHours(startTime, endTimeWithBuffer);
  if (!hoursCheck.valid) {
    return {
      available: false,
      conflictReason: hoursCheck.reason,
    };
  }

  const reqStart = startTime.getTime();
  const reqEnd = endTimeWithBuffer.getTime();

  // Query Supabase directly (Single Source of Truth)
  let activeAppointments: Appointment[] = [];
  try {
    const { data, error } = await supabase
      .from('appointments')
      .select('*')
      .eq('clinic_id', clinicId)
      .neq('status', 'CANCELLED');

    if (!error && Array.isArray(data) && data.length > 0) {
      activeAppointments = data as Appointment[];
    } else {
      // Graceful offline fallback
      activeAppointments = tenantStore.appointments.filter(
        (appt) => appt.clinic_id === clinicId && appt.status !== 'CANCELLED'
      );
    }
  } catch {
    activeAppointments = tenantStore.appointments.filter(
      (appt) => appt.clinic_id === clinicId && appt.status !== 'CANCELLED'
    );
  }

  const conflict = activeAppointments.find((appt) => {
    if (appt.clinic_id !== clinicId) return false;
    if (appt.status === 'CANCELLED') return false;

    const existingStart = new Date(appt.start_time).getTime();
    // Compare against the full sterilization buffer time
    const existingEnd = new Date(appt.sterilization_end_time || appt.end_time).getTime();

    // Overlap condition
    return reqStart < existingEnd && reqEnd > existingStart;
  });

  if (conflict) {
    const conflictDate = new Date(conflict.sterilization_end_time || conflict.end_time);
    return {
      available: false,
      conflictReason: `الموعد يتعارض مع موعد محجوز مسبقاً (شاملاً فترة التعقيم الإلزامية 15 دقيقة) حتى الساعة ${conflictDate.toLocaleTimeString('ar-JO', { hour: '2-digit', minute: '2-digit' })}.`,
    };
  }

  return { available: true };
}

/**
 * Frictionless Booking:
 * - Zero upfront deposit
 * - Adds 15-min sterilization buffer
 * - Saves distinct patient record under WhatsApp number (Family Profiles)
 * - Pushes to Google Calendar via Service Account
 */
export async function bookFrictionlessAppointment(
  input: BookAppointmentInput
): Promise<SchedulingResult> {
  const clinicId = input.clinicId || CLINIC_CONFIG.id;
  const service = CLINICAL_SERVICES[input.serviceType] || CLINICAL_SERVICES.consultation;

  // 1. Calculate Timestamps
  const [hours, minutes] = input.timeStr.split(':').map(Number);
  const startDate = new Date(input.dateStr);
  startDate.setHours(hours, minutes, 0, 0);

  const durationMs = service.durationMinutes * 60 * 1000;
  const sterilizationBufferMs = CLINIC_CONFIG.sterilizationBufferMinutes * 60 * 1000;

  const endDate = new Date(startDate.getTime() + durationMs);
  const sterilizationEndDate = new Date(endDate.getTime() + sterilizationBufferMs);

  // 2. Conflict Check
  const check = await checkSlotAvailability(clinicId, startDate, sterilizationEndDate);
  if (!check.available) {
    return {
      success: false,
      message: check.conflictReason || 'الوقت المطلوب غير متوفر حالياً.',
      conflictDetails: check.conflictReason,
    };
  }

  // 3. Family Profile Handling: Find or Create distinct patient record
  const { patient } = await findOrCreatePatient({
    clinicId,
    phone: input.phone,
    fullName: input.patientName,
    nationalId: input.nationalId,
    familyRelation: input.familyRelation || 'self',
    primaryContactPhone: input.phone,
  });

  // Ensure PDPL consent is recorded as patient is actively booking
  await recordPdplConsent(patient.id, clinicId, true);

  // 4. Push to Google Calendar (Service Account)
  let googleCalendarEventId: string | undefined;
  const calendar = getCalendarClient();
  const calendarId = process.env.GOOGLE_CALENDAR_ID || 'primary';

  if (calendar) {
    try {
      const summaryText = `[نشمي أوبس] ${service.nameAr} - ${input.patientName}`;
      const descriptionText = `حجز موعد عيادة نشمي (NashmiOps Enterprise MVP)
المريض: ${input.patientName} (${input.familyRelation === 'self' ? 'صاحب الرقم' : `أحد أفراد العائلة: ${input.familyRelation}`})
رقم الهاتف: ${input.phone}
الخدمة: ${service.nameAr} (${service.durationMinutes} دقيقة)
فترة التعقيم الإلزامية: 15 دقيقة إضافية
الحالة: مؤكد 100%`;

      const insertPromise = calendar.events.insert({
        calendarId,
        requestBody: {
          summary: summaryText,
          description: descriptionText,
          start: {
            dateTime: startDate.toISOString(),
            timeZone: CLINIC_CONFIG.timezone,
          },
          end: {
            dateTime: sterilizationEndDate.toISOString(), // Reserve the slot including sterilization buffer
            timeZone: CLINIC_CONFIG.timezone,
          },
          location: CLINIC_CONFIG.address,
        },
      });

      const timeoutPromise = new Promise((_, reject) =>
        setTimeout(() => reject(new Error('Google Calendar insertion timed out')), 3500)
      );

      const response: any = await Promise.race([insertPromise, timeoutPromise]);
      googleCalendarEventId = response?.data?.id || undefined;
      console.log(`[Google Calendar] Successfully created event ID: ${googleCalendarEventId}`);
    } catch (err) {
      console.warn('[Google Calendar] Could not push to remote calendar, stored in resilient tenant store:', err);
    }
  }

  // 5. Create Appointment in Supabase / Tenant Store (Atomic Double-Booking Guard)
  try {
    const appointment = await createAppointment({
      clinicId,
      patientId: patient.id,
      patientName: input.patientName,
      patientPhone: input.phone,
      serviceType: input.serviceType,
      startTime: startDate.toISOString(),
      endTime: endDate.toISOString(),
      sterilizationEndTime: sterilizationEndDate.toISOString(),
      googleCalendarEventId,
      notes: input.notes,
      isEmergency: input.isEmergency,
    });

    const formattedDate = startDate.toLocaleDateString('ar-JO', {
      weekday: 'long',
      year: 'numeric',
      month: 'long',
      day: 'numeric',
    });
    const formattedTime = startDate.toLocaleTimeString('ar-JO', {
      hour: '2-digit',
      minute: '2-digit',
      hour12: true,
    });

    return {
      success: true,
      appointment,
      googleCalendarEventId,
      message: `يا هلا بك، تم تثبيت موعدك تمام، بانتظارك وتنورنا!
اليوم: ${formattedDate}
الساعة: ${formattedTime}
الخدمة: ${service.nameAr}
المركز: ${CLINIC_CONFIG.name} (${CLINIC_CONFIG.address})`,
    };
  } catch (err: any) {
    if (err?.code === 'DOUBLE_BOOKING_CONFLICT' || err?.message?.includes('DOUBLE_BOOKING_CONFLICT')) {
      return {
        success: false,
        message: `عذراً، يبدو أن هذا الموعد تم حجزه للتو أو يتعارض مع فترة التعقيم الإلزامية (15 دقيقة). هل يناسبك وقت بديل مثل 14:00 أو 16:30؟`,
        conflictDetails: err.message,
      };
    }
    throw err;
  }
}
