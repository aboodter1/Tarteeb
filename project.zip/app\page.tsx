import Link from 'next/link';
import {
  Shield,
  FileCode,
  Calendar,
  Mic,
  Crosshair,
  Bell,
  ArrowLeft,
  CheckCircle2,
  Lock,
  Building,
} from 'lucide-react';
import { CLINIC_CONFIG } from '@/lib/config/constants';

export default function HomePage() {
  return (
    <main className="min-h-screen bg-slate-950 text-slate-100 flex flex-col justify-between selection:bg-emerald-600 selection:text-white">
      {/* Top Navigation */}
      <header className="border-b border-slate-800 bg-slate-900/70 backdrop-blur sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-6 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-emerald-600 to-teal-400 flex items-center justify-center font-bold text-xl text-white shadow-lg shadow-emerald-900/40">
              ن
            </div>
            <div>
              <h1 className="font-bold text-lg text-white">NashmiOps Enterprise</h1>
              <span className="text-xs text-emerald-400 font-medium">
                نشمي أوبس | نظام العمليات والعيادات الذكي (MVP Edition)
              </span>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <Link
              href="/chat"
              className="text-xs text-slate-300 hover:text-white bg-slate-800 hover:bg-slate-700 px-4 py-2.5 rounded-xl border border-slate-700 transition"
            >
              شات الاستقبال المباشر
            </Link>
            <Link
              href="/sandbox"
              className="bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold px-5 py-2.5 rounded-xl shadow-lg shadow-emerald-700/30 flex items-center gap-2 transition"
            >
              <span>فتح بيئة الاختبار (Sandbox)</span>
              <ArrowLeft className="w-4 h-4" />
            </Link>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="max-w-5xl mx-auto px-6 py-16 text-center space-y-6">
        <div className="inline-flex items-center gap-2 bg-emerald-500/10 border border-emerald-500/30 px-4 py-1.5 rounded-full text-emerald-400 text-xs font-semibold">
          <Shield className="w-4 h-4" />
          <span>مطابق 100% لقانون المسؤولية الطبية الأردني رقم 25 وقانون حماية البيانات رقم 24</span>
        </div>

        <h1 className="text-4xl md:text-5xl font-extrabold text-white leading-tight">
          نظام تشغيل عيادات الأسنان بالذكاء الاصطناعي <br />
          <span className="text-transparent bg-clip-text bg-gradient-to-l from-emerald-400 to-teal-200">
            إدارة تشغيلية ذكية وحجز فوري ومباشر
          </span>
        </h1>

        <p className="text-slate-400 text-base md:text-lg max-w-3xl mx-auto leading-relaxed">
          منصة B2B متكاملة متعددة المستأجرين (Multi-Tenant) مصممة خصيصاً لقطاع الرعاية الصحية في المملكة الأردنية
          الهاشمية، تجمع بين الذكاء الاصطناعي الصوتي والمحادثي، الفوترة الإلكترونية الوطنية JoFotara، وقناص المواعيد
          الشاغرة.
        </p>

        <div className="pt-4 flex flex-wrap items-center justify-center gap-4">
          <Link
            href="/sandbox"
            className="bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-bold px-8 py-3.5 rounded-xl shadow-xl shadow-emerald-950 flex items-center gap-2 transition transform hover:-translate-y-0.5 text-sm"
          >
            <span>بدء المحاكاة في الـ Sandbox التفاعلي</span>
            <ArrowLeft className="w-5 h-5" />
          </Link>
          <Link
            href="/chat"
            className="bg-slate-900 hover:bg-slate-800 text-slate-200 font-semibold px-6 py-3.5 rounded-xl border border-slate-700 transition text-sm"
          >
            تجربة شات المريض (WhatsApp Web UI)
          </Link>
        </div>
      </section>

      {/* 5 Core Pillars Grid */}
      <section className="max-w-7xl mx-auto px-6 py-12">
        <h2 className="text-xl font-bold text-center text-slate-200 mb-8">
          الركائز الخمس الأساسية للنظام (The 5 Core Pillars)
        </h2>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {/* Pillar 1: Conversational Voice AI */}
          <div className="bg-slate-900/80 border border-slate-800 p-6 rounded-2xl space-y-3 hover:border-emerald-500/50 transition">
            <div className="w-12 h-12 rounded-xl bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-center text-emerald-400">
              <Mic className="w-6 h-6" />
            </div>
            <h3 className="text-base font-bold text-white">الذكاء الاصطناعي الصوتي والمحادثي</h3>
            <p className="text-xs text-slate-400 leading-relaxed">
              معالجة الرسائل الصوتية (.ogg) ومحادثات الواتساب بلهجة أردنية عفوية وسريعة، مع حجز فوري وسلس ودعم
              ملفات العائلة (حجز الآباء لأبنائهم).
            </p>
          </div>

          {/* Pillar 2: JoFotara E-Invoicing */}
          <div className="bg-slate-900/80 border border-slate-800 p-6 rounded-2xl space-y-3 hover:border-emerald-500/50 transition">
            <div className="w-12 h-12 rounded-xl bg-teal-500/10 border border-teal-500/30 flex items-center justify-center text-teal-400">
              <FileCode className="w-6 h-6" />
            </div>
            <h3 className="text-base font-bold text-white">نظام الفوترة الوطني JoFotara (Phase 2)</h3>
            <p className="text-xs text-slate-400 leading-relaxed">
              توليد XML مطابق لمعيار UBL 2.1 (ISO/IEC 19845)، فواتير مبسطة B2C بدون رقم وطني، وفواتير قياسية B2B بالرقم
              الضريبي، وتشفير تسلسلي PIH مع رمز الاستجابة السريعة TLV Base64.
            </p>
          </div>

          {/* Pillar 3: Waitlist Sniper */}
          <div className="bg-slate-900/80 border border-slate-800 p-6 rounded-2xl space-y-3 hover:border-emerald-500/50 transition">
            <div className="w-12 h-12 rounded-xl bg-blue-500/10 border border-blue-500/30 flex items-center justify-center text-blue-400">
              <Crosshair className="w-6 h-6" />
            </div>
            <h3 className="text-base font-bold text-white">قناص المواعيد الشاغرة (Waitlist Sniper)</h3>
            <p className="text-xs text-slate-400 leading-relaxed">
              بمجرد إلغاء أي موعد، يستعلم النظام ذاتياً عن المرضى في قائمة الانتظار ويرسل قالب واتساب فوري لمنح الموعد
              الشاغر دون تدخل يدوي من موظف الاستقبال.
            </p>
          </div>

          {/* Pillar 4: Reminders & No-Show Recovery */}
          <div className="bg-slate-900/80 border border-slate-800 p-6 rounded-2xl space-y-3 hover:border-emerald-500/50 transition">
            <div className="w-12 h-12 rounded-xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-400">
              <Bell className="w-6 h-6" />
            </div>
            <h3 className="text-base font-bold text-white">التذكير الذكي واستعادة الغائبين (No-Show)</h3>
            <p className="text-xs text-slate-400 leading-relaxed">
              تذكير قبل 24 ساعة، وتذكير قبل ساعتين مع رابط خرائط جوجل المباشر للعيادة، بالإضافة لمتابعة لطيفة بعد ساعة
              من فوات الموعد لإعادة جدولته.
            </p>
          </div>

          {/* Pillar 5: Legal Shield (Law 25 & 24) */}
          <div className="bg-slate-900/80 border border-slate-800 p-6 rounded-2xl space-y-3 hover:border-emerald-500/50 transition">
            <div className="w-12 h-12 rounded-xl bg-red-500/10 border border-red-500/30 flex items-center justify-center text-red-400">
              <Shield className="w-6 h-6" />
            </div>
            <h3 className="text-base font-bold text-white">الدرع القانوني والطبي (Law No. 25 & 24)</h3>
            <p className="text-xs text-slate-400 leading-relaxed">
              منع قطعي لأي تشخيص أو اقتراح أدوية ومسكنات، تحفيز فوري لكود [EMERGENCY_TRIGGER] عند رصد النزيف أو الألم الحاد،
              ومطابقة تامة لحفظ سجلات 5 سنوات عبر الحذف اللطيف.
            </p>
          </div>

          {/* Pillar 6: Sterilization & Multi-Tenancy */}
          <div className="bg-slate-900/80 border border-slate-800 p-6 rounded-2xl space-y-3 hover:border-emerald-500/50 transition">
            <div className="w-12 h-12 rounded-xl bg-purple-500/10 border border-purple-500/30 flex items-center justify-center text-purple-400">
              <Lock className="w-6 h-6" />
            </div>
            <h3 className="text-base font-bold text-white">فترة التعقيم الإلزامية 15 دقيقة وعزل RLS</h3>
            <p className="text-xs text-slate-400 leading-relaxed">
              إضافة تلقائية لـ 15 دقيقة تعقيم بعد كل موعد في Google Calendar لمنع الحجز المزدوج، وعزل كامل لبيانات
              العيادات عبر Supabase Row Level Security.
            </p>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-slate-800 bg-slate-950 py-6 text-center text-xs text-slate-500">
        <p>NashmiOps Enterprise (MVP Edition) © 2026 | عيادات الأسنان - المملكة الأردنية الهاشمية (عمان)</p>
      </footer>
    </main>
  );
}
