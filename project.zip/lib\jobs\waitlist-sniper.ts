// NashmiOps Enterprise (MVP Edition) - Waitlist Sniper

import { Appointment, WaitlistEntry } from '@/types';
import { tenantStore } from '@/lib/db/supabase';
import { CLINIC_CONFIG, CLINICAL_SERVICES } from '@/lib/config/constants';
import { sendWhatsAppTextMessage } from '@/lib/whatsapp/client';

export interface SniperResult {
  triggered: boolean;
  cancelledAppointmentId: string;
  candidateFound: boolean;
  notifiedCandidate?: WaitlistEntry;
  metaTemplatePayload?: {
    to: string;
    templateName: string;
    language: string;
    messageText: string;
  };
}

/**
 * Waitlist Sniper: Autonomously triggered when an appointment is cancelled.
 * It immediately matches waiting patients and sends a Meta WhatsApp Utility Template.
 */
export async function triggerWaitlistSniper(
  cancelledAppt: Appointment
): Promise<SniperResult> {
  const apptDate = cancelledAppt.start_time.split('T')[0];
  const apptTime = new Date(cancelledAppt.start_time).toLocaleTimeString('ar-JO', {
    hour: '2-digit',
    minute: '2-digit',
    hour12: true,
  });

  // Find next waiting patient for this clinic, matching service or date
  const candidate = tenantStore.waitlist.find(
    (w) =>
      w.clinic_id === cancelledAppt.clinic_id &&
      w.status === 'WAITING' &&
      (w.preferred_date === apptDate || w.preferred_date <= apptDate)
  );

  if (!candidate) {
    return {
      triggered: true,
      cancelledAppointmentId: cancelledAppt.id,
      candidateFound: false,
    };
  }

  // Update candidate status
  candidate.status = 'NOTIFIED';
  candidate.notified_at = new Date().toISOString();

  const serviceName =
    CLINICAL_SERVICES[cancelledAppt.service_type]?.nameAr || 'كشف واستشارة';

  // Meta WhatsApp Utility Template Format (Jordanian Arabic)
  const messageText = `مرحباً ${candidate.patient_name} يا هلا فيك،
توفر موعد شاغر مبكر في مركز نشمي لطب وجراحة الأسنان بعمان!
🗓️ التاريخ: ${apptDate}
⏰ الوقت: ${apptTime}
🩺 الخدمة: ${serviceName}

إذا بتحب تأكد الموعد الآن، بس رد بـ "نعم أكد الموعد" وراح نسجله لك فوراً! 🦷`;

  const metaTemplatePayload = {
    to: candidate.patient_phone,
    templateName: 'waitlist_slot_notification_ar',
    language: 'ar',
    messageText,
  };

  console.log(`[Waitlist Sniper] Dispatched slot offer to ${candidate.patient_phone} for slot ${apptDate} ${apptTime}`);

  // Send real outbound WhatsApp message to candidate patient
  try {
    await sendWhatsAppTextMessage(candidate.patient_phone, messageText);
  } catch (outboundErr) {
    console.warn('[Waitlist Sniper] Failed to send outbound WhatsApp message:', outboundErr);
  }

  return {
    triggered: true,
    cancelledAppointmentId: cancelledAppt.id,
    candidateFound: true,
    notifiedCandidate: candidate,
    metaTemplatePayload,
  };
}
