import type { Config } from "tailwindcss";

export default {
  content: [
    "./pages/**/*.{js,ts,jsx,tsx,mdx}",
    "./components/**/*.{js,ts,jsx,tsx,mdx}",
    "./app/**/*.{js,ts,jsx,tsx,mdx}",
    "./lib/**/*.{js,ts,jsx,tsx,mdx}",
  ],
  theme: {
    extend: {
      colors: {
        background: "var(--background)",
        foreground: "var(--foreground)",
        nashmi: {
          50: "#f0fdf4",
          100: "#dcfce7",
          200: "#bbf7d0",
          300: "#86efac",
          400: "#4ade80",
          500: "#22c55e",
          600: "#16a34a",
          700: "#15803d",
          800: "#166534",
          900: "#14532d",
          dark: "#0b2015"
        },
        jordan: {
          red: "#ce1126",
          black: "#000000",
          white: "#ffffff",
          green: "#007a3d"
        }
      },
      fontFamily: {
        sans: ["var(--font-tajawal)", "var(--font-ibm-arabic)", "sans-serif"],
        arabic: ["var(--font-ibm-arabic)", "var(--font-tajawal)", "sans-serif"],
      },
    },
  },
  plugins: [],
} satisfies Config;
