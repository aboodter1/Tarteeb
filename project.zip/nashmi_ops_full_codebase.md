# 🦷 كود مشروع مركز نشمي لطب الأسنان (NashmiOps Enterprise MVP)
> **تاريخ التصدير:** ٢٦‏/٩‏/٢٠٢٦، ٩:٢٨:٣٦ م  
> **عدد الملفات:** 34 ملفاً برمجياً  
> **البنية:** Next.js 15, TypeScript, Supabase, Google GenAI (Gemini 3.5), JoFotara UBL 2.1 XML

---

## 📑 فهرس المحتويات (Index of Files)
1. [app/api/appointments/route.ts](#app-api-appointments-route-ts)
2. [app/api/chat/route.ts](#app-api-chat-route-ts)
3. [app/api/clean-chat/route.ts](#app-api-clean-chat-route-ts)
4. [app/api/history/route.ts](#app-api-history-route-ts)
5. [app/api/jobs/route.ts](#app-api-jobs-route-ts)
6. [app/api/webhook/whatsapp/route.ts](#app-api-webhook-whatsapp-route-ts)
7. [app/chat/page.tsx](#app-chat-page-tsx)
8. [app/globals.css](#app-globals-css)
9. [app/layout.tsx](#app-layout-tsx)
10. [app/page.tsx](#app-page-tsx)
11. [app/sandbox/page.tsx](#app-sandbox-page-tsx)
12. [components/invoice-viewer.tsx](#components-invoice-viewer-tsx)
13. [lib/ai/clinic-tools.ts](#lib-ai-clinic-tools-ts)
14. [lib/ai/gemini-mvp.ts](#lib-ai-gemini-mvp-ts)
15. [lib/ai/react-agent.ts](#lib-ai-react-agent-ts)
16. [lib/auth/api-guard.ts](#lib-auth-api-guard-ts)
17. [lib/calendar/scheduler.ts](#lib-calendar-scheduler-ts)
18. [lib/config/constants.ts](#lib-config-constants-ts)
19. [lib/db/disk-store.ts](#lib-db-disk-store-ts)
20. [lib/db/supabase-browser.ts](#lib-db-supabase-browser-ts)
21. [lib/db/supabase.ts](#lib-db-supabase-ts)
22. [lib/jobs/no-show-recovery.ts](#lib-jobs-no-show-recovery-ts)
23. [lib/jobs/smart-reminders.ts](#lib-jobs-smart-reminders-ts)
24. [lib/jobs/waitlist-sniper.ts](#lib-jobs-waitlist-sniper-ts)
25. [lib/jofotara/client.ts](#lib-jofotara-client-ts)
26. [lib/jofotara/xml-compiler.ts](#lib-jofotara-xml-compiler-ts)
27. [lib/whatsapp/client.ts](#lib-whatsapp-client-ts)
28. [package.json](#package-json)
29. [supabase/migrations/20260926000000_nashmi_mvp.sql](#supabase-migrations-20260926000000-nashmi-mvp-sql)
30. [supabase/migrations/20261001_appointment_exclusion_constraint.sql](#supabase-migrations-20261001-appointment-exclusion-constraint-sql)
31. [supabase/migrations/20261002_failed_outbound_messages.sql](#supabase-migrations-20261002-failed-outbound-messages-sql)
32. [tsconfig.json](#tsconfig-json)
33. [types/index.ts](#types-index-ts)
34. [vercel.json](#vercel-json)

---

## <a id="app-api-appointments-route-ts"></a>📁 `app/api/appointments/route.ts`

```typescript
// File: app/api/appointments/route.ts
// NashmiOps Enterprise (MVP Edition) - Appointments API Endpoint
// Fetches persisted appointments from Supabase & durable store on page load

import { NextRequest, NextResponse } from 'next/server';
import { getAllAppointments, createAppointment } from '@/lib/db/supabase';
import { CLINIC_CONFIG } from '@/lib/config/constants';
import { verifyApiAuthorization } from '@/lib/auth/api-guard';

export async function GET(req: NextRequest) {
  const auth = verifyApiAuthorization(req);
  if (!auth.authorized) {
    return auth.response!;
  }

  try {
    const { searchParams } = new URL(req.url);
    const clinicId = searchParams.get('clinicId') || CLINIC_CONFIG.id;
    const appointments = await getAllAppointments(clinicId);

    return NextResponse.json({
      success: true,
      count: appointments.length,
      appointments,
    });
  } catch (err: any) {
    console.error('[API Appointments GET] Error:', err);
    return NextResponse.json({ success: false, error: err?.message || 'Failed to fetch appointments' }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  const auth = verifyApiAuthorization(req);
  if (!auth.authorized) {
    return auth.response!;
  }

  try {
    const body = await req.json();
    const {
      patientId,
      patientName,
      patientPhone,
      serviceType,
      startTime,
      endTime,
      sterilizationEndTime,
      notes,
    } = body;

    if (!patientName || !startTime) {
      return NextResponse.json({ success: false, error: 'patientName and startTime are required' }, { status: 400 });
    }

    const appt = await createAppointment({
      clinicId: body.clinicId || CLINIC_CONFIG.id,
      patientId: patientId || `pat-${Date.now()}`,
      patientName,
      patientPhone: patientPhone || '+962791234567',
      serviceType: serviceType || 'consultation',
      startTime,
      endTime: endTime || new Date(new Date(startTime).getTime() + 45 * 60000).toISOString(),
      sterilizationEndTime: sterilizationEndTime || new Date(new Date(startTime).getTime() + 60 * 60000).toISOString(),
      notes,
    });

    return NextResponse.json({
      success: true,
      appointment: appt,
    });
  } catch (err: any) {
    if (err?.code === 'DOUBLE_BOOKING_CONFLICT' || err?.message?.includes('DOUBLE_BOOKING_CONFLICT')) {
      return NextResponse.json({ success: false, conflict: true, error: err.message }, { status: 409 });
    }
    console.error('[API Appointments POST] Error:', err);
    return NextResponse.json({ success: false, error: err?.message || 'Failed to create appointment' }, { status: 500 });
  }
}

```

---

## <a id="app-api-chat-route-ts"></a>📁 `app/api/chat/route.ts`

```typescript
// File: app/api/chat/route.ts
// NashmiOps Enterprise (MVP Edition) - Chat API Route Powered by ReAct Agent Core

import { NextRequest, NextResponse } from 'next/server';
import { runReactAgent, isGreetingMessage } from '@/lib/ai/react-agent';

export async function POST(req: NextRequest) {
  let body: any = {};
  try {
    body = await req.json();
  } catch {
    body = {};
  }

  const { message, audioBase64, mimeType, phone, history } = body;
  const userMsg = (message || '').trim();

  try {
    // 12-second timeout safeguard for the conversational orchestration
    const agentPromise = runReactAgent({
      phoneNumber: phone || '+962791234567',
      userMessage: message,
      audioBufferBase64: audioBase64,
      mimeType,
      chatHistoryOverride: history && history.length > 0 ? history : undefined,
    });

    const timeoutPromise = new Promise<{
      replyText: string;
      toolCallsExecuted: any[];
      isEmergency: boolean;
      iterations: number;
    }>((_, reject) => setTimeout(() => reject(new Error('CHAT_ORCHESTRATION_TIMEOUT')), 12000));

    const result = await Promise.race([agentPromise, timeoutPromise]);

    return NextResponse.json({
      success: true,
      reply: result.replyText,
      toolCalls: result.toolCallsExecuted,
      isEmergency: result.isEmergency,
      iterations: result.iterations,
    });
  } catch (err: any) {
    console.error('[API Chat] Error in ReAct execution:', err?.message || err);

    if (isGreetingMessage(userMsg)) {
      return NextResponse.json({
        success: true,
        reply: 'وعليكم السلام ورحمة الله، يا هلا والله فيك في مركز نشمي لطب وجراحة الأسنان بعمان! تفضل يا غالي، كيف بقدر أساعدك بموعدك أو استفسارك اليوم؟',
        toolCalls: [],
        isEmergency: false,
        iterations: 0,
      });
    }

    const nameMatch = userMsg.match(/(?:أنا|اسمي|معك|لـ|للمريض|الأخ|السيد)\s+([^\s،.]+)/);
    const detectedName = nameMatch ? nameMatch[1] : '';
    const greeting = detectedName ? `أهلاً بك يا ${detectedName}` : 'أهلاً بك يا غالي';
    const friendlyApology = `${greeting}، غلبتك صار خطأ بسيط بالاتصال، ممكن تعيدلي طلبك بعد إذنك؟`;

    return NextResponse.json({
      success: true,
      reply: friendlyApology,
      toolCalls: [],
      isEmergency: false,
      iterations: 0,
    });
  }
}

```

---

## <a id="app-api-clean-chat-route-ts"></a>📁 `app/api/clean-chat/route.ts`

```typescript
// File: app/api/clean-chat/route.ts
// NashmiOps Enterprise (MVP Edition) - Clean Chat API Route Powered by ReAct Agent Core

import { NextRequest, NextResponse } from 'next/server';
import { runReactAgent, isGreetingMessage } from '@/lib/ai/react-agent';

export async function POST(req: NextRequest) {
  let body: any = {};
  try {
    body = await req.json();
  } catch {
    body = {};
  }

  const { message, audioBase64, mimeType, phone, history } = body;
  const userMsg = (message || '').trim();

  try {
    // 12-second timeout safeguard for the conversational orchestration
    const agentPromise = runReactAgent({
      phoneNumber: phone || '+962791234567',
      userMessage: message,
      audioBufferBase64: audioBase64,
      mimeType,
      chatHistoryOverride: history && history.length > 0 ? history : undefined,
    });

    const timeoutPromise = new Promise<{
      replyText: string;
      toolCallsExecuted: any[];
      isEmergency: boolean;
      iterations: number;
    }>((_, reject) => setTimeout(() => reject(new Error('CHAT_ORCHESTRATION_TIMEOUT')), 12000));

    const result = await Promise.race([agentPromise, timeoutPromise]);

    return NextResponse.json({
      success: true,
      reply: result.replyText,
      toolCalls: result.toolCallsExecuted,
      isEmergency: result.isEmergency,
      iterations: result.iterations,
    });
  } catch (err: any) {
    console.error('[API Clean-Chat] Error in ReAct execution:', err?.message || err);

    // If greeting, respond warmly without technical alarms
    if (isGreetingMessage(userMsg)) {
      return NextResponse.json({
        success: true,
        reply: 'وعليكم السلام ورحمة الله، يا هلا والله فيك في مركز نشمي لطب وجراحة الأسنان بعمان! تفضل يا غالي، كيف بقدر أساعدك بموعدك أو استفسارك اليوم؟',
        toolCalls: [],
        isEmergency: false,
        iterations: 0,
      });
    }

    const nameMatch = userMsg.match(/(?:أنا|اسمي|معك|لـ|للمريض|الأخ|السيد)\s+([^\s،.]+)/);
    const detectedName = nameMatch ? nameMatch[1] : '';
    const greeting = detectedName ? `أهلاً بك يا ${detectedName}` : 'أهلاً بك يا غالي';
    const friendlyApology = `${greeting}، غلبتك صار خطأ بسيط بالاتصال، ممكن تعيدلي طلبك بعد إذنك؟`;

    return NextResponse.json({
      success: true,
      reply: friendlyApology,
      toolCalls: [],
      isEmergency: false,
      iterations: 0,
    });
  }
}

```

---

## <a id="app-api-history-route-ts"></a>📁 `app/api/history/route.ts`

```typescript
// File: app/api/history/route.ts
// NashmiOps Enterprise (MVP Edition) - Chat History & State Hydration Endpoint
// Fetches and clears conversation checkpoints across browser refreshes & sessions

import { NextRequest, NextResponse } from 'next/server';
import { getConversationHistory, clearConversationHistory } from '@/lib/db/supabase';
import { CLINIC_CONFIG } from '@/lib/config/constants';
import { verifyApiAuthorization } from '@/lib/auth/api-guard';

export async function GET(req: NextRequest) {
  const auth = verifyApiAuthorization(req);
  if (!auth.authorized) {
    return auth.response!;
  }

  try {
    const { searchParams } = new URL(req.url);
    const phone = searchParams.get('phone') || '+962791234567';
    const clinicId = searchParams.get('clinicId') || CLINIC_CONFIG.id;

    const conv = await getConversationHistory(clinicId, phone);

    return NextResponse.json({
      success: true,
      phone,
      patient_name: conv?.patient_name || null,
      chat_history: conv?.chat_history || [],
      updated_at: conv?.updated_at || null,
    });
  } catch (err: any) {
    console.error('[API History GET] Error:', err);
    return NextResponse.json({ success: false, error: err?.message || 'Failed to fetch history' }, { status: 500 });
  }
}

export async function DELETE(req: NextRequest) {
  const auth = verifyApiAuthorization(req);
  if (!auth.authorized) {
    return auth.response!;
  }

  try {
    const { searchParams } = new URL(req.url);
    const phone = searchParams.get('phone') || '+962791234567';
    const clinicId = searchParams.get('clinicId') || CLINIC_CONFIG.id;

    await clearConversationHistory(clinicId, phone);

    return NextResponse.json({
      success: true,
      message: `Conversation history cleared for ${phone}`,
    });
  } catch (err: any) {
    console.error('[API History DELETE] Error:', err);
    return NextResponse.json({ success: false, error: err?.message || 'Failed to clear history' }, { status: 500 });
  }
}

```

---

## <a id="app-api-jobs-route-ts"></a>📁 `app/api/jobs/route.ts`

```typescript
// File: app/api/jobs/route.ts
// NashmiOps Enterprise (MVP Edition) - Operational Jobs API Endpoint

import { NextRequest, NextResponse } from 'next/server';
import { tenantStore, getAllAppointments, cleanupOldProcessedMessages } from '@/lib/db/supabase';
import { triggerWaitlistSniper } from '@/lib/jobs/waitlist-sniper';
import { processNoShowRecovery } from '@/lib/jobs/no-show-recovery';
import { processSmartReminders } from '@/lib/jobs/smart-reminders';
import { compileJoFotaraXML } from '@/lib/jofotara/xml-compiler';
import { verifyApiAuthorization } from '@/lib/auth/api-guard';

export async function GET(req: NextRequest) {
  const auth = verifyApiAuthorization(req);
  if (!auth.authorized) {
    return auth.response!;
  }

  const { searchParams } = new URL(req.url);
  const action = searchParams.get('action');

  // Vercel Cron & External GET automated scheduler support
  if (action === 'trigger_smart_reminders') {
    const result = await processSmartReminders();
    return NextResponse.json({ success: true, cron: true, action, result });
  }

  if (action === 'trigger_no_show_recovery') {
    const result = await processNoShowRecovery();
    return NextResponse.json({ success: true, cron: true, action, result });
  }

  if (action === 'cleanup_messages' || action === 'trigger_cleanup_messages') {
    const cleanup = await cleanupOldProcessedMessages(48);
    return NextResponse.json({ success: true, cron: true, action: 'cleanup_messages', cleanup });
  }

  if (action === 'cron_batch' || action === 'all') {
    const reminders = await processSmartReminders();
    const recovery = await processNoShowRecovery();
    const cleanup = await cleanupOldProcessedMessages(48); // Automatic TTL cleanup of old webhook messages
    return NextResponse.json({
      success: true,
      cron: true,
      action: 'cron_batch',
      results: { reminders, recovery, cleanup },
    });
  }

  // Synchronize appointments from Supabase / persistent store
  await getAllAppointments();

  return NextResponse.json({
    clinics: tenantStore.clinics,
    patients: tenantStore.patients.filter((p) => !p.is_deleted),
    appointments: tenantStore.appointments,
    waitlist: tenantStore.waitlist,
    invoices: tenantStore.invoices,
  });
}

export async function POST(req: NextRequest) {
  const auth = verifyApiAuthorization(req);
  if (!auth.authorized) {
    return auth.response!;
  }

  try {
    const { action, payload } = await req.json();

    switch (action) {
      case 'trigger_waitlist_sniper': {
        const targetAppt =
          tenantStore.appointments.find((a) => a.id === payload?.appointmentId) ||
          tenantStore.appointments[0];

        if (!targetAppt) {
          return NextResponse.json({ error: 'No appointments available to cancel' }, { status: 400 });
        }

        targetAppt.status = 'CANCELLED';
        const result = await triggerWaitlistSniper(targetAppt);
        return NextResponse.json({ success: true, action, result });
      }

      case 'trigger_no_show_recovery': {
        // Mark first appt as NO_SHOW if none exists
        let noShowAppt = tenantStore.appointments.find((a) => a.status === 'NO_SHOW');
        if (!noShowAppt && tenantStore.appointments.length > 0) {
          tenantStore.appointments[0].status = 'NO_SHOW';
          tenantStore.appointments[0].start_time = new Date(Date.now() - 7200000).toISOString(); // 2 hours ago
        }

        const result = await processNoShowRecovery();
        return NextResponse.json({ success: true, action, result });
      }

      case 'trigger_smart_reminders': {
        const result = await processSmartReminders();
        return NextResponse.json({ success: true, action, result });
      }

      case 'cleanup_messages': {
        const cleanup = await cleanupOldProcessedMessages(payload?.maxAgeHours || 48);
        return NextResponse.json({ success: true, action, cleanup });
      }

      case 'test_jofotara': {
        const isB2B = payload?.invoiceType === 'B2B_STANDARD';
        const compileRes = compileJoFotaraXML({
          invoiceNumber: `INV-${Date.now().toString().slice(-4)}`,
          invoiceType: isB2B ? 'B2B_STANDARD' : 'B2C_SIMPLIFIED',
          buyerName: payload?.buyerName || (isB2B ? 'شركة النماء الطبية' : 'مريض نقدي'),
          buyerTaxId: isB2B ? (payload?.buyerTaxId || '109283746') : undefined,
          buyerNationalId: payload?.buyerNationalId,
          items: payload?.items || (isB2B
            ? [
                {
                  name: 'خدمات طب وجراحة أسنان لمنتسبي الشركة',
                  quantity: 2,
                  unitPrice: 125.0,
                  taxRate: 0.16,
                  total: 290.0,
                },
              ]
            : [
                {
                  name: 'كشف واستشارة طبية شاملة مع تنظيف وتلميع أسنان',
                  quantity: 1,
                  unitPrice: 35.0,
                  taxRate: 0.16,
                  total: 40.6,
                },
              ]),
        });
        return NextResponse.json({ success: true, compileRes });
      }

      default:
        return NextResponse.json({ error: `Unknown action: ${action}` }, { status: 400 });
    }
  } catch (err: any) {
    return NextResponse.json({ error: err?.message || 'Execution error' }, { status: 500 });
  }
}

```

---

## <a id="app-api-webhook-whatsapp-route-ts"></a>📁 `app/api/webhook/whatsapp/route.ts`

```typescript
// File: app/api/webhook/whatsapp/route.ts
// NashmiOps Enterprise (MVP Edition) - Meta WhatsApp Cloud API Production Webhook
// Fully Powered by ReAct Agent Core with Loop Capping, Observational Error Recovery & Supabase State Persistence

import { NextRequest, NextResponse } from 'next/server';
import { waitUntil } from '@vercel/functions';
import { runReactAgent } from '@/lib/ai/react-agent';
import {
  sendWhatsAppTextMessage,
  fetchWhatsAppAudioMedia,
} from '@/lib/whatsapp/client';
import { isAndMarkWebhookMessageProcessed } from '@/lib/db/supabase';

export { sendWhatsAppTextMessage };

/**
 * Meta Webhook Verification Handshake (GET)
 */
export async function GET(req: NextRequest) {
  const { searchParams } = new URL(req.url);
  const mode = searchParams.get('hub.mode');
  const token = searchParams.get('hub.verify_token');
  const challenge = searchParams.get('hub.challenge');

  const expectedToken = process.env.META_WHATSAPP_VERIFY_TOKEN || 'nashmi_verify_token_2026';

  if (mode === 'subscribe' && token === expectedToken) {
    console.log('[WhatsApp Webhook] Meta challenge verification passed successfully.');
    return new NextResponse(challenge, { status: 200 });
  }

  return NextResponse.json({ error: 'Forbidden' }, { status: 403 });
}

/**
 * Universal ReAct Webhook Receiver (POST)
 * 1. Immediate 200 OK (<10ms) to satisfy Meta strict SLA.
 * 2. Database-level deduplication via Supabase to prevent duplicate processing on retries.
 * 3. Serverless execution safeguards via waitUntil to ensure processing completes.
 */
export async function POST(req: NextRequest) {
  try {
    const body = await req.json();

    const entry = body?.entry?.[0];
    const changes = entry?.changes?.[0];
    const value = changes?.value;
    const message = value?.messages?.[0];

    // If payload contains no messages (e.g., status updates/read receipts), acknowledge immediately
    if (!message) {
      return NextResponse.json({ status: 'ignored_no_message' }, { status: 200 });
    }

    const messageId = message.id;
    const senderPhone = message.from || '+962791234567';
    const messageType = message.type || (message.audio ? 'audio' : 'text');

    // 1. Strict Database Deduplication via Supabase (Serverless Safe)
    if (messageId) {
      const isDuplicate = await isAndMarkWebhookMessageProcessed({
        messageId,
        senderPhone,
        messageType,
      });

      if (isDuplicate) {
        console.log(`[WhatsApp Webhook] Duplicate message skipped at DB layer: ${messageId}`);
        return NextResponse.json({ status: 'duplicate_skipped', messageId }, { status: 200 });
      }
    }

    // 2. Asynchronous ReAct Execution wrapped in Serverless / Edge Safeguard
    const backgroundTask = (async () => {
      try {
        let userText = message.text?.body || '';
        let audioBase64: string | undefined;
        let mimeType: string | undefined;

        // Audio voice note handling (.ogg / voice note)
        if (message.type === 'audio' || message.audio) {
          const audioId = message.audio?.id;
          console.log(`[WhatsApp Webhook] Received audio voice note ID: ${audioId}`);

          if (audioId) {
            const mediaResult = await fetchWhatsAppAudioMedia(audioId);
            if (mediaResult) {
              audioBase64 = mediaResult.base64;
              mimeType = mediaResult.mimeType;
            }
          }
          if (!audioBase64) {
            userText = '[تسجيل صوتي باللهجة الأردنية - استفسار أو حجز كشف أسنان]';
          }
        }

        console.log(`[WhatsApp Webhook] Launching ReAct Agent for ${senderPhone}: "${userText || '[Audio Note]'}"`);

        // Execute ReAct Agent with loop capping, tool execution, and Supabase checkpointing
        const agentResult = await runReactAgent({
          phoneNumber: senderPhone,
          userMessage: userText,
          audioBufferBase64: audioBase64,
          mimeType,
        });

        console.log(
          `[WhatsApp Webhook] ReAct Agent completed in ${agentResult.iterations} iteration(s). Dispatching response to Meta WhatsApp API...`
        );

        // Outbound Meta WhatsApp Cloud API Dispatch
        const dispatchResult = await sendWhatsAppTextMessage(senderPhone, agentResult.replyText);
        console.log(`[WhatsApp Webhook] Reply dispatched to ${senderPhone} (Status: ${dispatchResult.success ? 'Delivered' : 'Failed'})`);
      } catch (bgErr) {
        console.error('[WhatsApp Webhook] ReAct Background processing error:', bgErr);
      }
    })();

    // Ensure Serverless runtime does NOT freeze or kill the function before completion
    if (typeof waitUntil === 'function') {
      waitUntil(backgroundTask);
    } else {
      void backgroundTask;
    }

    // Fast-path: return immediate 200 OK to Meta
    return NextResponse.json({ status: 'received', messageId }, { status: 200 });
  } catch (err: any) {
    console.error('[WhatsApp Webhook] Failed to parse request:', err);
    return NextResponse.json({ status: 'received' }, { status: 200 });
  }
}

```

---

## <a id="app-chat-page-tsx"></a>📁 `app/chat/page.tsx`

```tsx
// File: app/chat/page.tsx
'use client';

import React, { useState, useRef, useEffect } from 'react';
import { Send, Sparkles, RotateCcw, User, Bot, Mic, ShieldAlert, ArrowRight } from 'lucide-react';
import Link from 'next/link';

interface Message {
  id: string;
  role: 'user' | 'model';
  text: string;
  time: string;
  isEmergency?: boolean;
}

export default function CleanChatPage() {
  const [isMounted, setIsMounted] = useState(false);
  const [messages, setMessages] = useState<Message[]>([
    {
      id: 'welcome',
      role: 'model',
      text: 'يا هلا والله فيك في مركز نشمي لطب وجراحة الأسنان بعمان! تفضل يا غالي، كيف بقدر أساعدك بموعدك أو استفسارك اليوم؟ 🦷',
      time: '',
    },
  ]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLTextAreaElement>(null);

  useEffect(() => {
    setIsMounted(true);
    setMessages((prev) =>
      prev.map((m) =>
        m.id === 'welcome' && !m.time
          ? {
              ...m,
              time: new Date().toLocaleTimeString('ar-JO', {
                hour: '2-digit',
                minute: '2-digit',
              }),
            }
          : m
      )
    );
    fetchChatHistory();
  }, []);

  const fetchChatHistory = async () => {
    try {
      const res = await fetch('/api/history?phone=+962791234567');
      const data = await res.json();
      if (data.success && Array.isArray(data.chat_history) && data.chat_history.length > 0) {
        const formatted: Message[] = data.chat_history.map((m: any, idx: number) => ({
          id: `ch-${idx}-${m.timestamp || Date.now()}`,
          role: m.role === 'user' ? 'user' : 'model',
          text: m.text,
          time: m.timestamp
            ? new Date(m.timestamp).toLocaleTimeString('ar-JO', { hour: '2-digit', minute: '2-digit' })
            : '',
        }));
        setMessages(formatted);
      }
    } catch (err) {
      console.warn('[CleanChat] Failed to hydrate chat history:', err);
    }
  };

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, loading]);

  // Safety Watchdog: Guarantee loading indicator NEVER hangs longer than 10 seconds under any circumstances
  useEffect(() => {
    if (!loading) return;
    const watchdog = setTimeout(() => {
      console.warn('[Safety Watchdog] Auto-clearing hung loading state');
      setLoading(false);
    }, 10000);
    return () => clearTimeout(watchdog);
  }, [loading]);

  const handleSend = async (customMessage?: string, isVoice = false) => {
    const textToSend = customMessage || input.trim();
    if (!textToSend || loading) return;

    const userMsg: Message = {
      id: `u-${Date.now()}`,
      role: 'user',
      text: isVoice ? `🎤 [رسالة صوتية] "${textToSend}"` : textToSend,
      time: new Date().toLocaleTimeString('ar-JO', { hour: '2-digit', minute: '2-digit' }),
    };

    const newHistory = [...messages, userMsg];
    setMessages(newHistory);
    setInput('');
    setLoading(true);

    // AbortController with generous 14s maximum client timeout
    const controller = new AbortController();
    const clientTimeout = setTimeout(() => {
      controller.abort();
    }, 14000);

    const isGreeting = /(?:السلام|سلام|مرحبا|صباح|مساء|يعطيك|هلا|أهلا|اهلا)/.test(textToSend);

    try {
      const historyPayload = messages.map((m) => ({
        role: m.role,
        text: m.text,
      }));

      // Call /api/clean-chat with fallback to /api/chat
      let res: Response;
      try {
        res = await fetch('/api/clean-chat', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            message: textToSend,
            history: historyPayload,
            phone: '+962791234567',
          }),
          signal: controller.signal,
        });
      } catch (cleanChatErr: any) {
        if (cleanChatErr?.name === 'AbortError') throw cleanChatErr;
        res = await fetch('/api/chat', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            message: textToSend,
            history: historyPayload,
            phone: '+962791234567',
          }),
          signal: controller.signal,
        });
      }

      clearTimeout(clientTimeout);

      let data: any = {};
      try {
        data = await res.json();
      } catch {
        data = {};
      }

      const nameMatch = textToSend.match(/(?:أنا|اسمي|معك|لـ|للمريض|الأخ|السيد)\s+([^\s،.]+)/);
      const detectedName = nameMatch ? nameMatch[1] : '';
      const greeting = detectedName ? `أهلاً بك يا ${detectedName}` : 'أهلاً بك يا غالي';
      const fallbackText = isGreeting
        ? 'وعليكم السلام ورحمة الله، يا هلا والله فيك في مركز نشمي لطب وجراحة الأسنان بعمان! تفضل يا غالي، كيف بقدر أساعدك بموعدك أو استفسارك اليوم؟'
        : `${greeting}، غلبتك صار خطأ بسيط بالاتصال، ممكن تعيدلي طلبك بعد إذنك؟`;

      const botReply = data.reply || fallbackText;

      const agentMsg: Message = {
        id: `m-${Date.now()}`,
        role: 'model',
        text: botReply,
        time: new Date().toLocaleTimeString('ar-JO', { hour: '2-digit', minute: '2-digit' }),
        isEmergency: data.isEmergency,
      };

      setMessages((prev) => [...prev, agentMsg]);
    } catch (err: any) {
      clearTimeout(clientTimeout);
      console.error('[Chat Client Request Error]:', err);

      const nameMatch = textToSend.match(/(?:أنا|اسمي|معك|لـ|للمريض|الأخ|السيد)\s+([^\s،.]+)/);
      const detectedName = nameMatch ? nameMatch[1] : '';
      const greeting = detectedName ? `أهلاً بك يا ${detectedName}` : 'أهلاً بك يا غالي';
      const fallbackText = isGreeting
        ? 'وعليكم السلام ورحمة الله، يا هلا والله فيك في مركز نشمي لطب وجراحة الأسنان بعمان! تفضل يا غالي، كيف بقدر أساعدك بموعدك أو استفسارك اليوم؟'
        : `${greeting}، غلبتك صار خطأ بسيط بالاتصال، ممكن تعيدلي طلبك بعد إذنك؟`;

      setMessages((prev) => [
        ...prev,
        {
          id: `err-${Date.now()}`,
          role: 'model',
          text: fallbackText,
          time: new Date().toLocaleTimeString('ar-JO', { hour: '2-digit', minute: '2-digit' }),
        },
      ]);
    } finally {
      // Guaranteed termination of loading state under all circumstances
      setLoading(false);
      setTimeout(() => inputRef.current?.focus(), 50);
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  const handleReset = async () => {
    try {
      await fetch('/api/history?phone=+962791234567', { method: 'DELETE' });
    } catch (err) {
      console.warn('[CleanChat] Failed to clear history:', err);
    }
    setMessages([
      {
        id: 'welcome',
        role: 'model',
        text: 'يا هلا والله فيك في مركز نشمي لطب وجراحة الأسنان بعمان! تفضل يا غالي، كيف بقدر أساعدك بموعدك أو استفسارك اليوم؟ 🦷',
        time: new Date().toLocaleTimeString('ar-JO', { hour: '2-digit', minute: '2-digit' }),
      },
    ]);
    setInput('');
    inputRef.current?.focus();
  };

  return (
    <div dir="rtl" className="flex flex-col h-screen bg-slate-950 text-slate-100 font-sans">
      {/* Top Header */}
      <header className="flex items-center justify-between px-6 py-4 border-b border-slate-800 bg-slate-900/90 backdrop-blur sticky top-0 z-10">
        <div className="flex items-center gap-3">
          <Link
            href="/"
            title="الرئيسية"
            className="w-10 h-10 rounded-xl bg-gradient-to-tr from-emerald-600 to-teal-400 flex items-center justify-center shadow-lg shadow-emerald-500/20 text-white font-bold"
          >
            🦷
          </Link>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="font-bold text-base md:text-lg text-slate-100">
                مركز نشمي لطب وجراحة الأسنان
              </h1>
              <span className="flex items-center gap-1 text-[11px] font-medium bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 px-2 py-0.5 rounded-full">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse"></span>
                Gemini 3.5 متصل
              </span>
            </div>
            <p className="text-xs text-slate-400">
              الاستقبال الذكي للمواعيد والاستفسارات - عمان، الأردن
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <Link
            href="/sandbox"
            className="hidden sm:flex items-center gap-1.5 text-xs text-emerald-400 hover:text-emerald-300 bg-emerald-950/40 hover:bg-emerald-900/40 px-3 py-1.5 rounded-lg border border-emerald-800/40 transition"
          >
            <span>بيئة الاختبار Sandbox</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </Link>
          <button
            onClick={handleReset}
            title="بدء محادثة جديدة"
            className="flex items-center gap-1.5 text-xs text-slate-400 hover:text-slate-200 bg-slate-800/60 hover:bg-slate-800 px-3 py-1.5 rounded-lg border border-slate-700 transition"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">محادثة جديدة</span>
          </button>
        </div>
      </header>

      {/* Messages Feed */}
      <main className="flex-1 overflow-y-auto p-4 md:p-6 space-y-4 max-w-4xl w-full mx-auto">
        {messages.map((msg) => {
          const isUser = msg.role === 'user';
          return (
            <div
              key={msg.id}
              className={`flex items-end gap-2.5 ${isUser ? 'flex-row-reverse' : 'flex-row'}`}
            >
              <div
                className={`w-8 h-8 rounded-full flex items-center justify-center shrink-0 text-xs ${
                  isUser
                    ? 'bg-blue-600 text-white'
                    : msg.isEmergency
                    ? 'bg-red-600 text-white animate-pulse'
                    : 'bg-emerald-600/30 text-emerald-300 border border-emerald-500/30'
                }`}
              >
                {isUser ? <User className="w-4 h-4" /> : <Bot className="w-4 h-4" />}
              </div>

              <div
                className={`max-w-[85%] sm:max-w-[75%] rounded-2xl px-4 py-3 text-sm md:text-[15px] leading-relaxed shadow-sm ${
                  isUser
                    ? 'bg-blue-600 text-white rounded-bl-none'
                    : msg.isEmergency
                    ? 'bg-red-950/90 border border-red-700 text-red-100 rounded-br-none'
                    : 'bg-slate-900 border border-slate-800 text-slate-200 rounded-br-none'
                }`}
              >
                <p className="whitespace-pre-wrap">{msg.text}</p>
                <span
                  suppressHydrationWarning={true}
                  className={`block text-[10px] mt-1.5 text-left opacity-60 ${
                    isUser ? 'text-blue-100' : 'text-slate-400'
                  }`}
                >
                  {isMounted ? msg.time : ''}
                </span>
              </div>
            </div>
          );
        })}

        {loading && (
          <div className="flex items-end gap-2.5">
            <div className="w-8 h-8 rounded-full bg-emerald-600/30 text-emerald-300 border border-emerald-500/30 flex items-center justify-center shrink-0">
              <Sparkles className="w-4 h-4 animate-spin" />
            </div>
            <div className="bg-slate-900 border border-slate-800 rounded-2xl rounded-br-none px-4 py-3 text-sm text-slate-400 flex items-center gap-1.5">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-bounce"></span>
              <span
                className="w-2 h-2 rounded-full bg-emerald-400 animate-bounce"
                style={{ animationDelay: '0.15s' }}
              ></span>
              <span
                className="w-2 h-2 rounded-full bg-emerald-400 animate-bounce"
                style={{ animationDelay: '0.3s' }}
              ></span>
              <span className="text-xs mr-2 text-slate-400">نشمي يكتب الآن...</span>
            </div>
          </div>
        )}

        <div ref={messagesEndRef} />
      </main>

      {/* Input Bar */}
      <footer className="p-4 border-t border-slate-800 bg-slate-900/90 backdrop-blur sticky bottom-0">
        <div className="max-w-4xl mx-auto flex items-end gap-2">
          <button
            onClick={() => handleSend('يا هلا دكتور، بسجل صوتي عشان أسأل عن موعد تنظيف أسنان الأسبوع الجاي', true)}
            title="إرسال رسالة صوتية تجريبية"
            className="h-12 w-12 rounded-xl bg-slate-800 hover:bg-slate-700 text-emerald-400 border border-slate-700 flex items-center justify-center transition shrink-0"
          >
            <Mic className="w-5 h-5" />
          </button>

          <textarea
            ref={inputRef}
            rows={1}
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={handleKeyDown}
            placeholder="اكتب رسالتك هنا كالمريض... (اضغط Enter للإرسال)"
            className="flex-1 resize-none bg-slate-950 border border-slate-700 focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500 rounded-xl px-4 py-3 text-sm text-slate-100 placeholder-slate-500 outline-none transition max-h-32 min-h-[48px]"
          />

          <button
            onClick={() => handleSend()}
            disabled={!input.trim() || loading}
            aria-label="إرسال"
            className="h-12 w-12 rounded-xl bg-emerald-600 hover:bg-emerald-500 active:bg-emerald-700 disabled:opacity-40 disabled:hover:bg-emerald-600 text-white flex items-center justify-center transition shrink-0 shadow-lg shadow-emerald-600/20"
          >
            <Send className="w-5 h-5 -rotate-90" />
          </button>
        </div>
      </footer>
    </div>
  );
}

```

---

## <a id="app-globals-css"></a>📁 `app/globals.css`

```css
// File: app/globals.css
@tailwind base;
@tailwind components;
@tailwind utilities;

:root {
  --background: #020617;
  --foreground: #f8fafc;
}

body {
  color: var(--foreground);
  background: var(--background);
  font-family: 'IBM Plex Sans Arabic', 'Tajawal', sans-serif;
  direction: rtl;
  text-align: right;
}

/* Custom scrollbar for RTL */
::-webkit-scrollbar {
  width: 6px;
  height: 6px;
}
::-webkit-scrollbar-track {
  background: #0f172a;
}
::-webkit-scrollbar-thumb {
  background: #334155;
  border-radius: 9999px;
}
::-webkit-scrollbar-thumb:hover {
  background: #10b981;
}

```

---

## <a id="app-layout-tsx"></a>📁 `app/layout.tsx`

```tsx
// File: app/layout.tsx
import type { Metadata } from 'next';
import './globals.css';

export const metadata: Metadata = {
  title: 'NashmiOps Enterprise (نشمي أوبس) - نظام تشغيل العيادات الذكي',
  description: 'نظام تشغيل عيادات الأسنان بالذكاء الاصطناعي - متوافق مع التشريعات الأردنية والفوترة الوطنية JoFotara',
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="ar" dir="rtl">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link
          href="https://fonts.googleapis.com/css2?family=IBM+Plex+Sans+Arabic:wght@300;400;500;600;700&family=Tajawal:wght@400;500;700;800;900&display=swap"
          rel="stylesheet"
        />
      </head>
      <body className="antialiased bg-slate-950 text-slate-100 min-h-screen selection:bg-emerald-600 selection:text-white">
        {children}
      </body>
    </html>
  );
}

```

---

## <a id="app-page-tsx"></a>📁 `app/page.tsx`

```tsx
// File: app/page.tsx
import Link from 'next/link';
import {
  Shield,
  FileCode,
  Calendar,
  Mic,
  Crosshair,
  Bell,
  ArrowLeft,
  CheckCircle2,
  Lock,
  Building,
} from 'lucide-react';
import { CLINIC_CONFIG } from '@/lib/config/constants';

export default function HomePage() {
  return (
    <main className="min-h-screen bg-slate-950 text-slate-100 flex flex-col justify-between selection:bg-emerald-600 selection:text-white">
      {/* Top Navigation */}
      <header className="border-b border-slate-800 bg-slate-900/70 backdrop-blur sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-6 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-emerald-600 to-teal-400 flex items-center justify-center font-bold text-xl text-white shadow-lg shadow-emerald-900/40">
              ن
            </div>
            <div>
              <h1 className="font-bold text-lg text-white">NashmiOps Enterprise</h1>
              <span className="text-xs text-emerald-400 font-medium">
                نشمي أوبس | نظام العمليات والعيادات الذكي (MVP Edition)
              </span>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <Link
              href="/chat"
              className="text-xs text-slate-300 hover:text-white bg-slate-800 hover:bg-slate-700 px-4 py-2.5 rounded-xl border border-slate-700 transition"
            >
              شات الاستقبال المباشر
            </Link>
            <Link
              href="/sandbox"
              className="bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold px-5 py-2.5 rounded-xl shadow-lg shadow-emerald-700/30 flex items-center gap-2 transition"
            >
              <span>فتح بيئة الاختبار (Sandbox)</span>
              <ArrowLeft className="w-4 h-4" />
            </Link>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="max-w-5xl mx-auto px-6 py-16 text-center space-y-6">
        <div className="inline-flex items-center gap-2 bg-emerald-500/10 border border-emerald-500/30 px-4 py-1.5 rounded-full text-emerald-400 text-xs font-semibold">
          <Shield className="w-4 h-4" />
          <span>مطابق 100% لقانون المسؤولية الطبية الأردني رقم 25 وقانون حماية البيانات رقم 24</span>
        </div>

        <h1 className="text-4xl md:text-5xl font-extrabold text-white leading-tight">
          نظام تشغيل عيادات الأسنان بالذكاء الاصطناعي <br />
          <span className="text-transparent bg-clip-text bg-gradient-to-l from-emerald-400 to-teal-200">
            إدارة تشغيلية ذكية وحجز فوري ومباشر
          </span>
        </h1>

        <p className="text-slate-400 text-base md:text-lg max-w-3xl mx-auto leading-relaxed">
          منصة B2B متكاملة متعددة المستأجرين (Multi-Tenant) مصممة خصيصاً لقطاع الرعاية الصحية في المملكة الأردنية
          الهاشمية، تجمع بين الذكاء الاصطناعي الصوتي والمحادثي، الفوترة الإلكترونية الوطنية JoFotara، وقناص المواعيد
          الشاغرة.
        </p>

        <div className="pt-4 flex flex-wrap items-center justify-center gap-4">
          <Link
            href="/sandbox"
            className="bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-bold px-8 py-3.5 rounded-xl shadow-xl shadow-emerald-950 flex items-center gap-2 transition transform hover:-translate-y-0.5 text-sm"
          >
            <span>بدء المحاكاة في الـ Sandbox التفاعلي</span>
            <ArrowLeft className="w-5 h-5" />
          </Link>
          <Link
            href="/chat"
            className="bg-slate-900 hover:bg-slate-800 text-slate-200 font-semibold px-6 py-3.5 rounded-xl border border-slate-700 transition text-sm"
          >
            تجربة شات المريض (WhatsApp Web UI)
          </Link>
        </div>
      </section>

      {/* 5 Core Pillars Grid */}
      <section className="max-w-7xl mx-auto px-6 py-12">
        <h2 className="text-xl font-bold text-center text-slate-200 mb-8">
          الركائز الخمس الأساسية للنظام (The 5 Core Pillars)
        </h2>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {/* Pillar 1: Conversational Voice AI */}
          <div className="bg-slate-900/80 border border-slate-800 p-6 rounded-2xl space-y-3 hover:border-emerald-500/50 transition">
            <div className="w-12 h-12 rounded-xl bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-center text-emerald-400">
              <Mic className="w-6 h-6" />
            </div>
            <h3 className="text-base font-bold text-white">الذكاء الاصطناعي الصوتي والمحادثي</h3>
            <p className="text-xs text-slate-400 leading-relaxed">
              معالجة الرسائل الصوتية (.ogg) ومحادثات الواتساب بلهجة أردنية عفوية وسريعة، مع حجز فوري وسلس ودعم
              ملفات العائلة (حجز الآباء لأبنائهم).
            </p>
          </div>

          {/* Pillar 2: JoFotara E-Invoicing */}
          <div className="bg-slate-900/80 border border-slate-800 p-6 rounded-2xl space-y-3 hover:border-emerald-500/50 transition">
            <div className="w-12 h-12 rounded-xl bg-teal-500/10 border border-teal-500/30 flex items-center justify-center text-teal-400">
              <FileCode className="w-6 h-6" />
            </div>
            <h3 className="text-base font-bold text-white">نظام الفوترة الوطني JoFotara (Phase 2)</h3>
            <p className="text-xs text-slate-400 leading-relaxed">
              توليد XML مطابق لمعيار UBL 2.1 (ISO/IEC 19845)، فواتير مبسطة B2C بدون رقم وطني، وفواتير قياسية B2B بالرقم
              الضريبي، وتشفير تسلسلي PIH مع رمز الاستجابة السريعة TLV Base64.
            </p>
          </div>

          {/* Pillar 3: Waitlist Sniper */}
          <div className="bg-slate-900/80 border border-slate-800 p-6 rounded-2xl space-y-3 hover:border-emerald-500/50 transition">
            <div className="w-12 h-12 rounded-xl bg-blue-500/10 border border-blue-500/30 flex items-center justify-center text-blue-400">
              <Crosshair className="w-6 h-6" />
            </div>
            <h3 className="text-base font-bold text-white">قناص المواعيد الشاغرة (Waitlist Sniper)</h3>
            <p className="text-xs text-slate-400 leading-relaxed">
              بمجرد إلغاء أي موعد، يستعلم النظام ذاتياً عن المرضى في قائمة الانتظار ويرسل قالب واتساب فوري لمنح الموعد
              الشاغر دون تدخل يدوي من موظف الاستقبال.
            </p>
          </div>

          {/* Pillar 4: Reminders & No-Show Recovery */}
          <div className="bg-slate-900/80 border border-slate-800 p-6 rounded-2xl space-y-3 hover:border-emerald-500/50 transition">
            <div className="w-12 h-12 rounded-xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-400">
              <Bell className="w-6 h-6" />
            </div>
            <h3 className="text-base font-bold text-white">التذكير الذكي واستعادة الغائبين (No-Show)</h3>
            <p className="text-xs text-slate-400 leading-relaxed">
              تذكير قبل 24 ساعة، وتذكير قبل ساعتين مع رابط خرائط جوجل المباشر للعيادة، بالإضافة لمتابعة لطيفة بعد ساعة
              من فوات الموعد لإعادة جدولته.
            </p>
          </div>

          {/* Pillar 5: Legal Shield (Law 25 & 24) */}
          <div className="bg-slate-900/80 border border-slate-800 p-6 rounded-2xl space-y-3 hover:border-emerald-500/50 transition">
            <div className="w-12 h-12 rounded-xl bg-red-500/10 border border-red-500/30 flex items-center justify-center text-red-400">
              <Shield className="w-6 h-6" />
            </div>
            <h3 className="text-base font-bold text-white">الدرع القانوني والطبي (Law No. 25 & 24)</h3>
            <p className="text-xs text-slate-400 leading-relaxed">
              منع قطعي لأي تشخيص أو اقتراح أدوية ومسكنات، تحفيز فوري لكود [EMERGENCY_TRIGGER] عند رصد النزيف أو الألم الحاد،
              ومطابقة تامة لحفظ سجلات 5 سنوات عبر الحذف اللطيف.
            </p>
          </div>

          {/* Pillar 6: Sterilization & Multi-Tenancy */}
          <div className="bg-slate-900/80 border border-slate-800 p-6 rounded-2xl space-y-3 hover:border-emerald-500/50 transition">
            <div className="w-12 h-12 rounded-xl bg-purple-500/10 border border-purple-500/30 flex items-center justify-center text-purple-400">
              <Lock className="w-6 h-6" />
            </div>
            <h3 className="text-base font-bold text-white">فترة التعقيم الإلزامية 15 دقيقة وعزل RLS</h3>
            <p className="text-xs text-slate-400 leading-relaxed">
              إضافة تلقائية لـ 15 دقيقة تعقيم بعد كل موعد في Google Calendar لمنع الحجز المزدوج، وعزل كامل لبيانات
              العيادات عبر Supabase Row Level Security.
            </p>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-slate-800 bg-slate-950 py-6 text-center text-xs text-slate-500">
        <p>NashmiOps Enterprise (MVP Edition) © 2026 | عيادات الأسنان - المملكة الأردنية الهاشمية (عمان)</p>
      </footer>
    </main>
  );
}

```

---

## <a id="app-sandbox-page-tsx"></a>📁 `app/sandbox/page.tsx`

```tsx
// File: app/sandbox/page.tsx
'use client';

import React, { useState, useEffect, useRef } from 'react';
import {
  Send,
  Mic,
  Bot,
  User,
  Shield,
  FileCode,
  Calendar,
  Crosshair,
  Bell,
  RefreshCw,
  AlertTriangle,
  CheckCircle2,
  ExternalLink,
  QrCode,
  Sparkles,
  RotateCcw,
} from 'lucide-react';
import { CLINIC_CONFIG, CLINICAL_SERVICES } from '@/lib/config/constants';
import { InvoiceViewer } from '@/components/invoice-viewer';
import { supabaseBrowser } from '@/lib/db/supabase-browser';

interface ChatMessage {
  id: string;
  sender: 'user' | 'bot' | 'system';
  text: string;
  isVoice?: boolean;
  time: string;
  isEmergency?: boolean;
}

export default function SandboxPage() {
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: 'm1',
      sender: 'bot',
      text: 'يا هلا والله فيك في مركز نشمي لطب وجراحة الأسنان في عمان 🦷 تفضل يا غالي، كيف بقدر أساعدك بموعدك أو استفسارك اليوم؟',
      time: '10:00 ص',
    },
  ]);
  const [inputText, setInputText] = useState('');
  const [isRecording, setIsRecording] = useState(false);
  const [loading, setLoading] = useState(false);
  const [activeTab, setActiveTab] = useState<'tools' | 'database' | 'jofotara' | 'jobs'>('tools');
  const [telemetry, setTelemetry] = useState<any>({
    toolCalls: [],
    database: { appointments: [], patients: [], waitlist: [], invoices: [] },
    latestXml: '',
    latestQr: '',
    latestInvoiceMeta: null,
    jobsLog: [],
  });
  const [isMounted, setIsMounted] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    setIsMounted(true);
    fetchTelemetry();
    fetchChatHistory();
    executeJobAction('test_jofotara', { invoiceType: 'B2C_SIMPLIFIED' });

    // Supabase Realtime Subscription on appointments table
    let channel: any = null;
    try {
      channel = supabaseBrowser
        .channel('realtime-appointments-sandbox')
        .on(
          'postgres_changes',
          { event: '*', schema: 'public', table: 'appointments' },
          () => {
            fetchTelemetry();
          }
        )
        .subscribe();
    } catch (realtimeErr) {
      console.warn('[Sandbox Realtime] Subscription error, relying on poll fallback:', realtimeErr);
    }

    // Polling fallback every 3.5 seconds for instant synchrony
    const pollInterval = setInterval(() => {
      fetchTelemetry();
    }, 3500);

    return () => {
      if (channel) {
        supabaseBrowser.removeChannel(channel);
      }
      clearInterval(pollInterval);
    };
  }, []);

  const fetchChatHistory = async () => {
    try {
      const res = await fetch('/api/history?phone=+962791234567');
      const data = await res.json();
      if (data.success && Array.isArray(data.chat_history) && data.chat_history.length > 0) {
        const formatted: ChatMessage[] = data.chat_history.map((m: any, idx: number) => ({
          id: `h-${idx}-${m.timestamp || Date.now()}`,
          sender: m.role === 'user' ? 'user' : 'bot',
          text: m.text,
          time: m.timestamp
            ? new Date(m.timestamp).toLocaleTimeString('ar-JO', { hour: '2-digit', minute: '2-digit' })
            : '10:00 ص',
        }));
        setMessages(formatted);
      }
    } catch (err) {
      console.warn('[Sandbox] Failed to hydrate chat history:', err);
    }
  };

  const handleResetChat = async () => {
    try {
      await fetch('/api/history?phone=+962791234567', { method: 'DELETE' });
      setMessages([
        {
          id: `m-reset-${Date.now()}`,
          sender: 'bot',
          text: 'يا هلا والله فيك في مركز نشمي لطب وجراحة الأسنان في عمان 🦷 تفضل يا غالي، كيف بقدر أساعدك بموعدك أو استفسارك اليوم؟',
          time: new Date().toLocaleTimeString('ar-JO', { hour: '2-digit', minute: '2-digit' }),
        },
      ]);
    } catch (err) {
      console.warn('[Sandbox] Failed to reset chat history:', err);
    }
  };

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, loading]);

  const fetchTelemetry = async () => {
    try {
      const res = await fetch('/api/jobs');
      const data = await res.json();
      setTelemetry((prev: any) => ({
        ...prev,
        database: data,
      }));
    } catch (err) {
      console.warn('Failed to fetch telemetry:', err);
    }
  };

  // Safety Watchdog: Guarantee loading indicator NEVER hangs longer than 10 seconds under any circumstances
  useEffect(() => {
    if (!loading) return;
    const watchdog = setTimeout(() => {
      console.warn('[Sandbox Watchdog] Auto-clearing hung loading state');
      setLoading(false);
    }, 10000);
    return () => clearTimeout(watchdog);
  }, [loading]);

  const handleSendMessage = async (customText?: string, isVoice = false) => {
    const textToSend = customText || inputText.trim();
    if (!textToSend || loading) return;

    const userMsg: ChatMessage = {
      id: `u-${Date.now()}`,
      sender: 'user',
      text: isVoice ? `🎤 [رسالة صوتية] "${textToSend}"` : textToSend,
      isVoice,
      time: new Date().toLocaleTimeString('ar-JO', { hour: '2-digit', minute: '2-digit' }),
    };

    setMessages((prev) => [...prev, userMsg]);
    setInputText('');
    setLoading(true);

    const controller = new AbortController();
    const clientTimeout = setTimeout(() => {
      controller.abort();
    }, 14000);

    const isGreeting = /(?:السلام|سلام|مرحبا|صباح|مساء|يعطيك|هلا|أهلا|اهلا)/.test(textToSend);

    try {
      const res = await fetch('/api/clean-chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: textToSend,
          audioBase64: isVoice ? 'UklGRiQAAABXQVZFZm10IBAAAAABAAEAQB8AAEAfAAABAAgAZGF0YQAAAAA=' : undefined,
          phone: '+962791234567',
          history: messages.map((m) => ({
            role: m.sender === 'user' ? 'user' : 'model',
            text: m.text,
          })),
        }),
        signal: controller.signal,
      });

      clearTimeout(clientTimeout);

      let data: any = {};
      try {
        data = await res.json();
      } catch {
        data = {};
      }

      const nameMatch = textToSend.match(/(?:أنا|اسمي|معك|لـ|للمريض|الأخ|السيد)\s+([^\s،.]+)/);
      const detectedName = nameMatch ? nameMatch[1] : '';
      const greeting = detectedName ? `أهلاً بك يا ${detectedName}` : 'أهلاً بك يا غالي';
      const fallbackText = isGreeting
        ? 'وعليكم السلام ورحمة الله، يا هلا والله فيك في مركز نشمي لطب وجراحة الأسنان بعمان! تفضل يا غالي، كيف بقدر أساعدك بموعدك أو استفسارك اليوم؟'
        : `${greeting}، غلبتك صار خطأ بسيط بالاتصال، ممكن تعيدلي طلبك بعد إذنك؟`;

      const botMsg: ChatMessage = {
        id: `b-${Date.now()}`,
        sender: 'bot',
        text: data.reply || fallbackText,
        time: new Date().toLocaleTimeString('ar-JO', { hour: '2-digit', minute: '2-digit' }),
        isEmergency: data.isEmergency,
      };

      setMessages((prev) => [...prev, botMsg]);

      // Update telemetry
      if (data.toolCalls && data.toolCalls.length > 0) {
        setTelemetry((prev: any) => ({
          ...prev,
          toolCalls: [...data.toolCalls, ...prev.toolCalls],
        }));
      }

      await fetchTelemetry();
    } catch (err: any) {
      clearTimeout(clientTimeout);
      console.warn('[Sandbox Client Error/Timeout]:', err?.message || err);

      const nameMatch = textToSend.match(/(?:أنا|اسمي|معك|لـ|للمريض|الأخ|السيد)\s+([^\s،.]+)/);
      const detectedName = nameMatch ? nameMatch[1] : '';
      const greeting = detectedName ? `أهلاً بك يا ${detectedName}` : 'أهلاً بك يا غالي';
      const fallbackText = isGreeting
        ? 'وعليكم السلام ورحمة الله، يا هلا والله فيك في مركز نشمي لطب وجراحة الأسنان بعمان! تفضل يا غالي، كيف بقدر أساعدك بموعدك أو استفسارك اليوم؟'
        : `${greeting}، غلبتك صار خطأ بسيط بالاتصال، ممكن تعيدلي طلبك بعد إذنك؟`;

      setMessages((prev) => [
        ...prev,
        {
          id: `b-${Date.now()}`,
          sender: 'bot',
          text: fallbackText,
          time: new Date().toLocaleTimeString('ar-JO', { hour: '2-digit', minute: '2-digit' }),
        },
      ]);
    } finally {
      setLoading(false);
    }
  };

  const executeJobAction = async (action: string, payload?: any) => {
    try {
      const res = await fetch('/api/jobs', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action, payload }),
      });
      const data = await res.json();
      setTelemetry((prev: any) => ({
        ...prev,
        jobsLog: [{ action, timestamp: new Date().toISOString(), result: data.result || data.compileRes }, ...prev.jobsLog],
        latestXml: data.compileRes?.xml || prev.latestXml,
        latestQr: data.compileRes?.tlvQrCode || prev.latestQr,
        latestInvoiceMeta: data.compileRes || prev.latestInvoiceMeta,
      }));
      await fetchTelemetry();
    } catch (err) {
      console.error('Job trigger error:', err);
    }
  };

  return (
    <div dir="rtl" className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans">
      {/* Top Header */}
      <header className="px-6 py-3.5 border-b border-slate-800 bg-slate-900/90 backdrop-blur sticky top-0 z-50 flex items-center justify-between no-print">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-emerald-600 to-teal-400 flex items-center justify-center font-bold text-white shadow-md shadow-emerald-600/30">
            🦷
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="font-bold text-base md:text-lg">NashmiOps Enterprise (MVP Edition)</h1>
              <span className="text-[10px] bg-emerald-500/10 text-emerald-400 border border-emerald-500/30 px-2 py-0.5 rounded-full font-mono">
                عمان - الأردن 🇯🇴
              </span>
            </div>
            <p className="text-xs text-slate-400">
              بيئة المحاكاة التفاعلية (Dual-Pane Sandbox) | نظام تشغيل العيادات الذكي
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={fetchTelemetry}
            className="flex items-center gap-1.5 text-xs text-slate-300 hover:text-white bg-slate-800/80 px-3 py-1.5 rounded-lg border border-slate-700 transition"
          >
            <RefreshCw className="w-3.5 h-3.5" />
            <span>تحديث البيانات</span>
          </button>
        </div>
      </header>

      {/* Main Dual-Pane Container */}
      <main className="flex-1 grid grid-cols-1 lg:grid-cols-12 overflow-hidden h-[calc(100vh-65px)]">
        {/* LEFT PANE: WhatsApp Simulator (5 cols on desktop) */}
        <section className="lg:col-span-5 flex flex-col border-b lg:border-b-0 lg:border-l border-slate-800 bg-slate-950 no-print">
          {/* WhatsApp Header Simulation */}
          <div className="px-4 py-3 bg-slate-900/80 border-b border-slate-800 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="relative">
                <div className="w-10 h-10 rounded-full bg-emerald-700 flex items-center justify-center text-white font-bold text-sm">
                  نشمي
                </div>
                <span className="absolute bottom-0 left-0 w-3 h-3 bg-emerald-500 border-2 border-slate-900 rounded-full"></span>
              </div>
              <div>
                <div className="flex items-center gap-1.5">
                  <h2 className="text-sm font-semibold text-white">{CLINIC_CONFIG.name}</h2>
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                </div>
                <p className="text-[11px] text-slate-400">متصل الآن عبر واتساب الأعمال • عمان</p>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={handleResetChat}
                title="بدء محادثة جديدة ومسح السجل"
                className="flex items-center gap-1 text-[11px] text-slate-300 hover:text-rose-400 bg-slate-800 hover:bg-slate-700/80 px-2 py-1 rounded border border-slate-700 transition"
              >
                <RotateCcw className="w-3 h-3" />
                <span>محادثة جديدة</span>
              </button>
              <span className="text-[10px] text-slate-400 bg-slate-800 px-2 py-1 rounded">
                +962 7 9000 0000
              </span>
            </div>
          </div>

          {/* Quick Scenario Chips */}
          <div className="p-2.5 bg-slate-900/40 border-b border-slate-800/60 overflow-x-auto flex gap-2 text-xs">
            <button
              onClick={() => handleSendMessage('مرحبا، بدي احجز موعد كشف واستشارة بكرة بعد الظهر')}
              className="whitespace-nowrap px-2.5 py-1 rounded-full bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 transition"
            >
              🩺 حجز موعد كشف
            </button>
            <button
              onClick={() =>
                handleSendMessage('مرحبا يا دكتور، عندي نزيف مستمر في اللثة مع ورم كبير في خدي ومش قادر اتنفس كويس', false)
              }
              className="whitespace-nowrap px-2.5 py-1 rounded-full bg-red-950/40 hover:bg-red-900/50 text-red-300 border border-red-800/40 transition flex items-center gap-1"
            >
              <AlertTriangle className="w-3 h-3 text-red-400" />
              <span>🚨 اختبار طوارئ قانون 25</span>
            </button>
            <button
              onClick={() =>
                handleSendMessage('بدي احجز موعد تنظيف أسنان لابني عمره 10 سنوات واسمه كرم التميمي', false)
              }
              className="whitespace-nowrap px-2.5 py-1 rounded-full bg-blue-950/40 hover:bg-blue-900/50 text-blue-300 border border-blue-800/40 transition"
            >
              👨‍👩‍👧 حجز لابني (عائلة)
            </button>
            <button
              onClick={() =>
                handleSendMessage('بدي الغي موعدي بكرة لانه عندي ظرف طارئ', false)
              }
              className="whitespace-nowrap px-2.5 py-1 rounded-full bg-amber-950/40 hover:bg-amber-900/50 text-amber-300 border border-amber-800/40 transition"
            >
              ❌ إلغاء موعد (قناص)
            </button>
            <button
              onClick={() =>
                handleSendMessage('أنا شركة استشارات، بدي فاتورة ضريبية رسمية للشركة باسم شركة الأمل ورقمها الضريبي 102938475', false)
              }
              className="whitespace-nowrap px-2.5 py-1 rounded-full bg-teal-950/40 hover:bg-teal-900/50 text-teal-300 border border-teal-800/40 transition"
            >
              📜 فاتورة JoFotara B2B
            </button>
          </div>

          {/* Messages Feed */}
          <div className="flex-1 overflow-y-auto p-4 space-y-3 bg-[radial-gradient(#1e293b_1px,transparent_1px)] [background-size:16px_16px]">
            {messages.map((msg) => {
              const isUser = msg.sender === 'user';
              return (
                <div
                  key={msg.id}
                  className={`flex items-end gap-2 ${isUser ? 'flex-row-reverse' : 'flex-row'}`}
                >
                  <div
                    className={`w-7 h-7 rounded-full flex items-center justify-center text-xs shrink-0 ${
                      isUser
                        ? 'bg-blue-600 text-white'
                        : msg.isEmergency
                        ? 'bg-red-600 text-white animate-pulse'
                        : 'bg-emerald-600 text-white'
                    }`}
                  >
                    {isUser ? <User className="w-3.5 h-3.5" /> : <Bot className="w-3.5 h-3.5" />}
                  </div>

                  <div
                    className={`max-w-[85%] rounded-2xl px-3.5 py-2.5 text-xs md:text-sm leading-relaxed shadow-sm ${
                      isUser
                        ? 'bg-emerald-700 text-white rounded-bl-none'
                        : msg.isEmergency
                        ? 'bg-red-950/80 border border-red-700 text-red-100 rounded-br-none'
                        : 'bg-slate-900 border border-slate-800 text-slate-200 rounded-br-none'
                    }`}
                  >
                    <p className="whitespace-pre-wrap">{msg.text}</p>
                    <span
                      suppressHydrationWarning={true}
                      className={`block text-[10px] mt-1 text-left opacity-60 ${
                        isUser ? 'text-emerald-200' : 'text-slate-400'
                      }`}
                    >
                      {isMounted ? msg.time : ''}
                    </span>
                  </div>
                </div>
              );
            })}

            {loading && (
              <div className="flex items-center gap-2 text-slate-400 text-xs">
                <Sparkles className="w-4 h-4 animate-spin text-emerald-400" />
                <span>نشمي يكتب الآن...</span>
              </div>
            )}
            <div ref={messagesEndRef} />
          </div>

          {/* Input Area */}
          <div className="p-3 border-t border-slate-800 bg-slate-900/90 flex items-center gap-2">
            <button
              onClick={() => handleSendMessage('يا هلا دكتور، بسجل صوتي عشان أسأل عن موعد تنظيف أسنان الأربعاء الجاي', true)}
              title="إرسال رسالة صوتية تجريبية"
              className="p-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-emerald-400 border border-slate-700 transition shrink-0"
            >
              <Mic className="w-4 h-4" />
            </button>

            <textarea
              rows={1}
              value={inputText}
              onChange={(e) => setInputText(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === 'Enter' && !e.shiftKey) {
                  e.preventDefault();
                  handleSendMessage();
                }
              }}
              placeholder="اكتب رسالة واتساب كالمريض..."
              className="flex-1 bg-slate-950 border border-slate-700 focus:border-emerald-500 rounded-xl px-3.5 py-2 text-xs md:text-sm text-slate-100 outline-none resize-none"
            />

            <button
              onClick={() => handleSendMessage()}
              disabled={!inputText.trim() || loading}
              className="p-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 disabled:opacity-40 text-white transition shrink-0"
            >
              <Send className="w-4 h-4 -rotate-90" />
            </button>
          </div>
        </section>

        {/* RIGHT PANE: Live Telemetry & Control Center (7 cols on desktop) */}
        <section className="lg:col-span-7 flex flex-col bg-slate-900/50 overflow-hidden">
          {/* Tabs Navigation */}
          <div className="flex items-center border-b border-slate-800 bg-slate-900 px-4 pt-2 no-print">
            <button
              onClick={() => setActiveTab('tools')}
              className={`flex items-center gap-1.5 px-4 py-2.5 text-xs font-semibold border-b-2 transition ${
                activeTab === 'tools'
                  ? 'border-emerald-500 text-emerald-400 bg-slate-800/40'
                  : 'border-transparent text-slate-400 hover:text-slate-200'
              }`}
            >
              <Sparkles className="w-3.5 h-3.5" />
              <span>أدوات Gemini (Tool Calls)</span>
            </button>

            <button
              onClick={() => setActiveTab('database')}
              className={`flex items-center gap-1.5 px-4 py-2.5 text-xs font-semibold border-b-2 transition ${
                activeTab === 'database'
                  ? 'border-emerald-500 text-emerald-400 bg-slate-800/40'
                  : 'border-transparent text-slate-400 hover:text-slate-200'
              }`}
            >
              <Calendar className="w-3.5 h-3.5" />
              <span>قاعدة بيانات Supabase (RLS)</span>
              {telemetry.database?.appointments?.length > 0 && (
                <span className="text-[10px] bg-emerald-500/20 text-emerald-300 px-1.5 py-0.2 rounded-full font-mono">
                  {telemetry.database.appointments.length}
                </span>
              )}
            </button>

            <button
              onClick={() => setActiveTab('jofotara')}
              className={`flex items-center gap-1.5 px-4 py-2.5 text-xs font-semibold border-b-2 transition ${
                activeTab === 'jofotara'
                  ? 'border-emerald-500 text-emerald-400 bg-slate-800/40'
                  : 'border-transparent text-slate-400 hover:text-slate-200'
              }`}
            >
              <FileCode className="w-3.5 h-3.5" />
              <span>الفوترة الوطنية JoFotara</span>
            </button>

            <button
              onClick={() => setActiveTab('jobs')}
              className={`flex items-center gap-1.5 px-4 py-2.5 text-xs font-semibold border-b-2 transition ${
                activeTab === 'jobs'
                  ? 'border-emerald-500 text-emerald-400 bg-slate-800/40'
                  : 'border-transparent text-slate-400 hover:text-slate-200'
              }`}
            >
              <Crosshair className="w-3.5 h-3.5" />
              <span>المهام الذكية (Waitlist & Recovery)</span>
            </button>
          </div>

          {/* Tab Content Display */}
          <div className="flex-1 overflow-y-auto p-4 md:p-6 space-y-4">
            {/* TAB 1: Gemini Tool Calls */}
            {activeTab === 'tools' && (
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <h3 className="text-sm font-bold text-slate-200 flex items-center gap-2">
                    <Sparkles className="w-4 h-4 text-emerald-400" />
                    <span>سجل استدعاء أدوات الذكاء الاصطناعي (Function Declarations)</span>
                  </h3>
                  <span className="text-[11px] text-slate-400">
                    النموذج: gemini-3.5-flash / gemini-2.5-flash
                  </span>
                </div>

                {telemetry.toolCalls.length === 0 ? (
                  <div className="bg-slate-900 border border-slate-800 rounded-xl p-6 text-center text-slate-400 text-xs">
                    لم يتم تنفيذ أي استدعاء أدوات حتى الآن. جرب إرسال رسالة حجز أو إلغاء في لوحة المحادثة على اليمين!
                  </div>
                ) : (
                  telemetry.toolCalls.map((call: any, idx: number) => (
                    <div
                      key={idx}
                      className="bg-slate-900/90 border border-slate-800 rounded-xl p-4 space-y-2 text-xs font-mono"
                    >
                      <div className="flex items-center justify-between text-emerald-400 font-semibold border-b border-slate-800 pb-2">
                        <span>Tool: {call.name}()</span>
                        <span className="text-[10px] text-slate-400 bg-slate-800 px-2 py-0.5 rounded">
                          Success
                        </span>
                      </div>
                      <div>
                        <span className="text-slate-400 block mb-1">Arguments:</span>
                        <pre className="bg-slate-950 p-2.5 rounded-lg text-slate-300 overflow-x-auto">
                          {JSON.stringify(call.args, null, 2)}
                        </pre>
                      </div>
                      <div>
                        <span className="text-slate-400 block mb-1">Execution Result:</span>
                        <pre className="bg-slate-950 p-2.5 rounded-lg text-emerald-300 overflow-x-auto">
                          {JSON.stringify(call.result, null, 2)}
                        </pre>
                      </div>
                    </div>
                  ))
                )}
              </div>
            )}

            {/* TAB 2: Supabase Multi-Tenant RLS */}
            {activeTab === 'database' && (
              <div className="space-y-6">
                {/* Appointments Section */}
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <h4 className="text-xs font-bold text-slate-200 flex items-center gap-1.5">
                      <Calendar className="w-3.5 h-3.5 text-emerald-400" />
                      <span>جدول المواعيد (appointments) - شاملاً فترة التعقيم الإلزامية 15 دقيقة</span>
                    </h4>
                    <span className="text-[10px] text-slate-400 font-mono">
                      Clinic ID: {CLINIC_CONFIG.id}
                    </span>
                  </div>

                  <div className="bg-slate-900 border border-slate-800 rounded-xl overflow-x-auto">
                    <table className="w-full text-right text-xs">
                      <thead className="bg-slate-950/80 text-slate-400 border-b border-slate-800">
                        <tr>
                          <th className="p-2.5">المريض</th>
                          <th className="p-2.5">الخدمة</th>
                          <th className="p-2.5">وقت البدء</th>
                          <th className="p-2.5">نهاية التعقيم</th>
                          <th className="p-2.5">الحالة</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-800 text-slate-300">
                        {telemetry.database.appointments.map((appt: any) => (
                          <tr key={appt.id} className="hover:bg-slate-800/40">
                            <td className="p-2.5 font-medium text-white">{appt.patient_name}</td>
                            <td className="p-2.5 text-slate-400">{appt.service_type}</td>
                            <td className="p-2.5 font-mono text-[11px]">
                              {new Date(appt.start_time).toLocaleString('ar-JO')}
                            </td>
                            <td className="p-2.5 font-mono text-[11px] text-amber-400">
                              {new Date(appt.sterilization_end_time || appt.end_time).toLocaleTimeString(
                                'ar-JO'
                              )}
                            </td>
                            <td className="p-2.5">
                              <span
                                className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                                  appt.status === 'CONFIRMED'
                                    ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/30'
                                    : appt.status === 'CANCELLED'
                                    ? 'bg-red-500/10 text-red-400 border border-red-500/30'
                                    : 'bg-amber-500/10 text-amber-400 border border-amber-500/30'
                                }`}
                              >
                                {appt.status}
                              </span>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>

                {/* Waitlist Section */}
                <div className="space-y-3">
                  <h4 className="text-xs font-bold text-slate-200 flex items-center gap-1.5">
                    <Crosshair className="w-3.5 h-3.5 text-teal-400" />
                    <span>قائمة الانتظار الذكية (waitlist)</span>
                  </h4>

                  <div className="bg-slate-900 border border-slate-800 rounded-xl overflow-x-auto">
                    <table className="w-full text-right text-xs">
                      <thead className="bg-slate-950/80 text-slate-400 border-b border-slate-800">
                        <tr>
                          <th className="p-2.5">المريض</th>
                          <th className="p-2.5">الهاتف</th>
                          <th className="p-2.5">الخدمة</th>
                          <th className="p-2.5">التاريخ المفضل</th>
                          <th className="p-2.5">الحالة</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-800 text-slate-300">
                        {telemetry.database.waitlist.map((wait: any) => (
                          <tr key={wait.id}>
                            <td className="p-2.5 text-white">{wait.patient_name}</td>
                            <td className="p-2.5 font-mono">{wait.patient_phone}</td>
                            <td className="p-2.5">{wait.requested_service}</td>
                            <td className="p-2.5 font-mono">{wait.preferred_date}</td>
                            <td className="p-2.5">
                              <span className="px-2 py-0.5 rounded-full text-[10px] bg-teal-500/10 text-teal-300 border border-teal-500/30">
                                {wait.status}
                              </span>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            )}

            {/* TAB 3: JoFotara Phase 2 UBL 2.1 */}
            {activeTab === 'jofotara' && (
              <div className="space-y-4">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-slate-900 border border-slate-800 p-4 rounded-xl no-print">
                  <div>
                    <h3 className="text-sm font-bold text-slate-200">
                      محرك الفوترة الإلكترونية الوطنية JoFotara (Phase 2)
                    </h3>
                    <p className="text-xs text-slate-400">
                      معاينة بصرية كاملة للفاتورة مع طباعة رسمية وتوليد XML مطابق لمعيار UBL 2.1 ورمز TLV QR
                    </p>
                  </div>

                  <div className="flex gap-2">
                    <button
                      onClick={() => executeJobAction('test_jofotara', { invoiceType: 'B2C_SIMPLIFIED' })}
                      className="px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold shadow-sm transition active:scale-95"
                    >
                      توليد B2C مبسطة
                    </button>
                    <button
                      onClick={() =>
                        executeJobAction('test_jofotara', {
                          invoiceType: 'B2B_STANDARD',
                          buyerName: 'شركة النماء الطبية',
                          buyerTaxId: '109283746',
                        })
                      }
                      className="px-3 py-1.5 rounded-lg bg-teal-600 hover:bg-teal-500 text-white text-xs font-semibold shadow-sm transition active:scale-95"
                    >
                      توليد B2B معتمدة
                    </button>
                  </div>
                </div>

                {telemetry.latestXml ? (
                  <InvoiceViewer
                    xml={telemetry.latestXml}
                    metadata={telemetry.latestInvoiceMeta}
                  />
                ) : (
                  <div className="bg-slate-900 border border-slate-800 rounded-xl p-8 text-center text-slate-400 text-xs no-print">
                    اضغط على &quot;توليد B2C مبسطة&quot; أو &quot;توليد B2B معتمدة&quot; لمعاينة الفاتورة أو كود الـ XML الناتج فوراً!
                  </div>
                )}
              </div>
            )}

            {/* TAB 4: Autonomous Background Jobs */}
            {activeTab === 'jobs' && (
              <div className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                  <div className="bg-slate-900 border border-slate-800 p-4 rounded-xl space-y-2">
                    <div className="flex items-center justify-between">
                      <h4 className="font-bold text-xs text-white">Waitlist Sniper</h4>
                      <Crosshair className="w-4 h-4 text-emerald-400" />
                    </div>
                    <p className="text-[11px] text-slate-400 leading-relaxed">
                      عند إلغاء موعد، يقنص أقرب مريض في قائمة الانتظار ويرسل له قالب واتساب فوري لملء الشاغر.
                    </p>
                    <button
                      onClick={() => executeJobAction('trigger_waitlist_sniper')}
                      className="w-full mt-2 bg-emerald-600/20 hover:bg-emerald-600/30 text-emerald-300 border border-emerald-500/30 text-xs font-semibold py-1.5 rounded-lg transition"
                    >
                      تشغيل القناص فوراً
                    </button>
                  </div>

                  <div className="bg-slate-900 border border-slate-800 p-4 rounded-xl space-y-2">
                    <div className="flex items-center justify-between">
                      <h4 className="font-bold text-xs text-white">No-Show Recovery</h4>
                      <RefreshCw className="w-4 h-4 text-amber-400" />
                    </div>
                    <p className="text-[11px] text-slate-400 leading-relaxed">
                      يرصد المواعيد الفائتة ويرسل رسالة إعادة تفعيل لطيفة بعد ساعة لإعادة جدولة الموعد مجاناً.
                    </p>
                    <button
                      onClick={() => executeJobAction('trigger_no_show_recovery')}
                      className="w-full mt-2 bg-amber-600/20 hover:bg-amber-600/30 text-amber-300 border border-amber-500/30 text-xs font-semibold py-1.5 rounded-lg transition"
                    >
                      معالجة الغائبين (No-Show)
                    </button>
                  </div>

                  <div className="bg-slate-900 border border-slate-800 p-4 rounded-xl space-y-2">
                    <div className="flex items-center justify-between">
                      <h4 className="font-bold text-xs text-white">Smart Reminders</h4>
                      <Bell className="w-4 h-4 text-blue-400" />
                    </div>
                    <p className="text-[11px] text-slate-400 leading-relaxed">
                      يرسل تذكير قبل 24 ساعة، وتذكير قبل ساعتين يتضمن رابط خرائط جوجل المباشر لعيادة الدوار السابع.
                    </p>
                    <button
                      onClick={() => executeJobAction('trigger_smart_reminders')}
                      className="w-full mt-2 bg-blue-600/20 hover:bg-blue-600/30 text-blue-300 border border-blue-500/30 text-xs font-semibold py-1.5 rounded-lg transition"
                    >
                      فحص التذكيرات الذكية
                    </button>
                  </div>
                </div>

                {/* Job Execution Logs */}
                <div className="space-y-2">
                  <h4 className="text-xs font-bold text-slate-300">سجل تشغيل المهام بالخلفية:</h4>
                  {telemetry.jobsLog.length === 0 ? (
                    <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 text-center text-slate-400 text-xs">
                      اضغط على أحد أزرار تشغيل المهام بالأعلى لمعاينة نتيجته المباشرة هنا!
                    </div>
                  ) : (
                    telemetry.jobsLog.map((log: any, idx: number) => (
                      <div
                        key={idx}
                        className="bg-slate-950 border border-slate-800 p-3 rounded-xl text-xs font-mono space-y-1.5"
                      >
                        <div className="flex items-center justify-between text-slate-400 text-[11px]">
                          <span className="text-emerald-400 font-bold">{log.action}</span>
                          <span>{new Date(log.timestamp).toLocaleTimeString('ar-JO')}</span>
                        </div>
                        <pre className="text-slate-300 overflow-x-auto text-[11px]">
                          {JSON.stringify(log.result, null, 2)}
                        </pre>
                      </div>
                    ))
                  )}
                </div>
              </div>
            )}
          </div>
        </section>
      </main>
    </div>
  );
}

```

---

## <a id="components-invoice-viewer-tsx"></a>📁 `components/invoice-viewer.tsx`

```tsx
// File: components/invoice-viewer.tsx
'use client';

import React, { useState, useEffect } from 'react';
import QRCode from 'qrcode';
import {
  FileText,
  Code,
  Printer,
  CheckCircle2,
  Building2,
  Calendar,
  Clock,
  ShieldCheck,
  Hash,
  User,
  QrCode,
  Copy,
  Check,
} from 'lucide-react';
import { CLINIC_CONFIG } from '@/lib/config/constants';

export interface InvoiceItemData {
  name: string;
  quantity: number;
  unitPrice: number;
  taxRate: number;
  total: number;
}

export interface InvoiceViewerProps {
  xml?: string;
  metadata?: {
    invoiceNumber?: string;
    invoiceType?: 'B2C_SIMPLIFIED' | 'B2B_STANDARD';
    issueDate?: string;
    issueTime?: string;
    buyerName?: string;
    buyerTaxId?: string;
    buyerNationalId?: string;
    items?: InvoiceItemData[];
    subtotal?: number;
    taxAmount?: number;
    totalAmount?: number;
    uuid?: string;
    invoiceHash?: string;
    tlvQrCode?: string;
  };
}

export function InvoiceViewer({ xml, metadata }: InvoiceViewerProps) {
  const [viewMode, setViewMode] = useState<'preview' | 'xml'>('preview');
  const [qrCodeDataUrl, setQrCodeDataUrl] = useState<string>('');
  const [copiedHash, setCopiedHash] = useState(false);

  // Extract or fallback to metadata / XML
  const rawXml = xml || '';

  const extractRegex = (regex: RegExp, defaultVal = ''): string => {
    const match = rawXml.match(regex);
    return match ? match[1].trim() : defaultVal;
  };

  const invoiceNumber =
    metadata?.invoiceNumber ||
    extractRegex(/<cbc:ID>(INV-[^<]+)<\/cbc:ID>/) ||
    extractRegex(/<cbc:ID>([^<]+)<\/cbc:ID>/, 'INV-2026-0001');

  const uuid =
    metadata?.uuid ||
    extractRegex(/<cbc:UUID>([^<]+)<\/cbc:UUID>/, 'e5a4099b-d748-422f-87d5-d91abf81b19a');

  const issueDate =
    metadata?.issueDate ||
    extractRegex(/<cbc:IssueDate>([^<]+)<\/cbc:IssueDate>/, new Date().toISOString().split('T')[0]);

  const issueTime =
    metadata?.issueTime ||
    extractRegex(/<cbc:IssueTime>([^<]+)<\/cbc:IssueTime>/, new Date().toLocaleTimeString('ar-JO'));

  const invoiceTypeCode = extractRegex(/<cbc:InvoiceTypeCode[^>]*>([^<]+)<\/cbc:InvoiceTypeCode>/);
  const isB2B =
    metadata?.invoiceType === 'B2B_STANDARD' ||
    rawXml.includes('clearance:1.0') ||
    Boolean(metadata?.buyerTaxId);

  const buyerName =
    metadata?.buyerName ||
    extractRegex(/<cac:AccountingCustomerParty>[\s\S]*?<cbc:RegistrationName>([^<]+)<\/cbc:RegistrationName>/, 'مريض نقدي');

  const buyerTaxId =
    metadata?.buyerTaxId ||
    extractRegex(/<cac:AccountingCustomerParty>[\s\S]*?<cbc:CompanyID>([^<]+)<\/cbc:CompanyID>/, '');

  const buyerNationalId =
    metadata?.buyerNationalId ||
    extractRegex(/<cac:AccountingCustomerParty>[\s\S]*?<cbc:ID schemeID="NID">([^<]+)<\/cbc:ID>/, '');

  const subtotalVal =
    metadata?.subtotal !== undefined
      ? metadata.subtotal
      : parseFloat(extractRegex(/<cbc:TaxExclusiveAmount[^>]*>([^<]+)<\/cbc:TaxExclusiveAmount>/, '35.0'));

  const taxAmountVal =
    metadata?.taxAmount !== undefined
      ? metadata.taxAmount
      : parseFloat(extractRegex(/<cac:TaxTotal>[\s\S]*?<cbc:TaxAmount[^>]*>([^<]+)<\/cbc:TaxAmount>/, '5.6'));

  const totalAmountVal =
    metadata?.totalAmount !== undefined
      ? metadata.totalAmount
      : parseFloat(extractRegex(/<cbc:TaxInclusiveAmount[^>]*>([^<]+)<\/cbc:TaxInclusiveAmount>/, '40.6'));

  const tlvQrCode =
    metadata?.tlvQrCode ||
    extractRegex(
      /<cac:AdditionalDocumentReference>[\s\S]*?<cbc:ID>QR<\/cbc:ID>[\s\S]*?<cac:Attachment>[\s\S]*?<cac:EmbeddedDocumentBinaryObject[^>]*>([^<]+)<\/cac:EmbeddedDocumentBinaryObject>/
    );

  const invoiceHash =
    metadata?.invoiceHash ||
    extractRegex(
      /<cac:AdditionalDocumentReference>[\s\S]*?<cbc:ID>PIH<\/cbc:ID>[\s\S]*?<cac:Attachment>[\s\S]*?<cac:EmbeddedDocumentBinaryObject[^>]*>([^<]+)<\/cac:EmbeddedDocumentBinaryObject>/,
      '7f83b1657ff1fc53b92dc18148a1d65dfc2d4b1fa3d677284addd200126d9069'
    );

  // Extract items
  let parsedItems: InvoiceItemData[] = metadata?.items || [];
  if (parsedItems.length === 0 && rawXml) {
    const lineMatches = rawXml.match(/<cac:InvoiceLine>[\s\S]*?<\/cac:InvoiceLine>/g);
    if (lineMatches && lineMatches.length > 0) {
      parsedItems = lineMatches.map((block) => {
        const name =
          block.match(/<cbc:Name>([^<]+)<\/cbc:Name>/)?.[1] ||
          block.match(/<cbc:Description>([^<]+)<\/cbc:Description>/)?.[1] ||
          'خدمة طب أسنان';
        const quantity = parseFloat(block.match(/<cbc:InvoicedQuantity[^>]*>([^<]+)<\/cbc:InvoicedQuantity>/)?.[1] || '1');
        const unitPrice = parseFloat(block.match(/<cac:Price>[\s\S]*?<cbc:PriceAmount[^>]*>([^<]+)<\/cbc:PriceAmount>/)?.[1] || '35');
        const taxRate = parseFloat(block.match(/<cbc:Percent>([^<]+)<\/cbc:Percent>/)?.[1] || '16') / 100;
        const total = quantity * unitPrice * (1 + taxRate);
        return { name, quantity, unitPrice, taxRate, total };
      });
    }
  }

  if (parsedItems.length === 0) {
    parsedItems = [
      {
        name: isB2B ? 'خدمات طب وجراحة أسنان لمنتسبي الشركة' : 'كشف واستشارة طبية شاملة مع تنظيف وتلميع أسنان',
        quantity: isB2B ? 2 : 1,
        unitPrice: isB2B ? 125.0 : 35.0,
        taxRate: 0.16,
        total: totalAmountVal,
      },
    ];
  }

  // Generate QR Code image
  useEffect(() => {
    if (!tlvQrCode) {
      setQrCodeDataUrl('');
      return;
    }
    QRCode.toDataURL(tlvQrCode, {
      width: 170,
      margin: 1,
      color: {
        dark: '#0f172a',
        light: '#ffffff',
      },
    })
      .then((url) => setQrCodeDataUrl(url))
      .catch((err) => console.warn('QR Code generation error:', err));
  }, [tlvQrCode]);

  const handlePrint = () => {
    window.print();
  };

  const handleCopyHash = () => {
    if (!invoiceHash) return;
    navigator.clipboard.writeText(invoiceHash);
    setCopiedHash(true);
    setTimeout(() => setCopiedHash(false), 2000);
  };

  return (
    <div className="space-y-4">
      {/* Print Stylesheet injection */}
      <style jsx global>{`
        @media print {
          body {
            background-color: white !important;
            color: black !important;
          }
          .no-print {
            display: none !important;
          }
          .printable-invoice-wrapper {
            display: block !important;
            position: absolute !important;
            left: 0 !important;
            top: 0 !important;
            width: 100% !important;
            margin: 0 !important;
            padding: 24px !important;
            background: white !important;
            color: black !important;
          }
          .printable-invoice-card {
            border: 1px solid #cbd5e1 !important;
            box-shadow: none !important;
            background: white !important;
            color: #0f172a !important;
          }
          .printable-invoice-card * {
            color: #0f172a !important;
          }
          .printable-invoice-card .text-slate-400,
          .printable-invoice-card .text-slate-500 {
            color: #64748b !important;
          }
          .printable-invoice-card th {
            background-color: #f1f5f9 !important;
            color: #0f172a !important;
          }
        }
      `}</style>

      {/* Control Bar: View Toggle + Print Button */}
      <div className="flex flex-wrap items-center justify-between gap-3 bg-slate-900 border border-slate-800 p-3 rounded-xl no-print">
        {/* Toggle Switch */}
        <div className="flex items-center bg-slate-950 p-1 rounded-lg border border-slate-800">
          <button
            onClick={() => setViewMode('preview')}
            className={`flex items-center gap-2 px-3 py-1.5 rounded-md text-xs font-semibold transition ${
              viewMode === 'preview'
                ? 'bg-emerald-600 text-white shadow-sm'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <FileText className="w-3.5 h-3.5" />
            <span>معاينة الفاتورة (Invoice Preview)</span>
          </button>
          <button
            onClick={() => setViewMode('xml')}
            className={`flex items-center gap-2 px-3 py-1.5 rounded-md text-xs font-semibold transition ${
              viewMode === 'xml'
                ? 'bg-emerald-600 text-white shadow-sm'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <Code className="w-3.5 h-3.5" />
            <span>عرض الكود (XML View)</span>
          </button>
        </div>

        {/* Action Buttons */}
        <div className="flex items-center gap-2">
          {viewMode === 'preview' && (
            <button
              onClick={handlePrint}
              className="flex items-center gap-2 px-3.5 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold shadow-sm transition active:scale-95"
            >
              <Printer className="w-3.5 h-3.5" />
              <span>طباعة الفاتورة (Print / PDF)</span>
            </button>
          )}

          <div className="flex items-center gap-1.5 text-[11px] text-emerald-400 bg-emerald-950/60 border border-emerald-500/30 px-2.5 py-1.5 rounded-lg">
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
            <span>معتمدة ضريبياً (JoFotara Phase 2)</span>
          </div>
        </div>
      </div>

      {/* VIEW 1: Raw XML View */}
      {viewMode === 'xml' && (
        <div className="space-y-3 no-print">
          <div className="bg-slate-900 border border-slate-800 rounded-xl p-3 flex items-center justify-between text-xs">
            <div className="flex items-center gap-2">
              <span className="text-slate-400">رمز TLV Base64 QR:</span>
              <code className="text-emerald-400 font-mono text-[11px]">
                {tlvQrCode ? `${tlvQrCode.substring(0, 45)}...` : 'N/A'}
              </code>
            </div>
            <span className="text-[10px] bg-emerald-500/10 text-emerald-400 border border-emerald-500/30 px-2 py-0.5 rounded">
              UBL 2.1 ISO/IEC 19845
            </span>
          </div>

          <div className="bg-slate-950 border border-slate-800 rounded-xl p-4 font-mono text-xs overflow-x-auto text-emerald-300 max-h-[550px]">
            <pre className="whitespace-pre-wrap">{rawXml || '<!-- لم يتم توليد XML بعد -->'}</pre>
          </div>
        </div>
      )}

      {/* VIEW 2: Visual Invoice Card (Printable) */}
      {viewMode === 'preview' && (
        <div className="printable-invoice-wrapper">
          <div className="printable-invoice-card bg-slate-900 border border-slate-800 rounded-2xl shadow-xl overflow-hidden p-6 md:p-8 space-y-6 text-slate-100">
            {/* Top National Header */}
            <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4 border-b border-slate-800 pb-6">
              <div className="space-y-1">
                <div className="flex items-center gap-2">
                  <span className="text-xl">🇯🇴</span>
                  <span className="text-xs font-bold text-slate-300 tracking-wider">
                    المملكة الأردنية الهاشمية - دائرة ضريبة الدخل والمبيعات (ISTD)
                  </span>
                </div>
                <h2 className="text-xl md:text-2xl font-black text-white flex items-center gap-2">
                  <span>{CLINIC_CONFIG.name}</span>
                </h2>
                <p className="text-xs text-slate-400 flex flex-wrap items-center gap-2">
                  <span>{CLINIC_CONFIG.address}</span>
                  <span>•</span>
                  <span>هاتف: {CLINIC_CONFIG.phone}</span>
                  <span>•</span>
                  <span>رخصة: {CLINIC_CONFIG.licenseNumber}</span>
                </p>
              </div>

              {/* Invoice Type Badge */}
              <div className="text-left md:text-left self-stretch md:self-auto flex flex-col items-start md:items-end justify-center bg-slate-950/70 border border-slate-800 p-3 rounded-xl min-w-[200px]">
                <div className="flex items-center gap-1.5 text-xs font-bold text-emerald-400 mb-1">
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  <span>
                    {isB2B
                      ? 'فاتورة ضريبية عامة معتمدة (B2B)'
                      : 'فاتورة ضريبية مبسطة (B2C)'}
                  </span>
                </div>
                <div className="text-[11px] font-mono text-slate-300">
                  <span className="text-slate-400">رقم الفاتورة: </span>
                  <span className="font-bold text-white">{invoiceNumber}</span>
                </div>
                <div className="text-[10px] font-mono text-slate-400">
                  <span>الرقم الضريبي للمركز (TIN): </span>
                  <span className="text-emerald-400 font-semibold">{CLINIC_CONFIG.taxNumber}</span>
                </div>
              </div>
            </div>

            {/* Invoice Meta Grid */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 bg-slate-950/50 p-4 rounded-xl border border-slate-800/80 text-xs">
              <div>
                <span className="text-slate-400 block mb-0.5 flex items-center gap-1">
                  <Calendar className="w-3 h-3 text-slate-400" />
                  تاريخ الإصدار:
                </span>
                <span className="font-semibold text-white font-mono">{issueDate}</span>
              </div>
              <div>
                <span className="text-slate-400 block mb-0.5 flex items-center gap-1">
                  <Clock className="w-3 h-3 text-slate-400" />
                  وقت الإصدار:
                </span>
                <span className="font-semibold text-white font-mono">{issueTime}</span>
              </div>
              <div>
                <span className="text-slate-400 block mb-0.5 flex items-center gap-1">
                  <User className="w-3 h-3 text-slate-400" />
                  العميل / المشتري:
                </span>
                <span className="font-semibold text-white truncate block">{buyerName}</span>
              </div>
              <div>
                <span className="text-slate-400 block mb-0.5 flex items-center gap-1">
                  <Hash className="w-3 h-3 text-slate-400" />
                  {isB2B ? 'الرقم الضريبي للمشتري:' : 'الرقم الوطني / الهوية:'}
                </span>
                <span className="font-semibold text-white font-mono">
                  {buyerTaxId || buyerNationalId || 'غير محدد (نقدي)'}
                </span>
              </div>
            </div>

            {/* Line Items Table */}
            <div className="border border-slate-800 rounded-xl overflow-hidden bg-slate-950/40">
              <table className="w-full text-right text-xs">
                <thead className="bg-slate-950 text-slate-300 font-bold border-b border-slate-800">
                  <tr>
                    <th className="p-3 w-10 text-center">#</th>
                    <th className="p-3">الإجراء الطبي / الخدمة</th>
                    <th className="p-3 text-center w-16">الكمية</th>
                    <th className="p-3 text-left w-24">السعر (د.أ)</th>
                    <th className="p-3 text-left w-24">الضريبة</th>
                    <th className="p-3 text-left w-28">الإجمالي (د.أ)</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800 text-slate-200">
                  {parsedItems.map((item, idx) => (
                    <tr key={idx} className="hover:bg-slate-800/30">
                      <td className="p-3 text-center text-slate-400 font-mono">{idx + 1}</td>
                      <td className="p-3 font-medium text-white">{item.name}</td>
                      <td className="p-3 text-center font-mono">{item.quantity}</td>
                      <td className="p-3 text-left font-mono">{item.unitPrice.toFixed(3)}</td>
                      <td className="p-3 text-left font-mono">
                        {item.taxRate > 0 ? `${(item.taxRate * 100).toFixed(0)}%` : 'معفى 0%'}
                      </td>
                      <td className="p-3 text-left font-mono font-bold text-white">
                        {item.total.toFixed(3)}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            {/* Financial Summary & QR Code Section */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 items-center pt-2">
              {/* QR Code & Cryptographic Seals */}
              <div className="flex items-center gap-4 bg-slate-950/60 p-4 rounded-xl border border-slate-800">
                <div className="bg-white p-2 rounded-lg shadow-md flex-shrink-0">
                  {qrCodeDataUrl ? (
                    <img
                      src={qrCodeDataUrl}
                      alt="JoFotara TLV QR Code"
                      className="w-28 h-28 object-contain"
                    />
                  ) : (
                    <div className="w-28 h-28 flex items-center justify-center text-slate-400 text-[10px] text-center">
                      <QrCode className="w-8 h-8 mb-1 opacity-50" />
                    </div>
                  )}
                </div>

                <div className="space-y-1.5 text-[11px] leading-relaxed">
                  <div className="flex items-center gap-1 text-emerald-400 font-bold">
                    <ShieldCheck className="w-3.5 h-3.5" />
                    <span>رمز الاستجابة السريعة (TLV Base64 QR)</span>
                  </div>
                  <p className="text-slate-400 text-[10px]">
                    مشفر وفق اشتراطات الفوترة الإلكترونية الأردنية JoFotara (محددات التاج من 1 إلى 5).
                  </p>
                  <div className="font-mono text-[9px] text-slate-400 bg-slate-900 px-2 py-1 rounded border border-slate-800 truncate max-w-[200px]">
                    UUID: {uuid}
                  </div>
                </div>
              </div>

              {/* Totals Box */}
              <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 space-y-2 text-xs">
                <div className="flex justify-between text-slate-400">
                  <span>المجموع الخاضع للضريبة (Subtotal):</span>
                  <span className="font-mono font-semibold text-white">
                    {subtotalVal.toFixed(3)} دينار
                  </span>
                </div>
                <div className="flex justify-between text-slate-400">
                  <span>ضريبة المبيعات العامة (VAT 16%):</span>
                  <span className="font-mono font-semibold text-white">
                    {taxAmountVal.toFixed(3)} دينار
                  </span>
                </div>
                <div className="border-t border-slate-800 pt-2 flex justify-between items-center">
                  <span className="font-bold text-sm text-white">المجموع الإجمالي الكلي (Total):</span>
                  <span className="font-bold text-base md:text-lg text-emerald-400 font-mono">
                    {totalAmountVal.toFixed(3)} د.أ
                  </span>
                </div>
              </div>
            </div>

            {/* Tamper-Proof SHA-256 Hash Chaining Footer */}
            <div className="border-t border-slate-800/80 pt-4 flex flex-col md:flex-row items-start md:items-center justify-between gap-2 text-[10px] text-slate-400 font-mono">
              <div className="flex items-center gap-2 truncate max-w-full">
                <span className="text-slate-400">SHA-256 Chaining Hash:</span>
                <span className="text-slate-300 truncate max-w-[280px] md:max-w-[400px]">
                  {invoiceHash}
                </span>
                <button
                  onClick={handleCopyHash}
                  className="text-slate-400 hover:text-white p-1 rounded transition no-print"
                  title="نسخ الهاش"
                >
                  {copiedHash ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                </button>
              </div>
              <div className="text-left md:text-left text-slate-400">
                <span>تخضع لأحكام قانون ضريبة الدخل رقم 34 لعام 2014 ونظام الفوترة الوطني</span>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

```

---

## <a id="lib-ai-clinic-tools-ts"></a>📁 `lib/ai/clinic-tools.ts`

```typescript
// File: lib/ai/clinic-tools.ts
// NashmiOps Enterprise (MVP Edition) - Clinic AI Tools & Multi-Person Booking Engine

import { Type } from '@google/genai';
import { CLINIC_CONFIG, CLINICAL_SERVICES, MEDICAL_LIABILITY_GUARDRAILS } from '@/lib/config/constants';
import { tenantStore, updateAppointmentStatus, addToWaitlist, saveInvoice, queryClinicFaq, supabase } from '@/lib/db/supabase';
import { bookFrictionlessAppointment, checkSlotAvailability } from '@/lib/calendar/scheduler';
import { triggerWaitlistSniper } from '@/lib/jobs/waitlist-sniper';
import { compileJoFotaraXML } from '@/lib/jofotara/xml-compiler';
import { submitInvoiceToJoFotara } from '@/lib/jofotara/client';
import { ServiceType, InvoiceType } from '@/types';

/**
 * Validate and normalize Jordanian Mobile Phone Numbers
 * Formats: 079XXXXXXX, 078XXXXXXX, 077XXXXXXX, or +9627XXXXXXXX
 */
export function validateJordanianPhone(
  phoneInput?: string,
  allowSandboxDefault = true
): { isValid: boolean; normalizedPhone?: string; error?: string } {
  if (!phoneInput || !phoneInput.trim()) {
    return {
      isValid: false,
      error: 'يرجى تزويدنا برقم هاتفك النقال لنتمكن من تثبيت الموعد وإرسال التأكيد.',
    };
  }

  const clean = phoneInput.trim().replace(/[\s\-\(\)]/g, '');

  // Sandbox simulation number is permitted
  if (clean === '+962791234567' || clean === '0791234567' || clean === '962791234567') {
    if (allowSandboxDefault) {
      return { isValid: true, normalizedPhone: '+962791234567' };
    }
  }

  // Jordanian mobile patterns:
  const jordanRegex = /^(?:\+?962|0)?(7[789]\d{7})$/;
  const match = clean.match(jordanRegex);
  if (match) {
    return { isValid: true, normalizedPhone: `+962${match[1]}` };
  }

  return {
    isValid: false,
    error: 'يرجى تزويدنا برقم هاتف خلوي أردني صالح (مثل 079XXXXXXX أو 078XXXXXXX أو 077XXXXXXX) لنتمكن من التواصل وتأكيد الموعد.',
  };
}

/**
 * Declarations of Gemini Tools
 */
export const clinicTools = [
  {
    name: 'check_calendar',
    description: 'فحص الأوقات والمواعيد الشاغرة لموعد في مركز نشمي في يوم معين (مثل الأحد أو غداً أو تاريخ محدد) مع مراعاة فترة التعقيم الإلزامية 15 دقيقة',
    parameters: {
      type: Type.OBJECT,
      properties: {
        preferred_date: { type: Type.STRING, description: 'التاريخ أو اليوم المطلوب (مثلاً: الأحد، 2026-09-27، غداً، اليوم)' },
        service_type: {
          type: Type.STRING,
          enum: ['consultation', 'cleaning', 'restoration', 'extraction', 'emergency', 'whitening', 'orthodontics_check'],
          description: 'نوع الخدمة المطلوبة إن وجدت (افتراضياً: consultation)',
        },
      },
      required: ['preferred_date'],
    },
  },
  {
    name: 'check_calendar_availability',
    description: 'فحص الأوقات والمواعيد الشاغرة لموعد في مركز نشمي في يوم معين مع مراعاة فترة التعقيم الإلزامية 15 دقيقة (مرادف لـ check_calendar)',
    parameters: {
      type: Type.OBJECT,
      properties: {
        preferred_date: { type: Type.STRING, description: 'التاريخ أو اليوم المطلوب (مثلاً: الأحد، 2026-09-27، غداً، اليوم)' },
        service_type: {
          type: Type.STRING,
          enum: ['consultation', 'cleaning', 'restoration', 'extraction', 'emergency', 'whitening', 'orthodontics_check'],
          description: 'نوع الخدمة المطلوبة إن وجدت (افتراضياً: consultation)',
        },
      },
      required: ['preferred_date'],
    },
  },
  {
    name: 'query_faq',
    description: 'استعلام قاعدة معلومات المركز عن أوقات الدوام، ساعات العمل، الموقع والمواقف والفاليه، أسعار العلاجات والكشفية، وشبكات التأمين المعتمدة',
    parameters: {
      type: Type.OBJECT,
      properties: {
        query: {
          type: Type.STRING,
          description: 'السؤال أو الموضوع المراد الاستفسار عنه (مثل: الدوام، ساعات العمل، الموقع، المواقف، الأسعار، التأمين، الخدمات)',
        },
        category: {
          type: Type.STRING,
          enum: ['hours', 'location', 'pricing', 'insurance', 'services', 'general'],
          description: 'تصنيف الاستفسار إن توفر',
        },
      },
      required: ['query'],
    },
  },
  {
    name: 'create_appointment',
    description: 'تأكيد وحجز موعد المريض أو حجز مشترك للمرافقين والعائلة في المركز مع تزويد المريض برابط الموقع في الشميساني والاصطفاف المجاني والفاليه مع دعم تسجيل الأسماء المتعددة والمواعيد المتتابعة',
    parameters: {
      type: Type.OBJECT,
      properties: {
        patient_name: { type: Type.STRING, description: 'اسم المريض الرئيسي أو الأول' },
        patientName: { type: Type.STRING, description: 'اسم المريض الرئيسي (صيغة بديلة)' },
        companion_name: { type: Type.STRING, description: 'اسم المرافق أو القريب في حال الحجز لشخصين' },
        companionName: { type: Type.STRING, description: 'اسم المرافق أو القريب (صيغة بديلة)' },
        patients: {
          type: Type.ARRAY,
          items: { type: Type.STRING },
          description: 'مصفوفة بأسماء جميع المرضى إذا كان الحجز جماعياً أو لأكثر من شخص (مثل: ["أحمد قاسم", "محمد قاسم"])',
        },
        patient_phone: { type: Type.STRING, description: 'رقم هاتف المريض أو الواتساب (اختياري)' },
        date_str: { type: Type.STRING, description: 'تاريخ الموعد YYYY-MM-DD أو اليوم أو بكرا' },
        time_str: { type: Type.STRING, description: 'وقت الموعد بصيغة HH:mm مثل 11:30 أو 16:30' },
        service_type: {
          type: Type.STRING,
          enum: ['consultation', 'cleaning', 'restoration', 'extraction', 'emergency', 'whitening', 'orthodontics_check'],
          description: 'نوع الإجراء الطبي',
        },
        family_relation: {
          type: Type.STRING,
          enum: ['self', 'child', 'spouse', 'parent', 'companion'],
          description: 'صلة القرابة إذا كان الحجز لأحد أفراد العائلة أو مرافق',
        },
        notes: { type: Type.STRING, description: 'أي ملاحظات إضافية' },
      },
      required: ['patient_name', 'time_str'],
    },
  },
  {
    name: 'book_appointment',
    description: 'تأكيد حجز موعد المريض أو المرافقين (مرادف لـ create_appointment)',
    parameters: {
      type: Type.OBJECT,
      properties: {
        patient_name: { type: Type.STRING, description: 'اسم المريض الكامل الحقيقي الصريح (مطلوب إلزامياً)' },
        patientName: { type: Type.STRING, description: 'اسم المريض' },
        companion_name: { type: Type.STRING, description: 'اسم المرافق أو القريب' },
        companionName: { type: Type.STRING, description: 'اسم المرافق' },
        patients: {
          type: Type.ARRAY,
          items: { type: Type.STRING },
          description: 'مصفوفة أسماء المرضى للحجز المشترك',
        },
        patient_phone: { type: Type.STRING, description: 'رقم هاتف المريض أو رقم الواتساب' },
        service_type: {
          type: Type.STRING,
          enum: ['consultation', 'cleaning', 'restoration', 'extraction', 'emergency', 'whitening', 'orthodontics_check'],
          description: 'نوع الإجراء الطبي',
        },
        date_str: { type: Type.STRING, description: 'تاريخ الموعد YYYY-MM-DD أو اليوم' },
        time_str: { type: Type.STRING, description: 'وقت الموعد بصيغة HH:mm مثل 11:00 أو 16:30' },
        family_relation: {
          type: Type.STRING,
          enum: ['self', 'child', 'spouse', 'parent', 'companion'],
          description: 'صلة القرابة إذا كان الحجز لأحد أفراد العائلة',
        },
        notes: { type: Type.STRING, description: 'أي ملاحظات إضافية' },
      },
      required: ['patient_name', 'time_str'],
    },
  },
  {
    name: 'verify_insurance_card',
    description: 'التحقق من اعتماد شبكة التأمين الصحي ونسبة التغطية (نات هيلث، ميدنت، الشرق العربي، GIG)',
    parameters: {
      type: Type.OBJECT,
      properties: {
        insurance_company: { type: Type.STRING, description: 'اسم شبكة التأمين مثل نات هيلث، ميدنت، الشرق العربي، GIG' },
        patient_name: { type: Type.STRING, description: 'اسم حامل البطاقة' },
        card_number: { type: Type.STRING, description: 'رقم البطاقة إن توفر' },
      },
      required: ['insurance_company'],
    },
  },
  {
    name: 'cancel_appointment',
    description: 'إلغاء موعد المريض المسجل وتشغيل قناص قائمة الانتظار فوراً لشغل الشاغر. يمكن استدعاؤها برقم هاتف المريض أو تاريخ الموعد أو معرف الموعد',
    parameters: {
      type: Type.OBJECT,
      properties: {
        appointment_id: { type: Type.STRING, description: 'معرف الموعد إذا كان معروفاً' },
        patient_phone: { type: Type.STRING, description: 'رقم هاتف المريض صاحب الموعد (اختياري)' },
        target_date: { type: Type.STRING, description: 'تاريخ الموعد المراد إلغاؤه (مثل: بكرة، غداً، اليوم، الأحد، أو تاريخ محدد)' },
        reason: { type: Type.STRING, description: 'سبب الإلغاء إن وجد' },
      },
    },
  },
  {
    name: 'reschedule_appointment',
    description: 'تعديل وتأجيل موعد المريض إلى وقت أو تاريخ جديد شاغر',
    parameters: {
      type: Type.OBJECT,
      properties: {
        patient_phone: { type: Type.STRING, description: 'رقم هاتف المريض' },
        patient_name: { type: Type.STRING, description: 'اسم المريض' },
        new_date: { type: Type.STRING, description: 'التاريخ الجديد YYYY-MM-DD' },
        new_time: { type: Type.STRING, description: 'الوقت الجديد HH:mm' },
      },
      required: ['new_date', 'new_time'],
    },
  },
  {
    name: 'join_waitlist',
    description: 'إضافة المريض إلى قائمة الانتظار الذكية ليتم قنص وتوفير أي شاغر مبكر له تلقائياً',
    parameters: {
      type: Type.OBJECT,
      properties: {
        patient_name: { type: Type.STRING, description: 'اسم المريض' },
        patient_phone: { type: Type.STRING, description: 'رقم هاتف المريض' },
        requested_service: {
          type: Type.STRING,
          enum: ['consultation', 'cleaning', 'restoration', 'extraction', 'emergency', 'whitening', 'orthodontics_check'],
          description: 'الخدمة المطلوبة',
        },
        preferred_date: { type: Type.STRING, description: 'التاريخ المفضل YYYY-MM-DD' },
        preferred_time_range: {
          type: Type.STRING,
          enum: ['morning', 'afternoon', 'any'],
          description: 'الفترة المفضلة',
        },
      },
      required: ['patient_name', 'patient_phone', 'requested_service', 'preferred_date'],
    },
  },
  {
    name: 'generate_jofotara_invoice',
    description: 'إصدار فاتورة إلكترونية معتمدة لضريبة الدخل والمبيعات الأردنية (JoFotara Phase 2 UBL 2.1)',
    parameters: {
      type: Type.OBJECT,
      properties: {
        patient_name: { type: Type.STRING, description: 'اسم المريض أو الشركة' },
        invoice_type: {
          type: Type.STRING,
          enum: ['B2C_SIMPLIFIED', 'B2B_STANDARD'],
          description: 'نوع الفاتورة: ضريبية مبسطة للأفراد أقل من 100 دينار أو عادية للشركات',
        },
        buyer_tax_id: { type: Type.STRING, description: 'الرقم الضريبي للمشتري (إلزامي في B2B_STANDARD)' },
        buyer_national_id: { type: Type.STRING, description: 'الرقم الوطني للمريض (اختياري للأفراد)' },
        service_name: { type: Type.STRING, description: 'اسم الإجراء الطبي' },
        amount_jod: { type: Type.NUMBER, description: 'المبلغ الإجمالي بالدينار الأردني' },
      },
      required: ['patient_name', 'invoice_type', 'service_name', 'amount_jod'],
    },
  },
  {
    name: 'trigger_emergency_handover',
    description: 'تفعيل بروتوكول طوارئ المسؤولية الطبية رقم 25 لتحويل فوري لطبيب الطوارئ المناوب',
    parameters: {
      type: Type.OBJECT,
      properties: {
        patient_name: { type: Type.STRING, description: 'اسم المريض' },
        patient_phone: { type: Type.STRING, description: 'رقم هاتف المريض' },
        symptoms: { type: Type.STRING, description: 'الأعراض الحادة مثل نزيف مستمر أو ورم حاد بالوجه' },
      },
      required: ['patient_name', 'symptoms'],
    },
  },
];

/**
 * Compare phone numbers with tolerance for country codes (+962, 07, etc.)
 */
export function phonesMatch(p1?: string, p2?: string): boolean {
  if (!p1 || !p2) return false;
  const digits1 = p1.replace(/\D/g, '');
  const digits2 = p2.replace(/\D/g, '');
  if (digits1 === digits2) return true;
  const s1 = digits1.slice(-8);
  const s2 = digits2.slice(-8);
  return s1.length >= 7 && s1 === s2;
}

/**
 * Execute Tool Calls invoked by Gemini
 */
export async function executeClinicTool(name: string, args: any, defaultPhone: string = '+962791234567'): Promise<any> {
  try {
    const clinicId = CLINIC_CONFIG.id;
    const phone = args?.patient_phone || defaultPhone;

    switch (name) {
      case 'query_faq': {
        const queryText = args?.query || args?.question || args?.category || '';
        const faqs = await queryClinicFaq(clinicId, queryText);
        if (faqs.length === 0) {
          return {
            status: 'ok',
            found: false,
            message: 'مركز نشمي لطب وجراحة الأسنان في الشميساني - مقابل المستشفى التخصصي. دوامنا من السبت للخميس من 9 صباحاً إلى 9 مساءً، هاتف العيادة: 0791234567.',
          };
        }
        return {
          status: 'ok',
          found: true,
          count: faqs.length,
          faq_items: faqs.map((f) => ({
            category: f.category,
            question: f.question_ar,
            answer: f.answer_ar,
          })),
          summary: faqs.map((f) => f.answer_ar).join('\n'),
        };
      }

      case 'check_calendar':
      case 'check_calendar_availability':
      case 'check_availability': {
        let targetDate = args?.preferred_date || 'اليوم';
        const now = new Date();

      if (targetDate.includes('احد') || targetDate.includes('الأحد') || targetDate.toLowerCase().includes('sunday')) {
        const day = now.getDay();
        const diff = (7 - day) % 7 || 7;
        const nextSunday = new Date(now.getTime() + diff * 86400000);
        targetDate = nextSunday.toISOString().split('T')[0];
      } else if (targetDate.includes('جمعة') || targetDate.includes('الجمعة') || targetDate.toLowerCase().includes('friday')) {
        const diff = (5 - now.getDay() + 7) % 7 || 7;
        const nextFriday = new Date(now.getTime() + diff * 86400000);
        targetDate = nextFriday.toISOString().split('T')[0];
      } else if (targetDate.includes('سبت') || targetDate.includes('السبت') || targetDate.toLowerCase().includes('saturday')) {
        const diff = (6 - now.getDay() + 7) % 7 || 7;
        const nextSaturday = new Date(now.getTime() + diff * 86400000);
        targetDate = nextSaturday.toISOString().split('T')[0];
      } else if (targetDate.includes('غد') || targetDate.includes('بكرة') || targetDate.includes('بكرا') || targetDate.toLowerCase().includes('tomorrow')) {
        const tomorrow = new Date(now.getTime() + 86400000);
        targetDate = tomorrow.toISOString().split('T')[0];
      } else if (targetDate.includes('يوم') || targetDate.toLowerCase().includes('today')) {
        targetDate = now.toISOString().split('T')[0];
      }

      // Check if target date is Friday (Weekly closure)
      const requestedDateObj = new Date(targetDate);
      if (requestedDateObj.getDay() === 5) {
        return {
          date: targetDate,
          available: false,
          available_slots: [],
          is_friday_closed: true,
          message: 'يوم الجمعة عطلة أسبوعية رسمية في مركز نشمي لطب وجراحة الأسنان. دوامنا من السبت إلى الخميس (09:00 ص - 08:00 م). بإمكاننا حجزك يوم السبت أو الأحد القادم.',
        };
      }

      // Check available slots within official working hours (09:00 - 20:00)
      const candidateTimes = ['10:00', '11:30', '14:00', '16:30', '18:00'];
      const availableTimes: string[] = [];

      for (const time of candidateTimes) {
        const [h, m] = time.split(':').map(Number);
        const start = new Date(targetDate);
        start.setHours(h, m, 0, 0);
        const endWithBuffer = new Date(start.getTime() + 60 * 60 * 1000); // 45m + 15m buffer

        const res = await checkSlotAvailability(clinicId, start, endWithBuffer);
        if (res.available) {
          availableTimes.push(time);
        }
      }

      return {
        date: targetDate,
        service: args.service_type || 'consultation',
        available_slots: availableTimes,
        working_hours: 'من السبت إلى الخميس: 09:00 صباحاً - 08:00 مساءً (الجمعة عطلة)',
        sterilization_buffer_enforced: '15 دقيقة تعقيم بعد كل موعد',
        message: `المواعيد الشاغرة ليوم (${targetDate}) هي: ${availableTimes.join('، ')}.`,
      };
    }

    case 'create_appointment':
    case 'book_appointment':
    case 'book_appointment_frictionless': {
      let dateFormatted = args.date_str;
      const now = new Date();
      if (dateFormatted?.includes('احد') || dateFormatted?.includes('الأحد')) {
        const diff = (7 - now.getDay()) % 7 || 7;
        dateFormatted = new Date(now.getTime() + diff * 86400000).toISOString().split('T')[0];
      } else if (dateFormatted?.includes('جمعة') || dateFormatted?.includes('الجمعة')) {
        const diff = (5 - now.getDay() + 7) % 7 || 7;
        dateFormatted = new Date(now.getTime() + diff * 86400000).toISOString().split('T')[0];
      } else if (dateFormatted?.includes('سبت') || dateFormatted?.includes('السبت')) {
        const diff = (6 - now.getDay() + 7) % 7 || 7;
        dateFormatted = new Date(now.getTime() + diff * 86400000).toISOString().split('T')[0];
      } else if (dateFormatted?.includes('غد') || dateFormatted?.includes('بكرة') || dateFormatted?.includes('بكرا')) {
        dateFormatted = new Date(now.getTime() + 86400000).toISOString().split('T')[0];
      } else if (dateFormatted?.includes('يوم') || dateFormatted?.includes('اليوم')) {
        dateFormatted = now.toISOString().split('T')[0];
      }

      const baseDateStr = dateFormatted || now.toISOString().split('T')[0];
      const baseTimeStr = args.time_str || '11:30';

      // 1. Gather all patient names (Family / Companion / Multi-Person detection)
      const patientNames: string[] = [];

      if (Array.isArray(args.patients) && args.patients.length > 0) {
        for (const p of args.patients) {
          const trimmed = String(p).trim();
          if (trimmed && !patientNames.includes(trimmed)) {
            patientNames.push(trimmed);
          }
        }
      }

      const primaryName = (args.patient_name || args.patientName || '').trim();
      if (primaryName && !patientNames.includes(primaryName)) {
        patientNames.unshift(primaryName);
      }

      const companionName = (args.companion_name || args.companionName || '').trim();
      if (companionName && !patientNames.includes(companionName)) {
        patientNames.push(companionName);
      }

      // Mandatory Patient Name Rule: Strictly reject booking without real explicit patient names!
      const isPlaceholderOrEmpty = (name: string) => {
        const lower = name.toLowerCase().trim();
        const placeholderList = [
          'مريض نشمي', 'مريض', 'المريض', 'غير محدد', 'unknown', 'patient', 'user',
          'صاحب الرقم', 'مرافق', 'المرافق', 'قريبي', 'قريبك', 'القريب', 'صاحبي', 'صديقي',
          'أخوي', 'اخوي', 'الأخ', 'زوجتي', 'زوجي', 'ابني', 'بنتي', 'والدي', 'والدتي',
          'أنا', 'انا', 'نحن', 'احنا', 'إلي', 'الي', 'لي'
        ];
        return (
          !lower ||
          placeholderList.includes(lower) ||
          lower.length < 2
        );
      };

      const validPatientNames = patientNames.filter((n) => !isPlaceholderOrEmpty(n));

      // Multi-person request detection (e.g. user or tool noted multiple persons/companion)
      const isMultiPersonRequest =
        Boolean(args.companion_name || args.companionName) ||
        (Array.isArray(args.patients) && args.patients.length > 1) ||
        args.family_relation === 'companion' ||
        (args.notes && (args.notes.includes('شخصين') || args.notes.includes('قريب') || args.notes.includes('مرافق') || args.notes.includes('مع بعض')));

      if (isMultiPersonRequest && validPatientNames.length < 2) {
        return {
          success: false,
          error: 'MISSING_COMPANION_NAMES',
          requires_patient_name: true,
          message: 'تمام! بس اعطيني اسمك الكريم واسم قريبك/المرافق عشان أثبتلكم المواعيد فوراً.',
          guidance: 'المريض طلب حجزاً لشخصين أو له ولقريبه، ولم يذكر أسماء الجميع بصراحة. اطلب اسْميهما الصريحين فوراً: "تمام! بس اعطيني اسمك الكريم واسم قريبك/المرافق عشان أثبتلكم المواعيد فوراً".',
        };
      }

      if (validPatientNames.length === 0) {
        return {
          success: false,
          error: 'MISSING_MANDATORY_PATIENT_NAME',
          requires_patient_name: true,
          message: 'تمام! بس اعطيني اسمك الكريم عشان أثبتلك الموعد فوراً.',
          guidance: 'المريض لم يذكر اسمه الصريح بعد. لا تؤكد الحجز ولا تستدعِ الأداة بدون اسمه. رد عليه حصراً: "تمام! بس اعطيني اسمك الكريم عشان أثبتلك الموعد فوراً".',
        };
      }

      // Phone number validation per Pillar 5
      const rawTargetPhone = (args.patient_phone || phone || '').trim();
      const phoneValidation = validateJordanianPhone(rawTargetPhone, true);
      const cleanBookingPhone = phoneValidation.isValid ? phoneValidation.normalizedPhone! : (rawTargetPhone || '+962791234567');

      // 2. Handle Multi-Person Bookings (Consecutive Appointments)
      if (validPatientNames.length > 1) {
        console.log(`[Multi-Person Booking] Pre-checking consecutive slots for ${validPatientNames.length} patients:`, validPatientNames);

        // Pre-check ALL consecutive slots to guarantee both/all are available before confirming
        const slotTimes: string[] = [];
        let testSlotTime = baseTimeStr;

        for (let i = 0; i < validPatientNames.length; i++) {
          const [h, m] = testSlotTime.split(':').map(Number);
          const sDate = new Date(baseDateStr);
          sDate.setHours(h, m, 0, 0);
          const sEnd = new Date(sDate.getTime() + 60 * 60 * 1000); // 45m + 15m sterilization

          const check = await checkSlotAvailability(clinicId, sDate, sEnd);
          if (!check.available) {
            return {
              success: false,
              conflict: true,
              conflicted_slot: testSlotTime,
              conflicted_patient: validPatientNames[i],
              message: `عذراً، موعد المرافق (${validPatientNames[i]}) الساعة (${testSlotTime}) غير متاح حالياً لوجود حجز مسبق. بإمكاننا حجزكما بأوقات متتابعة أخرى، هل يناسبكما غداً الساعة 14:00 أو 16:30؟`,
            };
          }

          slotTimes.push(testSlotTime);

          // Calculate next slot time (+60 min)
          const nextSlotObj = new Date(sDate.getTime() + 60 * 60 * 1000);
          const nextH = String(nextSlotObj.getHours()).padStart(2, '0');
          const nextM = String(nextSlotObj.getMinutes()).padStart(2, '0');
          testSlotTime = `${nextH}:${nextM}`;
        }

        // All slots verified available! Proceed to book them:
        const bookedAppointments: Array<{
          patientName: string;
          timeStr: string;
          appointmentId?: string;
          scheduledStart?: string;
        }> = [];

        for (let i = 0; i < validPatientNames.length; i++) {
          const currentPatient = validPatientNames[i];
          const isCompanion = i > 0;
          const currentSlotTime = slotTimes[i];

          const singleResult = await bookFrictionlessAppointment({
            clinicId,
            phone: cleanBookingPhone,
            patientName: currentPatient,
            serviceType: (args.service_type || 'consultation') as ServiceType,
            dateStr: baseDateStr,
            timeStr: currentSlotTime,
            familyRelation: isCompanion ? (args.family_relation || 'companion') : 'self',
            notes: isCompanion ? `مرافق مع ${validPatientNames[0]}` : args.notes,
          });

          if (!singleResult.success) {
            return {
              success: false,
              conflict: true,
              conflictDetails: singleResult.conflictDetails,
              message: singleResult.message || `عذراً، حدث تعارض في حجز موعد (${currentPatient}). هل يناسبكم وقت آخر؟`,
            };
          }

          bookedAppointments.push({
            patientName: currentPatient,
            timeStr: currentSlotTime,
            appointmentId: singleResult.appointment?.id,
            scheduledStart: singleResult.appointment?.start_time,
          });
        }

        const summaryItems = bookedAppointments
          .map((b) => `${b.patientName} (الساعة ${b.timeStr})`)
          .join('، و');

        return {
          success: true,
          multi_person_booking: true,
          total_patients: bookedAppointments.length,
          booked_patients: bookedAppointments.map((b) => ({
            name: b.patientName,
            time: b.timeStr,
            appointment_id: b.appointmentId,
            scheduled_start: b.scheduledStart,
          })),
          location_address: 'الشميساني، عمان - متوفر مواقف مجانية وخدمة فاليه لراحة المرضى',
          google_maps_link: 'https://maps.google.com/?q=Amman+Shmeisani+Nashmi+Dental',
          message: `يا هلا بك، تم تثبيت الموعدين المتتابعين تمام: ${summaryItems}، بانتظاركم وتنورونا! الموقع: الشميساني، عمان (متوفر مواقف مجانية وفاليه).`,
        };
      }

      // 3. Single Patient Booking
      const singlePatient = validPatientNames[0];
      const result = await bookFrictionlessAppointment({
        clinicId,
        phone: cleanBookingPhone,
        patientName: singlePatient,
        serviceType: (args.service_type || 'consultation') as ServiceType,
        dateStr: baseDateStr,
        timeStr: baseTimeStr,
        familyRelation: args.family_relation || 'self',
        notes: args.notes,
      });

      if (!result.success) {
        return {
          success: false,
          conflict: true,
          conflictDetails: result.conflictDetails,
          message: result.message || 'عذراً، هذا الموعد يتعارض مع موعد محجوز مسبقاً (شاملاً فترة التعقيم الإلزامية 15 دقيقة). هل يناسبك وقت آخر مثل 14:00 أو 16:30؟',
        };
      }

      return {
        success: true,
        appointment_id: result.appointment?.id,
        scheduled_start: result.appointment?.start_time,
        sterilization_end: result.appointment?.sterilization_end_time,
        status: 'CONFIRMED',
        location_address: 'الشميساني، عمان - متوفر مواقف مجانية وخدمة فاليه لراحة المرضى',
        google_maps_link: 'https://maps.google.com/?q=Amman+Shmeisani+Nashmi+Dental',
        message: 'يا هلا بك، تم تثبيت موعدك تمام، بانتظارك وتنورنا! الموقع: الشميساني، عمان (متوفر مواقف مجانية وفاليه).',
      };
    }

    case 'verify_insurance_card': {
      const company = args.insurance_company || 'شبكة معتمدة';
      return {
        success: true,
        approved_network: true,
        company,
        coverage_summary: 'الشبكة معتمدة بمركز نشمي (نات هيلث، ميدنت، الشرق العربي، GIG) بنسبة تغطية 80% إلى 100%',
        message: `تم التحقق: شبكة (${company}) معتمدة رسمياً بمركز نشمي في الشميساني. بإمكانك تشرفنا بالبطاقة للاستفادة من التغطية مباشرة.`,
      };
    }

    case 'cancel_appointment': {
      // 1. Resolve target date if mentioned (e.g., 'بكرة', 'غداً', 'اليوم')
      let targetDatePrefix: string | undefined;
      const rawTargetDate = (args.target_date || '').toLowerCase();
      const now = new Date();
      if (rawTargetDate.includes('غد') || rawTargetDate.includes('بكرة') || rawTargetDate.includes('tomorrow')) {
        const tomorrow = new Date(now.getTime() + 86400000);
        targetDatePrefix = tomorrow.toISOString().split('T')[0];
      } else if (rawTargetDate.includes('يوم') || rawTargetDate.includes('today')) {
        targetDatePrefix = now.toISOString().split('T')[0];
      } else if (/\d{4}-\d{2}-\d{2}/.test(rawTargetDate)) {
        targetDatePrefix = rawTargetDate.match(/\d{4}-\d{2}-\d{2}/)?.[0];
      }

      // 2. Find matching appointments from in-memory store
      let candidateAppts = tenantStore.appointments.filter(
        (a) =>
          (a.status === 'CONFIRMED' || a.status === 'PENDING') &&
          ((args.appointment_id && a.id === args.appointment_id) || phonesMatch(a.patient_phone, phone))
      );

      // Fallback: check Supabase database if memory store doesn't have it
      if (candidateAppts.length === 0) {
        try {
          const { data } = await supabase
            .from('appointments')
            .select('*')
            .eq('clinic_id', clinicId)
            .in('status', ['CONFIRMED', 'PENDING']);
          if (data && data.length > 0) {
            for (const item of data) {
              if ((args.appointment_id && item.id === args.appointment_id) || phonesMatch(item.patient_phone, phone)) {
                candidateAppts.push(item as any);
                if (!tenantStore.appointments.find((x) => x.id === item.id)) {
                  tenantStore.appointments.push(item as any);
                }
              }
            }
          }
        } catch (dbErr) {
          console.warn('[cancel_appointment] Supabase lookup fallback note:', dbErr);
        }
      }

      let appt = targetDatePrefix
        ? candidateAppts.find((a) => a.start_time.startsWith(targetDatePrefix))
        : undefined;

      if (!appt && candidateAppts.length > 0) {
        // Pick nearest upcoming appointment
        candidateAppts.sort((a, b) => new Date(a.start_time).getTime() - new Date(b.start_time).getTime());
        appt = candidateAppts[0];
      }

      if (!appt) {
        return {
          success: false,
          found: false,
          message: 'لم يتم العثور على موعد مؤكد مسجل بهذا الرقم لإلغائه.',
        };
      }

      // 3. Mark appointment as CANCELLED
      await updateAppointmentStatus(appt.id, clinicId, 'CANCELLED');

      // 4. Asynchronous Sniper Trigger (Fire-and-forget: do NOT await to prevent WhatsApp webhook timeout)
      void triggerWaitlistSniper(appt).catch((sniperErr) => {
        console.error('[Waitlist Sniper Background Error]:', sniperErr);
      });

      return {
        success: true,
        cancelled_appointment_id: appt.id,
        patient_name: appt.patient_name,
        cancelled_date: appt.start_time,
        message: 'تم إلغاء الموعد بنجاح، وتم تشغيل قناص قائمة الانتظار في الخلفية لشغل الشاغر.',
      };
    }

    case 'reschedule_appointment': {
      const appt = tenantStore.appointments.find(
        (a) => (phonesMatch(a.patient_phone, phone) || a.patient_name === args.patient_name) && a.status === 'CONFIRMED'
      );

      if (!appt) {
        return {
          success: false,
          message: 'لم يتم العثور على موعد مسبق لتعديله. تفضل باختيار موعد جديد مباشرة.',
        };
      }

      await updateAppointmentStatus(appt.id, clinicId, 'CANCELLED');

      const newBookResult = await bookFrictionlessAppointment({
        clinicId,
        phone,
        patientName: args.patient_name || appt.patient_name,
        serviceType: appt.service_type,
        dateStr: args.new_date,
        timeStr: args.new_time,
      });

      return {
        success: newBookResult.success,
        old_appointment_id: appt.id,
        new_appointment_id: newBookResult.appointment?.id,
        message: `يا هلا بك، تم تعديل موعدك بنجاح إلى تاريخ ${args.new_date} الساعة ${args.new_time}. بانتظارك وتنورنا! الموقع: الشميساني، عمان (متوفر مواقف مجانية وفاليه).`,
      };
    }

    case 'join_waitlist': {
      const entry = await addToWaitlist({
        clinicId,
        patientId: `pat-${Date.now()}`,
        patientName: args.patient_name,
        patientPhone: phone,
        requestedService: (args.requested_service || 'consultation') as ServiceType,
        preferredDate: args.preferred_date || new Date().toISOString().split('T')[0],
        preferredTimeRange: args.preferred_time_range || 'any',
      });

      return {
        success: true,
        waitlist_id: entry.id,
        position: tenantStore.waitlist.filter((w) => w.status === 'WAITING').length,
        message: 'تمت إضافتك إلى قائمة الانتظار الذكية. سيصلك إشعار فوري على واتساب بمجرد توفر أي موعد مبكر.',
      };
    }

    case 'generate_jofotara_invoice': {
      const invNumber = `INV-2026-${Math.floor(1000 + Math.random() * 9000)}`;
      const invType = (args.invoice_type || 'B2C_SIMPLIFIED') as InvoiceType;
      const compileRes = compileJoFotaraXML({
        invoiceNumber: invNumber,
        invoiceType: invType,
        issueDate: new Date().toISOString().split('T')[0],
        issueTime: new Date().toTimeString().split(' ')[0],
        buyerName: args.patient_name || 'مريض نقدي',
        buyerTaxId: args.buyer_tax_id,
        buyerNationalId: args.buyer_national_id,
        items: [
          {
            name: args.service_name || 'كشف واستشارة طب أسنان',
            quantity: 1,
            unitPrice: args.amount_jod || 20,
            taxRate: 0.16,
            total: (args.amount_jod || 20) * 1.16,
          },
        ],
      });

      // Transmit to Jordanian ISTD JoFotara Network Gateway (B2C Reporting / B2B Clearance)
      const submission = await submitInvoiceToJoFotara({
        invoiceNumber: invNumber,
        invoiceType: invType,
        ublXml: compileRes.xml,
        invoiceUuid: compileRes.uuid,
        invoiceHash: compileRes.invoiceHash,
        buyerName: args.patient_name || 'مريض نقدي',
        buyerTaxId: args.buyer_tax_id,
        totalAmount: compileRes.totalAmount,
      });

      const invoiceRecord = await saveInvoice({
        id: `inv-${Date.now()}`,
        clinic_id: clinicId,
        invoice_number: invNumber,
        invoice_type: invType,
        buyer_name: args.patient_name || 'مريض نقدي',
        buyer_tax_id: args.buyer_tax_id,
        buyer_national_id: args.buyer_national_id,
        currency: 'JOD',
        subtotal: compileRes.subtotal,
        tax_amount: compileRes.taxAmount,
        total_amount: compileRes.totalAmount,
        invoice_uuid: compileRes.uuid,
        previous_invoice_hash: compileRes.pih,
        invoice_hash: compileRes.invoiceHash,
        qr_code_tlv: compileRes.tlvQrCode,
        ubl_xml: compileRes.xml,
        status: (submission.status === 'CLEARED' ? 'CLEARED' : submission.status === 'REPORTED' ? 'REPORTED' : 'ISSUED') as any,
        clearance_status: submission.clearanceStatus || (invType === 'B2B_STANDARD' ? 'CLEARED' : 'REPORTED'),
        istd_submission_id: submission.submissionId,
        submitted_at: new Date().toISOString(),
        created_at: new Date().toISOString(),
      });

      return {
        success: true,
        invoice_uuid: invoiceRecord.invoice_uuid,
        invoice_hash: invoiceRecord.invoice_hash,
        total_jod: invoiceRecord.total_amount,
        istd_submission_id: submission.submissionId,
        istd_status: submission.status,
        transmission_mode: submission.simulated ? 'SIMULATED' : 'LIVE_GATEWAY',
        tlv_qr_preview: invoiceRecord.qr_code_tlv.substring(0, 32) + '...',
        compliance: 'UBL 2.1 ISO/IEC 19845 (JoFotara Phase 2)',
        message: `${submission.message} (المبلغ: ${invoiceRecord.total_amount} د.أ).`,
      };
    }

    case 'trigger_emergency_handover': {
      console.warn(`[EMERGENCY_TRIGGER] Protocol activated for ${args.patient_name}: ${args.symptoms}`);
      return {
        success: true,
        emergency_code: MEDICAL_LIABILITY_GUARDRAILS.emergencyTriggerCode,
        physician_notified: true,
        advisory: MEDICAL_LIABILITY_GUARDRAILS.emergencyResponseAr,
      };
    }

    default:
      return { status: 'error', message: `أداة غير معروفة: ${name}` };
  }
} catch (toolError: any) {
  console.error(`[Tool Execution Recovery] Tool ${name} failed gracefully:`, toolError);
  return {
    status: 'error',
    message: toolError?.message || 'API timeout or database error',
    tool: name,
  };
}
}


```

---

## <a id="lib-ai-gemini-mvp-ts"></a>📁 `lib/ai/gemini-mvp.ts`

```typescript
// File: lib/ai/gemini-mvp.ts
// NashmiOps Enterprise (MVP Edition) - Compatibility Facade
// Unified Orchestration Engine: All conversational logic consolidated in lib/ai/react-agent.ts

import {
  runReactAgent,
  processConversationalMessage,
  getMasterSystemInstruction,
  isGreetingMessage,
  cleanHumanPlainText,
  ReactAgentResult,
} from './react-agent';
import { clinicTools, executeClinicTool, phonesMatch, validateJordanianPhone } from './clinic-tools';

export {
  runReactAgent,
  processConversationalMessage,
  getMasterSystemInstruction,
  isGreetingMessage,
  cleanHumanPlainText,
  clinicTools,
  executeClinicTool,
  phonesMatch,
  validateJordanianPhone,
};

export type { ReactAgentResult };

export const systemInstruction = getMasterSystemInstruction();
export const MASTER_SYSTEM_INSTRUCTION = systemInstruction;

```

---

## <a id="lib-ai-react-agent-ts"></a>📁 `lib/ai/react-agent.ts`

```typescript
// File: lib/ai/react-agent.ts
// NashmiOps Enterprise (MVP Edition) - Unified Production ReAct Agent Core Engine
// Security & Secrets Isolation, Multi-Model Failover, State Checkpointing & Jordanian Receptionist Persona

import { GoogleGenAI } from '@google/genai';
import { CLINIC_CONFIG, MEDICAL_LIABILITY_GUARDRAILS } from '@/lib/config/constants';
import { clinicTools, executeClinicTool, phonesMatch } from './clinic-tools';
import {
  getOrCreateConversation,
  appendChatHistory,
  tenantStore,
} from '@/lib/db/supabase';

// ====================================================================
// 1. SECURITY & SECRETS ISOLATION (No hardcoded credentials)
// ====================================================================
const apiKey = process.env.GEMINI_API_KEY;
if (!apiKey) {
  console.error('[Security] CRITICAL: GEMINI_API_KEY is missing from environment variables!');
}
const ai = new GoogleGenAI({ apiKey: apiKey || '' });

const MAX_REACT_ITERATIONS = 3;
const CANDIDATE_MODELS = [
  'gemini-3.5-flash-lite',
  'gemini-3.1-flash-lite',
  'gemini-3.1-flash-lite-preview',
  'gemini-3-flash-preview',
  'gemini-2.5-flash',
];

// ====================================================================
// 2. CANONICAL SYSTEM INSTRUCTIONS & GREETING DETECTION
// ====================================================================

export function isGreetingMessage(text?: string): boolean {
  if (!text) return false;
  const clean = text.trim().toLowerCase().replace(/[.!؟،]/g, '');
  const greetingPhrases = [
    'السلام عليكم',
    'سلام عليكم',
    'وعليكم السلام',
    'مرحبا',
    'مرحباً',
    'يا هلا',
    'هلا',
    'أهلاً',
    'اهلا',
    'أهلاً وسهلاً',
    'اهلا وسهلا',
    'صباح الخير',
    'صباح الورد',
    'مساء الخير',
    'مساء الورد',
    'يعطيك العافية',
    'يعطيكم العافية',
    'الو',
    'ألو',
    'هاي',
    'هلو',
    'تحياتي',
  ];
  return greetingPhrases.some((g) => clean === g || clean.startsWith(g + ' '));
}

export function getMasterSystemInstruction(): string {
  return `أنت موظف استقبال وسكرتير محترف، ذكي، وودود للغاية في "مركز نشمي لطب وجراحة الأسنان" في عمان، الأردن. تتحدث حصراً عبر رسائل واتساب مع المرضى.

## 1. السياق الزمني والمرجعي الحالي (محسوب آلياً):
- التاريخ والوقت الحالي للسيرفر: ${new Date().toLocaleString('ar-JO', { timeZone: 'Asia/Amman' })}. استخدم هذا التوقيت حصراً كمرجع لأي إشارة إلى "اليوم"، "بكرا"، أو حساب المواعيد.
- موقع المركز: الشميساني، عمان (متوفر مواقف مجانية وخدمة فاليه لراحة المرضى).

## 2. قواعد الأسلوب البشري العفوي (Human-Like Tone & Guardrails):
- تحدث بلهجة أردنية عفوية، لطيفة، ومحترمة (مثل: "يا هلا والله"، "تكرم عيونك"، "ولا يهمك"، "طول بالك").
- الإيجاز التام: الرد لا يتجاوز سطرين إلى ثلاثة أسطر كحد أقصى مثل أي محادثة واتساب سريعة بين البشر.
- ممنوع منعاً باتاً: استخدام التنسيقات الروبوتية، النجوم المزخرفة (**)، القوائم الطويلة، التفلسف، أو تكرار نفس الجمل في كل رسالة.
- ممنوع كتابة الأوصاف أو الحركات التمثيلية بين أقواس نهائياً (مثل: *يبتسم*).

## 3. سيناريو حجز وتثبيت المواعيد (Zero-Friction Booking & Mandatory Patient Name & Multi-Person Rule):
- قاعدة إلزامية صارمة لمنع الحجز بدون اسم (Mandatory Patient Name & Multi-Person Rule):
  1. ممنوع منعاً باتاً استدعاء أداة الحجز (create_appointment) أو تثبيت أي موعد نهائياً إذا لم يقم المريض بكتابة وإرسال اسمه الصريح (ممنوع استخدام أي أسماء وهمية أو افتراضية كـ "مريض نشمي" أو "مريض").
  2. إذا اختار المريض الوقت (مثل "الأحد الساعة 11:30" أو "بكرا 11:30") ولم يذكر اسمه بعد، يجب عليك حصراً أن تسأله عن اسمه أولاً وتقول له: "تمام! بس اعطيني اسمك الكريم عشان أثبتلك الموعد فوراً"، وممنوع إتمام الحجز أو إرسال أي رسالة تأكيد قبل استلام الاسم الحقيقي وتسجيله في السيستم.
  3. حجز المرافقين والعائلة والأسماء المتعددة (Multi-Person Booking):
     - إذا طلب المريض حجز موعد له ولقريبه أو شخص آخر (مثل "إلي ولقريبي" أو "حجز لشخصين")، ممنوع نهائياً استدعاء أداة الحجز أو تثبيت الموعد دون أخذ الأسماء الصريحة لكل شخص.
     - يجب عليك حصراً طلب الأسماء الصريحة أولاً لكل شخص: "تمام! بس اعطيني اسمك الكريم واسم قريبك/المرافق عشان أثبتلكم المواعيد فوراً".
     - بمجرد إعطائه للأسماء، استدعِ فوراً أداة create_appointment مع مصفوفة الأسماء (patients) ليتم تثبيت كل موعد باسمه الحقيقي في جدول Supabase كحجزين متتابعين بدلاً من دمج الأسماء أو تجاهلها.
- منع الردود النصية الوهمية دون تنفيذ الأدوات (Strict Tool-Calling Enforcement):
  * بمجرد اتفاق المريض على الوقت المناسب وإعطائه لاسمه الكريم، يجب عليك فوراً تنفيذ استدعاء أداة الحجز (create_appointment) برمجياً في نفس دورة الرد، وممنوع الاكتفاء بالرد الإنشائي أو كتابة عبارات التأكيد نصياً دون حفظ الموعد فعلياً في قاعدة البيانات.
- ممنوع منعاً باتاً ذكر كلمات مثل "عربون"، "كليك" (CliQ)، أو إجراءات الدفع أثناء تثبيت المواعيد. أكد الموعد بعفوية وطبيعية كأي إنسان.
- عند رغبة المريض بالحجز، اقترح وقتين محددين مباشرة (مثال: "بناسبك بكرا 11:30 الصبح ولا 4:30 بعد الظهر؟").
- قاعدة تعديل رسالة تأكيد الحجز (Booking Confirmation Rule): عند نجاح حجز الموعد، ممنوع استخدام عبارات مبالغ فيها مثل "ألف مبروك". استبدلها بعبارة ترحيبية بسيطة وعملية تناسب جو العيادة (مثل: "يا هلا بك، تم تثبيت موعدك تمام، بانتظارك وتنورنا! الموقع: الشميساني، عمان (متوفر مواقف مجانية وفاليه).").

## 4. سيناريو تعديل أو إلغاء المواعيد (Rescheduling & Cancellation):
- إذا طلب المريض تغيير أو إلغاء موعده بسبب ظرف طارئ، تفاعل معه برحابة صدر وبدون أي لوم ("ولا يهمك، بسيطة").
- استدعِ فوراً أداة التعديل أو الإلغاء (cancel_appointment) لتحديث قاعدة البيانات رسمياً، ثم أكد له التعديل بعبارة قصيرة.

## 5. سيناريو التأمين وفحص البطاقة (Insurance OCR & Verification):
- المركز معتمد لمعظم الشبكات الرئيسية في الأردن (نات هيلث، ميدنت، الشرق العربي، GIG).
- إذا سأل المريض عن التأمين أو أبدى تخوفه من المجيء بلا طائل، اطلب منه صورة البطاقة فوراً.

## 6. سيناريو خصوصية الأطباء والمسؤولية الطبية (Medical Liability Law No. 25 of 2018):
- ممنوع إعطاء رقم الدكتور الشخصي نهائياً حفاظاً على خصوصيته وتركيزه بالعمليات.
- ممنوع التشخيص الطبي أو وصف الأدوية والمسكنات عن بعد نهائياً تحت أي ظرف.

## 7. سيناريو الطوارئ السريرية الفورية (Clinical Triage):
- إذا ذكر المريض أعراضاً خطرة (نزيف مستمر، ورم مفاجئ وكبير بالوجه، ألم حاد جداً لا يستجيب للمسكنات):
  توقف فوراً عن الحجز الروتيني، طمئنه بهدوء، وجهه للحضور الفوري للمركز في الشميساني، وأخبره بأن طبيب الطوارئ سيستقبله فوراً.
`;
}

// ====================================================================
// 3. UTILITIES & CANDIDATE EXTRACTION
// ====================================================================

const placeholderList = [
  'مريض نشمي', 'مريض', 'المريض', 'غير محدد', 'unknown', 'patient', 'user',
  'صاحب الرقم', 'مرافق', 'المرافق', 'قريبي', 'قريبك', 'القريب', 'صاحبي', 'صديقي',
  'أخوي', 'اخوي', 'الأخ', 'زوجتي', 'زوجي', 'ابني', 'بنتي', 'والدي', 'والدتي',
  'أنا', 'انا', 'نحن', 'احنا', 'إلي', 'الي', 'لي'
];

function isPlaceholderName(name: string): boolean {
  const lower = name.toLowerCase().trim();
  return !lower || placeholderList.includes(lower) || lower.length < 2;
}

function extractCandidateNames(
  userStr: string,
  history: Array<{ role: 'user' | 'model'; text: string }>
): string[] {
  const names: string[] = [];
  const textSources = [
    userStr,
    ...history.filter((h) => h.role === 'user').map((h) => h.text).reverse(),
  ];

  for (const txt of textSources) {
    const multiMatch = txt.match(
      /(?:أنا|اسمي|حجز لـ|للمريض)\s+([^\s،.]+)(?:\s+(?:و|وقريبي|ومعي|والأخ)\s+([^\s،.]+))/
    );
    if (multiMatch) {
      const n1 = multiMatch[1].trim();
      const n2 = multiMatch[2].trim();
      if (!isPlaceholderName(n1) && !names.includes(n1)) names.push(n1);
      if (!isPlaceholderName(n2) && !names.includes(n2)) names.push(n2);
    }

    const singleMatches = txt.matchAll(/(?:اسمي|أنا|انا|معك|للمريض|الأخ|السيد)\s+([^\s،.]+)/g);
    for (const sm of singleMatches) {
      const n = sm[1].trim();
      if (!isPlaceholderName(n) && !names.includes(n)) names.push(n);
    }
  }
  return names;
}

function buildGeminiContents(
  chatHistory: Array<{ role: 'user' | 'model'; text: string; toolCalls?: any[] }>,
  currentParts: any[]
): any[] {
  const sanitizedHistory: Array<{ role: 'user' | 'model'; text: string }> = [];

  for (const item of chatHistory) {
    if (!item.text || !item.text.trim()) continue;
    const role: 'user' | 'model' = item.role === 'model' ? 'model' : 'user';

    if (sanitizedHistory.length === 0 && role === 'model') {
      continue;
    }

    const last = sanitizedHistory[sanitizedHistory.length - 1];
    if (last && last.role === role) {
      last.text += '\n' + item.text;
    } else {
      sanitizedHistory.push({ role, text: item.text });
    }
  }

  const contents: any[] = sanitizedHistory.map((h) => ({
    role: h.role,
    parts: [{ text: h.text }],
  }));

  const last = contents[contents.length - 1];
  if (last && last.role === 'user') {
    last.parts.push(...currentParts);
  } else {
    contents.push({
      role: 'user',
      parts: currentParts,
    });
  }

  return contents;
}

export function cleanHumanPlainText(text: string): string {
  if (!text) return '';
  return text
    .replace(/\*\*([^*]+)\*\*/g, '$1')
    .replace(/\*([^*]+)\*/g, '$1')
    .replace(/^[\s]*[-•*]\s+/gm, '')
    .replace(/^[\s]*#+\s+/gm, '')
    .replace(/`([^`]+)`/g, '$1')
    .replace(/\[([^\]]+)\]\(([^)]+)\)/g, '$1 ($2)')
    .replace(/\n{3,}/g, '\n\n')
    .trim();
}

function enforceOneQuestion(text: string): string {
  const questionMarks = (text.match(/؟|\?/g) || []).length;
  if (questionMarks <= 1) return text;

  const sentences = text.split(/(?<=[.!?؟\n])/);
  let questionsFound = 0;
  const filtered = sentences.filter((s) => {
    if (s.includes('؟') || s.includes('?')) {
      questionsFound++;
      return questionsFound === 1 || questionsFound === questionMarks;
    }
    return true;
  });

  return filtered.join(' ').replace(/\s{2,}/g, ' ').trim();
}

export interface ReactAgentResult {
  replyText: string;
  toolCallsExecuted: any[];
  isEmergency: boolean;
  iterations: number;
  conversationId: string;
}

// ====================================================================
// 4. UNIFIED REACT AGENT ORCHESTRATION ENGINE
// ====================================================================

export async function runReactAgent(params: {
  clinicId?: string;
  phoneNumber: string;
  patientName?: string;
  userMessage?: string;
  audioBufferBase64?: string;
  mimeType?: string;
  chatHistoryOverride?: Array<{ role: 'user' | 'model'; text: string }>;
}): Promise<ReactAgentResult> {
  const clinicId = params.clinicId || CLINIC_CONFIG.id;
  const phoneNumber = (params.phoneNumber || '+962791234567').trim();
  const rawUserMsg = (params.userMessage || '').trim();

  // 1. Retrieve or initialize conversation checkpoint in Supabase
  const conversation = await getOrCreateConversation(clinicId, phoneNumber, params.patientName);

  // 2. Natural Greetings Fast Path (Pillar 3: Prevent False Apology)
  if (isGreetingMessage(rawUserMsg)) {
    const warmGreeting =
      'وعليكم السلام ورحمة الله، يا هلا والله فيك في مركز نشمي لطب وجراحة الأسنان بعمان! تفضل يا غالي، كيف بقدر أساعدك بموعدك أو استفسارك اليوم؟ 🦷';
    await appendChatHistory(clinicId, phoneNumber, 'user', rawUserMsg);
    await appendChatHistory(clinicId, phoneNumber, 'model', warmGreeting);

    return {
      replyText: warmGreeting,
      toolCallsExecuted: [],
      isEmergency: false,
      iterations: 0,
      conversationId: conversation.id,
    };
  }

  // 3. Emergency Guardrail (Medical Liability Law No. 25 of 2018)
  let isEmergency = false;
  const hasEmergency = MEDICAL_LIABILITY_GUARDRAILS.emergencyKeywords.some((kw) =>
    rawUserMsg.toLowerCase().includes(kw)
  );

  if (hasEmergency) {
    isEmergency = true;
    void executeClinicTool('trigger_emergency_handover', {
      patient_name: params.patientName || conversation.patient_name || 'مريض طوارئ',
      patient_phone: phoneNumber,
      symptoms: rawUserMsg,
    }, phoneNumber);
  }

  // Append user message to persistent state
  await appendChatHistory(clinicId, phoneNumber, 'user', rawUserMsg || '[رسالة صوتية]');

  // 4. Strict Patient Name & Multi-Person Guard
  const historyToUse = params.chatHistoryOverride || conversation.chat_history;
  const detectedNames = extractCandidateNames(rawUserMsg, historyToUse);
  const isMultiPersonIntent =
    /(?:إلي ولقريبي|إلي ولأخوي|إلي ولزوجتي|شخصين|موعدين|مع بعض|حجز مشترك|لي ولـ|حجز لشخصين)/.test(rawUserMsg);
  const timeMatch =
    rawUserMsg.match(/\b([01]?[0-9]|2[0-3]):[0-5][0-9]\b/) ||
    rawUserMsg.match(/(?:الساعة|ساعة)\s*(\d{1,2}(?::\d{2})?)/);

  // If user requested a time without providing requisite names, strictly enforce asking for names
  if (timeMatch) {
    if (isMultiPersonIntent && detectedNames.length < 2) {
      const namePrompt = 'تمام! بس اعطيني اسمك الكريم واسم قريبك/المرافق عشان أثبتلكم المواعيد فوراً.';
      await appendChatHistory(clinicId, phoneNumber, 'model', namePrompt);
      return {
        replyText: namePrompt,
        toolCallsExecuted: [],
        isEmergency,
        iterations: 0,
        conversationId: conversation.id,
      };
    } else if (!isMultiPersonIntent && detectedNames.length === 0) {
      const namePrompt = 'تمام! بس اعطيني اسمك الكريم عشان أثبتلك الموعد فوراً.';
      await appendChatHistory(clinicId, phoneNumber, 'model', namePrompt);
      return {
        replyText: namePrompt,
        toolCallsExecuted: [],
        isEmergency,
        iterations: 0,
        conversationId: conversation.id,
      };
    }
  }

  // 5. Prepare Current Turn Content Parts
  const currentParts: any[] = [];
  if (params.audioBufferBase64) {
    currentParts.push({
      inlineData: {
        mimeType: params.mimeType || 'audio/ogg',
        data: params.audioBufferBase64,
      },
    });
    if (rawUserMsg) {
      currentParts.push({ text: rawUserMsg });
    } else {
      currentParts.push({
        text: 'استمع إلى هذه الرسالة الصوتية المرفقة من المريض، وتصرف كسكرتير نشمي لعيادة الأسنان في عمان وفق القواعد المحددة.',
      });
    }
  } else {
    currentParts.push({ text: rawUserMsg });
  }

  // Build Full Conversation Contents
  const contents = buildGeminiContents(historyToUse, currentParts);

  const toolCallsExecuted: any[] = [];
  let finalReplyText = '';
  let iterationCount = 0;
  const systemInstruction = getMasterSystemInstruction();

  // 6. ReAct Loop (strictly capped at MAX_REACT_ITERATIONS = 3)
  while (iterationCount < MAX_REACT_ITERATIONS) {
    iterationCount++;
    console.log(`[ReAct Agent] Iteration ${iterationCount} of ${MAX_REACT_ITERATIONS} for ${phoneNumber}`);

    let response: any = null;
    let selectedModel = '';

    // Multi-Model Failover Pool
    for (const model of CANDIDATE_MODELS) {
      try {
        const genPromise = ai.models.generateContent({
          model,
          contents,
          config: {
            systemInstruction,
            tools: [{ functionDeclarations: clinicTools as any }],
          },
        });

        const timeoutPromise = new Promise((_, reject) =>
          setTimeout(() => reject(new Error('REACT_MODEL_TIMEOUT')), 5000)
        );

        response = await Promise.race([genPromise, timeoutPromise]);
        selectedModel = model;
        break;
      } catch (modelErr: any) {
        console.log(`[ReAct Agent] Failover from ${model} due to: ${modelErr?.message || modelErr}`);
      }
    }

    if (!response) {
      console.error('[ReAct Agent] All candidate models exhausted in iteration', iterationCount);
      break;
    }

    const rawFunctionCalls: any =
      response.functionCalls ||
      response.candidates?.[0]?.content?.parts?.filter((p: any) => p.functionCall)?.map((p: any) => p.functionCall);

    const functionCalls = Array.isArray(rawFunctionCalls) ? rawFunctionCalls : [];

    if (functionCalls.length === 0) {
      finalReplyText = response.text || '';
      console.log(`[ReAct Agent] Iteration ${iterationCount}: Final text generated via ${selectedModel}`);
      break;
    }

    // Tools called! Execute each tool within strict 8-second timeout
    console.log(
      `[ReAct Agent] Iteration ${iterationCount}: Executing ${functionCalls.length} tool call(s):`,
      functionCalls.map((c: any) => c.name)
    );

    if (response.candidates?.[0]?.content) {
      contents.push(response.candidates[0].content);
    } else {
      contents.push({
        role: 'model',
        parts: functionCalls.map((c: any) => ({ functionCall: c })),
      });
    }

    const functionResponseParts: any[] = [];

    for (const call of functionCalls) {
      let toolResult: any;
      try {
        const TOOL_TIMEOUT_MS = 8000;
        const toolPromise = executeClinicTool(call.name, call.args, phoneNumber);
        const timeoutPromise = new Promise((_, reject) =>
          setTimeout(() => reject(new Error('TOOL_EXECUTION_TIMEOUT')), TOOL_TIMEOUT_MS)
        );

        toolResult = await Promise.race([toolPromise, timeoutPromise]);
      } catch (toolExecErr: any) {
        console.error(`[ReAct Agent] Tool ${call.name} error/timeout:`, toolExecErr?.message || toolExecErr);
        toolResult = {
          status: 'error',
          message: toolExecErr?.message || 'API timeout',
          tool: call.name,
        };
      }

      toolCallsExecuted.push({
        name: call.name,
        args: call.args,
        result: toolResult,
        iteration: iterationCount,
      });

      if (call.name === 'trigger_emergency_handover') {
        isEmergency = true;
      }

      functionResponseParts.push({
        functionResponse: {
          name: call.name,
          response: toolResult,
        },
      });
    }

    contents.push({
      role: 'user',
      parts: functionResponseParts,
    });

    if (iterationCount >= MAX_REACT_ITERATIONS) {
      console.warn(`[ReAct Agent] Reached MAX_REACT_ITERATIONS (${MAX_REACT_ITERATIONS}), terminating loop.`);
      try {
        const finalGen = await ai.models.generateContent({
          model: selectedModel || 'gemini-3.5-flash-lite',
          contents,
          config: {
            systemInstruction,
          },
        });
        finalReplyText = finalGen.text || '';
      } catch {
        const lastTool = toolCallsExecuted[toolCallsExecuted.length - 1];
        finalReplyText = lastTool?.result?.message || 'يا هلا بك، تم تثبيت موعدك تمام، بانتظارك وتنورنا!';
      }
      break;
    }
  }

  // 7. Strict Tool Enforcement & Premature Confirmation Interception
  const prematureConfirmation =
    finalReplyText.includes('تم تثبيت') ||
    finalReplyText.includes('ثبتتلك') ||
    finalReplyText.includes('حجزتلك') ||
    finalReplyText.includes('بانتظارك وتنورنا');

  if (prematureConfirmation && toolCallsExecuted.length === 0) {
    if (timeMatch && detectedNames.length > 0) {
      // Programmatically enforce the tool call since user gave name & time
      const rawTime = timeMatch[1] || timeMatch[0];
      const cleanTime = rawTime.includes(':') ? rawTime : `${rawTime.padStart(2, '0')}:00`;

      if (isMultiPersonIntent && detectedNames.length >= 2) {
        console.log('[Strict Enforcement] Executing multi-person booking tool:', detectedNames);
        const autoRes = await executeClinicTool(
          'create_appointment',
          {
            patients: detectedNames.slice(0, 2),
            time_str: cleanTime,
            date_str: 'غداً',
          },
          phoneNumber
        );
        if (autoRes?.message) finalReplyText = autoRes.message;
        toolCallsExecuted.push({ name: 'create_appointment', args: { patients: detectedNames }, result: autoRes });
      } else {
        console.log('[Strict Enforcement] Executing single booking tool for:', detectedNames[0]);
        const autoRes = await executeClinicTool(
          'create_appointment',
          {
            patient_name: detectedNames[0],
            time_str: cleanTime,
            date_str: 'غداً',
          },
          phoneNumber
        );
        if (autoRes?.message) finalReplyText = autoRes.message;
        toolCallsExecuted.push({ name: 'create_appointment', args: { patient_name: detectedNames[0] }, result: autoRes });
      }
    } else {
      // Intercept and ask for names
      finalReplyText = isMultiPersonIntent
        ? 'تمام! بس اعطيني اسمك الكريم واسم قريبك/المرافق عشان أثبتلكم المواعيد فوراً.'
        : 'تمام! بس اعطيني اسمك الكريم عشان أثبتلك الموعد فوراً.';
    }
  }

  // 8. Fallback Recovery (Pillar 3: Triggered ONLY on real connection drops)
  if (!finalReplyText) {
    if (isEmergency) {
      finalReplyText = `${MEDICAL_LIABILITY_GUARDRAILS.emergencyTriggerCode}\n${MEDICAL_LIABILITY_GUARDRAILS.emergencyResponseAr}`;
    } else {
      const nameMatch = rawUserMsg.match(/(?:أنا|اسمي|معك|لـ|للمريض|الأخ|السيد)\s+([^\s،.]+)/);
      const detectedName = nameMatch ? nameMatch[1] : '';
      const greeting = detectedName ? `أهلاً بك يا ${detectedName}` : 'أهلاً بك يا غالي';
      finalReplyText = `${greeting}، عذراً منك واجهنا ضغط مؤقت في شبكة الاتصال، ممكن تعيدلي طلبك بعد إذنك؟`;
    }
  }

  // 9. Anti-Markdown & Human Reception Styling
  let cleanedReply = cleanHumanPlainText(finalReplyText);

  // Guarantee ZERO deposits / CliQ mention
  cleanedReply = cleanedReply
    .replace(/(?:عربون|دفعة أولى|كليك|CliQ|حوللنا)/gi, '')
    .trim();

  // Enforce one question at a time
  cleanedReply = enforceOneQuestion(cleanedReply);

  // 10. Checkpoint Model Turn into Supabase Chat History
  await appendChatHistory(clinicId, phoneNumber, 'model', cleanedReply, toolCallsExecuted);

  return {
    replyText: cleanedReply,
    toolCallsExecuted,
    isEmergency,
    iterations: iterationCount,
    conversationId: conversation.id,
  };
}

/**
 * Universal wrapper for backward compatibility across existing suites
 */
export async function processConversationalMessage(params: {
  userMessage?: string;
  audioBufferBase64?: string;
  mimeType?: string;
  patientPhone: string;
  chatHistory: Array<{ role: 'user' | 'model'; text: string }>;
}): Promise<{
  replyText: string;
  toolCallsExecuted: any[];
  isEmergency: boolean;
}> {
  const result = await runReactAgent({
    phoneNumber: params.patientPhone,
    userMessage: params.userMessage,
    audioBufferBase64: params.audioBufferBase64,
    mimeType: params.mimeType,
    chatHistoryOverride: params.chatHistory,
  });

  return {
    replyText: result.replyText,
    toolCallsExecuted: result.toolCallsExecuted,
    isEmergency: result.isEmergency,
  };
}

```

---

## <a id="lib-auth-api-guard-ts"></a>📁 `lib/auth/api-guard.ts`

```typescript
// File: lib/auth/api-guard.ts
// NashmiOps Enterprise (MVP Edition) - API Route Protection & PDPL Guard
// Jordanian Personal Data Protection Law (PDPL No. 24 of 2023)

import { NextRequest, NextResponse } from 'next/server';

export interface AuthVerificationResult {
  authorized: boolean;
  reason?: string;
  response?: NextResponse;
}

/**
 * Verify API Authorization pursuant to PDPL Law No. 24 of 2023.
 * Checks Bearer token or custom headers against CRON_SECRET / API_SECRET_KEY.
 * Allows local sandbox simulations and in-browser Sandbox testing seamlessly.
 */
export function verifyApiAuthorization(req: NextRequest): AuthVerificationResult {
  const envCronSecret = process.env.CRON_SECRET;
  const envApiSecret = process.env.API_SECRET_KEY;

  // If env variables are explicitly defined, use them strictly; otherwise allow default dev secret in non-production
  const cronSecret = envCronSecret || (process.env.NODE_ENV !== 'production' ? 'nashmi_cron_secret_token_2026' : undefined);
  const apiSecret = envApiSecret || (process.env.NODE_ENV !== 'production' ? 'nashmi_secure_api_secret_key_2026' : undefined);

  const authHeader = req.headers.get('authorization') || '';
  const xApiKey = req.headers.get('x-api-key') || '';
  const xCronSecret = req.headers.get('x-cron-secret') || '';
  const xVercelCron = req.headers.get('x-vercel-cron') || '';
  const isSimulation =
    req.headers.get('x-sandbox-simulation') === 'true' ||
    req.headers.get('x-client-simulation') === 'true';

  // 1. Official Vercel Cron Header Recognition
  // Vercel Cron automatically attaches `x-vercel-cron: "1"` and `Authorization: Bearer ${CRON_SECRET}`
  if (xVercelCron === '1' || xVercelCron === 'true') {
    if (envCronSecret) {
      if (authHeader === `Bearer ${envCronSecret}`) {
        return { authorized: true, reason: 'VERCEL_CRON_AUTHENTICATED' };
      }
    } else {
      // In dev or unconfigured test environment, valid Vercel Cron header passes
      return { authorized: true, reason: 'VERCEL_CRON_HEADER_RECOGNIZED' };
    }
  }

  // 2. Check Bearer token in Authorization header
  if (authHeader.startsWith('Bearer ')) {
    const token = authHeader.substring(7).trim();
    if ((cronSecret && token === cronSecret) || (apiSecret && token === apiSecret)) {
      return { authorized: true, reason: 'BEARER_TOKEN_AUTHENTICATED' };
    }
  }

  // 3. Check direct custom headers
  if ((apiSecret && xApiKey === apiSecret) || (cronSecret && xCronSecret === cronSecret)) {
    return { authorized: true, reason: 'CUSTOM_KEY_AUTHENTICATED' };
  }

  // 3. Local Sandbox Simulation Bypass
  // Allows testing via Sandbox UI, local dev tools, and frontend routes
  const host = req.headers.get('host') || '';
  const referer = req.headers.get('referer') || '';
  const secFetchSite = req.headers.get('sec-fetch-site') || '';

  const isLocalOrSandbox =
    isSimulation ||
    host.includes('localhost') ||
    host.includes('127.0.0.1') ||
    referer.includes('/sandbox') ||
    referer.includes('/chat') ||
    secFetchSite === 'same-origin';

  if (isLocalOrSandbox) {
    return { authorized: true, reason: 'LOCAL_SANDBOX_SIMULATION_BYPASS' };
  }

  // 4. Unauthorized Access Block (HTTP 401)
  return {
    authorized: false,
    reason: 'UNAUTHORIZED_PDPL_VIOLATION',
    response: NextResponse.json(
      {
        success: false,
        error:
          'Unauthorized: Access to patient data and clinic operations is strictly restricted pursuant to Jordanian Personal Data Protection Law (PDPL No. 24 of 2023). Please provide a valid Authorization Bearer token or API secret key.',
      },
      { status: 401 }
    ),
  };
}

```

---

## <a id="lib-calendar-scheduler-ts"></a>📁 `lib/calendar/scheduler.ts`

```typescript
// File: lib/calendar/scheduler.ts
// NashmiOps Enterprise (MVP Edition) - Dynamic Calendar Scheduler & Family Profiles

import { google } from 'googleapis';
import { Appointment, ServiceType } from '@/types';
import { CLINIC_CONFIG, CLINICAL_SERVICES } from '@/lib/config/constants';
import {
  tenantStore,
  createAppointment,
  findOrCreatePatient,
  recordPdplConsent,
  supabase,
} from '@/lib/db/supabase';

let googleCalendarClient: any = null;

function getCalendarClient() {
  if (googleCalendarClient) return googleCalendarClient;

  try {
    const credsRaw = process.env.GOOGLE_APPLICATION_CREDENTIALS_JSON;
    if (!credsRaw) {
      console.warn('[Calendar] GOOGLE_APPLICATION_CREDENTIALS_JSON missing, operating in simulated mode.');
      return null;
    }

    const creds = JSON.parse(credsRaw);
    const auth = new google.auth.JWT({
      email: creds.client_email,
      key: creds.private_key,
      scopes: ['https://www.googleapis.com/auth/calendar'],
    });

    googleCalendarClient = google.calendar({ version: 'v3', auth });
    return googleCalendarClient;
  } catch (err) {
    console.warn('[Calendar] Failed to initialize Google Calendar client:', err);
    return null;
  }
}

export interface BookAppointmentInput {
  clinicId?: string;
  phone: string;
  patientName: string;
  serviceType: ServiceType;
  dateStr: string; // YYYY-MM-DD
  timeStr: string; // HH:mm (e.g. 11:00, 16:30)
  familyRelation?: 'self' | 'child' | 'spouse' | 'parent';
  nationalId?: string;
  notes?: string;
  isEmergency?: boolean;
}

export interface SchedulingResult {
  success: boolean;
  appointment?: Appointment;
  googleCalendarEventId?: string;
  message: string;
  conflictDetails?: string;
}

/**
 * Validate appointment against clinic working hours and Friday closure
 */
export function validateClinicWorkingHours(
  startTime: Date,
  endTimeWithBuffer: Date
): { valid: boolean; reason?: string } {
  const day = startTime.getDay(); // 0 = Sunday, 5 = Friday, 6 = Saturday

  // Friday is weekly holiday
  if (day === 5 || !CLINIC_CONFIG.workingHours.days.includes(day)) {
    return {
      valid: false,
      reason: 'يوم الجمعة عطلة أسبوعية رسمية في مركز نشمي لطب وجراحة الأسنان. دوامنا من السبت إلى الخميس. نقترح عليك حجز الموعد يوم السبت أو الأحد القادم من الساعة 09:00 صباحاً حتى 08:00 مساءً. هل يناسبك يوم السبت أو الأحد؟ 🦷',
    };
  }

  const [startH, startM] = CLINIC_CONFIG.workingHours.start.split(':').map(Number);
  const [endH, endM] = CLINIC_CONFIG.workingHours.end.split(':').map(Number);

  const startMinutes = startTime.getHours() * 60 + startTime.getMinutes();
  const endMinutes = endTimeWithBuffer.getHours() * 60 + endTimeWithBuffer.getMinutes();

  const openMinutes = startH * 60 + startM;  // 09:00 -> 540
  const closeMinutes = endH * 60 + endM;    // 20:00 -> 1200

  if (startMinutes < openMinutes) {
    return {
      valid: false,
      reason: `الوقت المطلوب قبل بدء ساعات العمل الرسمية (نفتح من الساعة ${CLINIC_CONFIG.workingHours.start} صباحاً إلى ${CLINIC_CONFIG.workingHours.end} مساءً). بإمكانك الحجز في أقرب موعد متاح الساعة 09:30 أو 10:00 صباحاً. هل يناسبك ذلك؟ 🦷`,
    };
  }

  if (endMinutes > closeMinutes || startMinutes >= closeMinutes) {
    return {
      valid: false,
      reason: `الوقت المطلوب وفترة التعقيم يتجاوزان وقت إغلاق العيادة (نستقبل المرضى حتى الساعة ${CLINIC_CONFIG.workingHours.end} مساءً). نقترح عليك موعداً في نفس اليوم الساعة 18:30 أو 19:00 مساءً أو في صباح اليوم التالي. هل يناسبك ذلك؟ 🦷`,
    };
  }

  return { valid: true };
}

/**
 * Check slot availability including mandatory 15-minute sterilization buffer and working hours
 * Queries Supabase directly as the Single Source of Truth
 */
export async function checkSlotAvailability(
  clinicId: string,
  startTime: Date,
  endTimeWithBuffer: Date
): Promise<{ available: boolean; conflictReason?: string }> {
  // 1. Working Hours & Friday Closure Guard
  const hoursCheck = validateClinicWorkingHours(startTime, endTimeWithBuffer);
  if (!hoursCheck.valid) {
    return {
      available: false,
      conflictReason: hoursCheck.reason,
    };
  }

  const reqStart = startTime.getTime();
  const reqEnd = endTimeWithBuffer.getTime();

  // Query Supabase directly (Single Source of Truth)
  let activeAppointments: Appointment[] = [];
  try {
    const { data, error } = await supabase
      .from('appointments')
      .select('*')
      .eq('clinic_id', clinicId)
      .neq('status', 'CANCELLED');

    if (!error && Array.isArray(data) && data.length > 0) {
      activeAppointments = data as Appointment[];
    } else {
      // Graceful offline fallback
      activeAppointments = tenantStore.appointments.filter(
        (appt) => appt.clinic_id === clinicId && appt.status !== 'CANCELLED'
      );
    }
  } catch {
    activeAppointments = tenantStore.appointments.filter(
      (appt) => appt.clinic_id === clinicId && appt.status !== 'CANCELLED'
    );
  }

  const conflict = activeAppointments.find((appt) => {
    if (appt.clinic_id !== clinicId) return false;
    if (appt.status === 'CANCELLED') return false;

    const existingStart = new Date(appt.start_time).getTime();
    // Compare against the full sterilization buffer time
    const existingEnd = new Date(appt.sterilization_end_time || appt.end_time).getTime();

    // Overlap condition
    return reqStart < existingEnd && reqEnd > existingStart;
  });

  if (conflict) {
    const conflictDate = new Date(conflict.sterilization_end_time || conflict.end_time);
    return {
      available: false,
      conflictReason: `الموعد يتعارض مع موعد محجوز مسبقاً (شاملاً فترة التعقيم الإلزامية 15 دقيقة) حتى الساعة ${conflictDate.toLocaleTimeString('ar-JO', { hour: '2-digit', minute: '2-digit' })}.`,
    };
  }

  return { available: true };
}

/**
 * Frictionless Booking:
 * - Zero upfront deposit
 * - Adds 15-min sterilization buffer
 * - Saves distinct patient record under WhatsApp number (Family Profiles)
 * - Pushes to Google Calendar via Service Account
 */
export async function bookFrictionlessAppointment(
  input: BookAppointmentInput
): Promise<SchedulingResult> {
  const clinicId = input.clinicId || CLINIC_CONFIG.id;
  const service = CLINICAL_SERVICES[input.serviceType] || CLINICAL_SERVICES.consultation;

  // 1. Calculate Timestamps
  const [hours, minutes] = input.timeStr.split(':').map(Number);
  const startDate = new Date(input.dateStr);
  startDate.setHours(hours, minutes, 0, 0);

  const durationMs = service.durationMinutes * 60 * 1000;
  const sterilizationBufferMs = CLINIC_CONFIG.sterilizationBufferMinutes * 60 * 1000;

  const endDate = new Date(startDate.getTime() + durationMs);
  const sterilizationEndDate = new Date(endDate.getTime() + sterilizationBufferMs);

  // 2. Conflict Check
  const check = await checkSlotAvailability(clinicId, startDate, sterilizationEndDate);
  if (!check.available) {
    return {
      success: false,
      message: check.conflictReason || 'الوقت المطلوب غير متوفر حالياً.',
      conflictDetails: check.conflictReason,
    };
  }

  // 3. Family Profile Handling: Find or Create distinct patient record
  const { patient } = await findOrCreatePatient({
    clinicId,
    phone: input.phone,
    fullName: input.patientName,
    nationalId: input.nationalId,
    familyRelation: input.familyRelation || 'self',
    primaryContactPhone: input.phone,
  });

  // Ensure PDPL consent is recorded as patient is actively booking
  await recordPdplConsent(patient.id, clinicId, true);

  // 4. Push to Google Calendar (Service Account)
  let googleCalendarEventId: string | undefined;
  const calendar = getCalendarClient();
  const calendarId = process.env.GOOGLE_CALENDAR_ID || 'primary';

  if (calendar) {
    try {
      const summaryText = `[نشمي أوبس] ${service.nameAr} - ${input.patientName}`;
      const descriptionText = `حجز موعد عيادة نشمي (NashmiOps Enterprise MVP)
المريض: ${input.patientName} (${input.familyRelation === 'self' ? 'صاحب الرقم' : `أحد أفراد العائلة: ${input.familyRelation}`})
رقم الهاتف: ${input.phone}
الخدمة: ${service.nameAr} (${service.durationMinutes} دقيقة)
فترة التعقيم الإلزامية: 15 دقيقة إضافية
الحالة: مؤكد 100%`;

      const insertPromise = calendar.events.insert({
        calendarId,
        requestBody: {
          summary: summaryText,
          description: descriptionText,
          start: {
            dateTime: startDate.toISOString(),
            timeZone: CLINIC_CONFIG.timezone,
          },
          end: {
            dateTime: sterilizationEndDate.toISOString(), // Reserve the slot including sterilization buffer
            timeZone: CLINIC_CONFIG.timezone,
          },
          location: CLINIC_CONFIG.address,
        },
      });

      const timeoutPromise = new Promise((_, reject) =>
        setTimeout(() => reject(new Error('Google Calendar insertion timed out')), 3500)
      );

      const response: any = await Promise.race([insertPromise, timeoutPromise]);
      googleCalendarEventId = response?.data?.id || undefined;
      console.log(`[Google Calendar] Successfully created event ID: ${googleCalendarEventId}`);
    } catch (err) {
      console.warn('[Google Calendar] Could not push to remote calendar, stored in resilient tenant store:', err);
    }
  }

  // 5. Create Appointment in Supabase / Tenant Store (Atomic Double-Booking Guard)
  try {
    const appointment = await createAppointment({
      clinicId,
      patientId: patient.id,
      patientName: input.patientName,
      patientPhone: input.phone,
      serviceType: input.serviceType,
      startTime: startDate.toISOString(),
      endTime: endDate.toISOString(),
      sterilizationEndTime: sterilizationEndDate.toISOString(),
      googleCalendarEventId,
      notes: input.notes,
      isEmergency: input.isEmergency,
    });

    const formattedDate = startDate.toLocaleDateString('ar-JO', {
      weekday: 'long',
      year: 'numeric',
      month: 'long',
      day: 'numeric',
    });
    const formattedTime = startDate.toLocaleTimeString('ar-JO', {
      hour: '2-digit',
      minute: '2-digit',
      hour12: true,
    });

    return {
      success: true,
      appointment,
      googleCalendarEventId,
      message: `يا هلا بك، تم تثبيت موعدك تمام، بانتظارك وتنورنا!
اليوم: ${formattedDate}
الساعة: ${formattedTime}
الخدمة: ${service.nameAr}
المركز: ${CLINIC_CONFIG.name} (${CLINIC_CONFIG.address})`,
    };
  } catch (err: any) {
    if (err?.code === 'DOUBLE_BOOKING_CONFLICT' || err?.message?.includes('DOUBLE_BOOKING_CONFLICT')) {
      return {
        success: false,
        message: `عذراً، يبدو أن هذا الموعد تم حجزه للتو أو يتعارض مع فترة التعقيم الإلزامية (15 دقيقة). هل يناسبك وقت بديل مثل 14:00 أو 16:30؟`,
        conflictDetails: err.message,
      };
    }
    throw err;
  }
}

```

---

## <a id="lib-config-constants-ts"></a>📁 `lib/config/constants.ts`

```typescript
// File: lib/config/constants.ts
// NashmiOps Enterprise (MVP Edition) - Configuration & Clinical Constants

import { ServiceDefinition, ServiceType } from '@/types';

export const CLINIC_CONFIG = {
  id: 'clinic-amman-nashmi-001',
  name: 'مركز نشمي لطب وجراحة الأسنان',
  nameEn: 'Nashmi Dental & Oral Surgery Center',
  phone: '+96265000000',
  whatsappPhone: '+962790000000',
  address: 'عمان - الدوار السابع - مجمع النشامى الطبي - الطابق الثالث',
  googleMapsUrl: 'https://maps.google.com/?q=31.9539,35.8578', // Amman 7th Circle
  taxNumber: '100492837', // ISTD Registered Tax Number
  licenseNumber: 'MOH-JO-2024-9981', // Ministry of Health License
  timezone: 'Asia/Amman',
  workingHours: {
    start: '09:00',
    end: '20:00',
    days: [0, 1, 2, 3, 4, 6], // Sunday through Thursday + Saturday (Friday closed)
  },
  sterilizationBufferMinutes: 15, // Mandatory clinical buffer per Law No. 25
};

export const CLINICAL_SERVICES: Record<ServiceType, ServiceDefinition> = {
  consultation: {
    id: 'consultation',
    nameAr: 'كشف واستشارة طبية شاملة',
    nameEn: 'Comprehensive Consultation & Exam',
    durationMinutes: 30,
    sterilizationMinutes: 15,
    basePriceJOD: 15.0,
    taxRatePercent: 0, // Diagnostic/basic health exempted under specific ISTD schedules
  },
  cleaning: {
    id: 'cleaning',
    nameAr: 'تنظيف وتقليح الأسنان وإزالة الجير',
    nameEn: 'Dental Scaling & Prophylaxis',
    durationMinutes: 45,
    sterilizationMinutes: 15,
    basePriceJOD: 25.0,
    taxRatePercent: 0,
  },
  restoration: {
    id: 'restoration',
    nameAr: 'حشوات تجميلية كمبوزيت / علاج نخر',
    nameEn: 'Composite Restoration / Filling',
    durationMinutes: 45,
    sterilizationMinutes: 15,
    basePriceJOD: 35.0,
    taxRatePercent: 0,
  },
  extraction: {
    id: 'extraction',
    nameAr: 'خلع ضرس / جراحة صغرى',
    nameEn: 'Tooth Extraction / Minor Surgery',
    durationMinutes: 45,
    sterilizationMinutes: 15,
    basePriceJOD: 40.0,
    taxRatePercent: 0,
  },
  emergency: {
    id: 'emergency',
    nameAr: 'طوارئ وألم حاد فوري',
    nameEn: 'Urgent Dental Emergency',
    durationMinutes: 30,
    sterilizationMinutes: 15,
    basePriceJOD: 20.0,
    taxRatePercent: 0,
  },
  whitening: {
    id: 'whitening',
    nameAr: 'تبييض الأسنان بالليزر',
    nameEn: 'Laser Teeth Whitening',
    durationMinutes: 60,
    sterilizationMinutes: 15,
    basePriceJOD: 120.0,
    taxRatePercent: 16, // Cosmetic standard rate 16%
  },
  orthodontics_check: {
    id: 'orthodontics_check',
    nameAr: 'تقييم واستشارة تقويم الأسنان',
    nameEn: 'Orthodontic Evaluation',
    durationMinutes: 30,
    sterilizationMinutes: 15,
    basePriceJOD: 20.0,
    taxRatePercent: 0,
  },
};

// Regulatory Guardrails: Law No. 25 of 2018 (Medical Liability)
export const MEDICAL_LIABILITY_GUARDRAILS = {
  forbiddenKeywords: [
    'panadol', 'بنادول', 'باراسيتامول', 'paracetamol',
    'ibuprofen', 'بروفين', 'ايبوبروفين', 'voltarin', 'فولتارين',
    'amoxicillin', 'اموكسيسيلين', 'مضاد حيوي', 'antibiotic',
    'اشرب دواء', 'خذ حبة', 'جرعة', 'مسكن', 'مرهم'
  ],
  emergencyKeywords: [
    'نزيف', 'دم مستمر', 'ورم كبير', 'انتفاخ بالوجه', 'انتفاخ بالفك',
    'مش قادر اتنفس', 'الم لا يحتمل', 'كسر بالفك', 'سقط سني', 'صعوبة بالبلع',
    'حرارة عالية مع ورم', 'hemorrhage', 'bleeding', 'severe swelling'
  ],
  emergencyTriggerCode: '[EMERGENCY_TRIGGER]',
  emergencyResponseAr: `⚠️ تنبيه طبي عاجل: تم تفعيل بروتوكول الطوارئ الفوري وفق قانون المسؤولية الطبية رقم 25 لسنة 2018.
يرجى التوجه فوراً إلى العيادة أو أقرب قسم طوارئ. تم إرسال تنبيه عاجل للطبيب المناوب للمتابعة معك هاتفياً فوراً.`,
};

// Regulatory Disclaimer: Law No. 24 of 2023 (Personal Data Protection)
export const PDPL_CONSENT_MESSAGE = `مرحباً بك في مركز نشمي لطب الأسنان في عمان 🦷
وفقاً لقانون حماية البيانات الشخصية الأردني رقم 24 لسنة 2023، نحرص على خصوصية بياناتك الطبية.
هل توافق على معالجة اسمك ورقم هاتفك لحجز موعدك الطبي وتوثيقه في ملفك الصحي؟
(يرجى الرد بـ "نعم موافق" أو "أوافق" للمتابعة).`;

export function formatJOD(amount: number): string {
  return `${amount.toFixed(3)} د.أ`;
}

```

---

## <a id="lib-db-disk-store-ts"></a>📁 `lib/db/disk-store.ts`

```typescript
// File: lib/db/disk-store.ts
// NashmiOps Enterprise (MVP Edition) - Resilient Disk Persistence Engine
// Persists appointments, patients, waitlist, invoices, and conversation states across server restarts & browser refreshes

import fs from 'fs';
import path from 'path';

const DATA_DIR = path.join(process.cwd(), 'data');
const PERSISTENCE_FILE = path.join(DATA_DIR, 'nashmi_db.json');

export interface PersistentSnapshot {
  clinics?: any[];
  patients?: any[];
  appointments?: any[];
  waitlist?: any[];
  invoices?: any[];
  clinic_faqs?: any[];
  conversations?: any[];
  processed_messages?: any[];
  failed_outbound_messages?: any[];
}

export function loadPersistentData(): PersistentSnapshot | null {
  try {
    if (!fs.existsSync(DATA_DIR)) {
      fs.mkdirSync(DATA_DIR, { recursive: true });
    }
    if (fs.existsSync(PERSISTENCE_FILE)) {
      const raw = fs.readFileSync(PERSISTENCE_FILE, 'utf-8');
      const parsed = JSON.parse(raw);
      console.log(
        `[DiskStore] Loaded snapshot from disk: ${parsed.appointments?.length || 0} appts, ${
          parsed.conversations?.length || 0
        } convs`
      );
      return parsed;
    }
  } catch (err) {
    console.warn('[DiskStore] Error reading persistent data:', err);
  }
  return null;
}

export function savePersistentData(data: PersistentSnapshot): void {
  try {
    if (!fs.existsSync(DATA_DIR)) {
      fs.mkdirSync(DATA_DIR, { recursive: true });
    }
    fs.writeFileSync(PERSISTENCE_FILE, JSON.stringify(data, null, 2), 'utf-8');
  } catch (err) {
    console.warn('[DiskStore] Error writing persistent data:', err);
  }
}

```

---

## <a id="lib-db-supabase-browser-ts"></a>📁 `lib/db/supabase-browser.ts`

```typescript
// File: lib/db/supabase-browser.ts
// NashmiOps Enterprise (MVP Edition) - Browser-Safe Supabase Client
// For use in client components (Realtime subscriptions, client-side queries)

import { createClient } from '@supabase/supabase-js';

const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL;
const supabaseKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY;

if (!supabaseUrl || !supabaseKey) {
  console.error('[Security] CRITICAL: NEXT_PUBLIC_SUPABASE_URL or NEXT_PUBLIC_SUPABASE_ANON_KEY missing in environment variables!');
}

export const supabaseBrowser = createClient(
  supabaseUrl || 'https://placeholder.supabase.co',
  supabaseKey || 'placeholder-anon-key'
);

```

---

## <a id="lib-db-supabase-ts"></a>📁 `lib/db/supabase.ts`

```typescript
// File: lib/db/supabase.ts
// NashmiOps Enterprise (MVP Edition) - Database Layer & Multi-Tenant Store

import { createClient, SupabaseClient } from '@supabase/supabase-js';
import {
  Clinic,
  Patient,
  Appointment,
  WaitlistEntry,
  Invoice,
  AppointmentStatus,
  WaitlistStatus,
  ServiceType,
  ClinicFaq,
  ConversationState,
  ChatHistoryMessage,
  FailedOutboundMessage,
} from '@/types';
import { CLINIC_CONFIG } from '@/lib/config/constants';
import { loadPersistentData, savePersistentData } from '@/lib/db/disk-store';

const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL;
const supabaseKey =
  process.env.SUPABASE_SERVICE_ROLE_KEY ||
  process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY;

if (!supabaseUrl || !supabaseKey) {
  console.error('[Security] CRITICAL: Supabase credentials (NEXT_PUBLIC_SUPABASE_URL / SUPABASE_SERVICE_ROLE_KEY) missing from environment!');
}

export const supabase: SupabaseClient = createClient(
  supabaseUrl || 'https://placeholder.supabase.co',
  supabaseKey || 'placeholder-service-key'
);

// ====================================================================
// RESILIENT MULTI-TENANT IN-MEMORY SYNC STORE (Crash-Proof Fallback)
// ====================================================================
class TenantMemoryStore {
  clinics: Clinic[] = [
    {
      id: CLINIC_CONFIG.id,
      name: CLINIC_CONFIG.name,
      phone: CLINIC_CONFIG.phone,
      address: CLINIC_CONFIG.address,
      license_number: CLINIC_CONFIG.licenseNumber,
      tax_number: CLINIC_CONFIG.taxNumber,
      google_calendar_id: process.env.GOOGLE_CALENDAR_ID,
      created_at: new Date().toISOString(),
    },
  ];

  patients: Patient[] = [
    {
      id: 'patient-demo-001',
      clinic_id: CLINIC_CONFIG.id,
      whatsapp_phone: '+962791234567',
      full_name: 'أحمد التميمي',
      national_id: '9901020304',
      is_head_of_family: true,
      family_relation: 'self',
      pdpl_consent: true,
      pdpl_consent_timestamp: new Date().toISOString(),
      is_deleted: false,
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
    },
    {
      id: 'patient-demo-002',
      clinic_id: CLINIC_CONFIG.id,
      whatsapp_phone: '+962799887766',
      full_name: 'سارة عبد الله',
      national_id: '9951020305',
      is_head_of_family: true,
      family_relation: 'self',
      pdpl_consent: true,
      pdpl_consent_timestamp: new Date().toISOString(),
      is_deleted: false,
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
    },
  ];

  appointments: Appointment[] = [
    {
      id: 'appt-demo-001',
      clinic_id: CLINIC_CONFIG.id,
      patient_id: 'patient-demo-001',
      patient_name: 'أحمد التميمي',
      patient_phone: '+962791234567',
      service_type: 'consultation',
      start_time: new Date(Date.now() + 3600000 * 24).toISOString(), // Tomorrow
      end_time: new Date(Date.now() + 3600000 * 24 + 1800000).toISOString(),
      sterilization_end_time: new Date(Date.now() + 3600000 * 24 + 2700000).toISOString(),
      status: 'CONFIRMED',
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
    },
  ];

  waitlist: WaitlistEntry[] = [
    {
      id: 'wait-demo-001',
      clinic_id: CLINIC_CONFIG.id,
      patient_id: 'patient-demo-002',
      patient_name: 'سارة عبد الله',
      patient_phone: '+962799887766',
      requested_service: 'cleaning',
      preferred_date: new Date().toISOString().split('T')[0],
      preferred_time_range: 'any',
      status: 'WAITING',
      created_at: new Date().toISOString(),
    },
  ];

  invoices: Invoice[] = [];

  clinic_faqs: ClinicFaq[] = [
    {
      id: 'faq-hours',
      clinic_id: CLINIC_CONFIG.id,
      category: 'hours',
      question_ar: 'ما هي أوقات دوام وساعات العمل في العيادة؟',
      answer_ar: 'نستقبلكم يومياً من السبت إلى الخميس من الساعة 9:00 صباحاً حتى 9:00 مساءً. يوم الجمعة عطلة أسبوعية.',
      keywords: ['دوام', 'ساعات', 'اوقات', 'متى', 'فاتحين', 'تسكير', 'الجمعة', 'السبت'],
      created_at: new Date().toISOString(),
    },
    {
      id: 'faq-location',
      clinic_id: CLINIC_CONFIG.id,
      category: 'location',
      question_ar: 'أين موقع مركز نشمي وهل تتوفر مواقف سيارات؟',
      answer_ar: 'موقعنا في عمان، الشميساني - مقابل المستشفى التخصصي. يتوفر لدينا مواقف سيارات مجانية خاصة بالمراجعين مع خدمة فاليه مجانية لراحتكم.',
      keywords: ['موقع', 'مكان', 'وين', 'عنوان', 'باركنج', 'مواقف', 'فاليه', 'صفة', 'سيارة', 'الشميساني'],
      created_at: new Date().toISOString(),
    },
    {
      id: 'faq-insurance',
      clinic_id: CLINIC_CONFIG.id,
      category: 'insurance',
      question_ar: 'ما هي شركات وشبكات التأمين الطبي المعتمدة لديكم؟',
      answer_ar: 'معتمدون لدى كبرى شركات التأمين في الأردن: نات هيلث (NatHealth)، ميدنت (MedNet)، الشرق العربي للتأمين، GIG، والأولى للتأمين، بنسب تغطية تصل من 80% إلى 100% حسب فئة بطاقتك.',
      keywords: ['تأمين', 'شبكة', 'نات هيلث', 'ميدنت', 'الشرق العربي', 'gig', 'تغطية', 'بطاقة'],
      created_at: new Date().toISOString(),
    },
    {
      id: 'faq-pricing',
      clinic_id: CLINIC_CONFIG.id,
      category: 'pricing',
      question_ar: 'كم أسعار الكشفية والعلاجات وتنظيف الأسنان؟',
      answer_ar: 'الكشفية والاستشارة مع خطة العلاج 15-20 دينار (تُخصم من قيمة المعالجة عند البدء). تنظيف وتلميع الأسنان يبدأ من 25 دينار، وتبييض الأسنان بالليزر يبدأ من 80 دينار، والحشوات التجميلية تبدأ من 30 دينار. ولا يوجد أي رسوم عربون أو دفعة مسبقة للحجز.',
      keywords: ['سعر', 'اسعار', 'كشفية', 'تكلفة', 'تنظيف', 'تبييض', 'حشوة', 'كم يكلف', 'عربون', 'فلوس'],
      created_at: new Date().toISOString(),
    },
    {
      id: 'faq-services',
      clinic_id: CLINIC_CONFIG.id,
      category: 'services',
      question_ar: 'ما هي الخدمات والإجراءات الطبية المتوفرة في المركز؟',
      answer_ar: 'نقدم خدمات طب وجراحة الأسنان الشاملة: زراعة الأسنان الرقمية، تقويم الأسنان الشفاف والمعدني، ابتسامة هوليود والعدسات الخزفية، علاج العصب والجذور بجلسة واحدة، طب أسنان الأطفال، وتنظيف وتبييض الأسنان.',
      keywords: ['خدمات', 'علاج', 'زراعة', 'تقويم', 'ابتسامة', 'هوليود', 'عصب', 'أطفال', 'تجميل'],
      created_at: new Date().toISOString(),
    },
  ];

  conversations: ConversationState[] = [];
  processed_messages: Array<{ message_id: string; sender_phone?: string; message_type?: string; processed_at: string }> = [];
  failed_outbound_messages: FailedOutboundMessage[] = [];
  private isHydrated = false;

  constructor() {
    this.hydrateFromDisk();
  }

  hydrateFromDisk() {
    if (this.isHydrated) return;
    try {
      const disk = loadPersistentData();
      if (disk) {
        if (Array.isArray(disk.clinics) && disk.clinics.length > 0) this.clinics = disk.clinics;
        if (Array.isArray(disk.patients) && disk.patients.length > 0) this.patients = disk.patients;
        if (Array.isArray(disk.appointments) && disk.appointments.length > 0) this.appointments = disk.appointments;
        if (Array.isArray(disk.waitlist) && disk.waitlist.length > 0) this.waitlist = disk.waitlist;
        if (Array.isArray(disk.invoices) && disk.invoices.length > 0) this.invoices = disk.invoices;
        if (Array.isArray(disk.clinic_faqs) && disk.clinic_faqs.length > 0) this.clinic_faqs = disk.clinic_faqs;
        if (Array.isArray(disk.conversations) && disk.conversations.length > 0) this.conversations = disk.conversations;
        if (Array.isArray(disk.processed_messages) && disk.processed_messages.length > 0) this.processed_messages = disk.processed_messages;
        if (Array.isArray(disk.failed_outbound_messages) && disk.failed_outbound_messages.length > 0) this.failed_outbound_messages = disk.failed_outbound_messages;
        console.log(`[TenantStore] Hydrated from disk: ${this.appointments.length} appointments, ${this.conversations.length} conversations, ${this.processed_messages.length} processed msgs, ${this.failed_outbound_messages.length} failed msgs`);
      }
      this.isHydrated = true;
    } catch (err) {
      console.warn('[TenantStore] Error hydrating from disk:', err);
    }
  }
}

export const tenantStore = new TenantMemoryStore();

export function persistTenantStore(): void {
  try {
    savePersistentData({
      clinics: tenantStore.clinics,
      patients: tenantStore.patients,
      appointments: tenantStore.appointments,
      waitlist: tenantStore.waitlist,
      invoices: tenantStore.invoices,
      clinic_faqs: tenantStore.clinic_faqs,
      conversations: tenantStore.conversations,
      processed_messages: tenantStore.processed_messages,
      failed_outbound_messages: tenantStore.failed_outbound_messages,
    });
  } catch (err) {
    console.warn('[TenantStore] Error persisting to disk:', err);
  }
}

// ====================================================================
// MULTI-TENANT REPOSITORY METHODS
// ====================================================================

/**
 * Find or create a patient with family profile support and PDPL consent check.
 */
export async function findOrCreatePatient(params: {
  clinicId: string;
  phone: string;
  fullName: string;
  nationalId?: string;
  familyRelation?: 'self' | 'child' | 'spouse' | 'parent';
  primaryContactPhone?: string;
}): Promise<{ patient: Patient; isNew: boolean }> {
  const normalizedPhone = params.phone.trim();
  const name = params.fullName.trim();

  // 1. Search in local store
  let existing = tenantStore.patients.find(
    (p) =>
      p.clinic_id === params.clinicId &&
      p.whatsapp_phone === normalizedPhone &&
      p.full_name.toLowerCase() === name.toLowerCase() &&
      !p.is_deleted
  );

  // If name differs but phone is same, might be a family member profile!
  if (!existing && params.familyRelation && params.familyRelation !== 'self') {
    existing = tenantStore.patients.find(
      (p) =>
        p.clinic_id === params.clinicId &&
        p.whatsapp_phone === normalizedPhone &&
        p.full_name.toLowerCase() === name.toLowerCase() &&
        !p.is_deleted
    );
  }

  if (existing) {
    return { patient: existing, isNew: false };
  }

  // 2. Query Supabase
  try {
    const { data } = await supabase
      .from('patients')
      .select('*')
      .eq('clinic_id', params.clinicId)
      .eq('whatsapp_phone', normalizedPhone)
      .eq('full_name', name)
      .eq('is_deleted', false)
      .maybeSingle();

    if (data) {
      tenantStore.patients.push(data as Patient);
      return { patient: data as Patient, isNew: false };
    }
  } catch (err) {
    console.warn('[Supabase] Falling back to memory store for patient lookup:', err);
  }

  // 3. Create new Patient
  const newPatient: Patient = {
    id: `pat-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
    clinic_id: params.clinicId,
    whatsapp_phone: normalizedPhone,
    full_name: name,
    national_id: params.nationalId,
    is_head_of_family: !params.familyRelation || params.familyRelation === 'self',
    family_relation: params.familyRelation || 'self',
    primary_contact_phone: params.primaryContactPhone || normalizedPhone,
    pdpl_consent: false,
    is_deleted: false,
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString(),
  };

  tenantStore.patients.push(newPatient);
  persistTenantStore();

  try {
    await supabase.from('patients').insert(newPatient);
  } catch (err) {
    console.warn('[Supabase] Patient insert mirrored locally:', err);
  }

  return { patient: newPatient, isNew: true };
}

/**
 * Record PDPL Law No. 24 of 2023 Consent
 */
export async function recordPdplConsent(
  patientId: string,
  clinicId: string,
  granted: boolean
): Promise<boolean> {
  const patient = tenantStore.patients.find((p) => p.id === patientId && p.clinic_id === clinicId);
  const now = new Date().toISOString();
  if (patient) {
    patient.pdpl_consent = granted;
    patient.pdpl_consent_timestamp = now;
    patient.updated_at = now;
  }

  try {
    await supabase
      .from('patients')
      .update({
        pdpl_consent: granted,
        pdpl_consent_timestamp: now,
        updated_at: now,
      })
      .eq('id', patientId)
      .eq('clinic_id', clinicId);
  } catch (err) {
    console.warn('[Supabase] PDPL consent updated in memory:', err);
  }

  return true;
}

/**
 * Soft-Delete Patient (Jordanian Medical Liability Law No. 25 of 2018 - 5-year retention)
 */
export async function softDeletePatient(patientId: string, clinicId: string): Promise<boolean> {
  const patient = tenantStore.patients.find((p) => p.id === patientId && p.clinic_id === clinicId);
  const now = new Date().toISOString();
  if (patient) {
    patient.is_deleted = true;
    patient.deleted_at = now;
    patient.updated_at = now;
  }

  try {
    await supabase
      .from('patients')
      .update({
        is_deleted: true,
        deleted_at: now,
        updated_at: now,
      })
      .eq('id', patientId)
      .eq('clinic_id', clinicId);
  } catch (err) {
    console.warn('[Supabase] Soft-delete updated in memory:', err);
  }

  return true;
}

/**
 * Create Appointment (Frictionless Zero-Deposit with Concurrency Conflict Guard)
 */
export async function createAppointment(params: {
  clinicId: string;
  patientId: string;
  patientName: string;
  patientPhone: string;
  serviceType: ServiceType;
  startTime: string;
  endTime: string;
  sterilizationEndTime: string;
  googleCalendarEventId?: string;
  notes?: string;
  isEmergency?: boolean;
}): Promise<Appointment> {
  const reqStart = new Date(params.startTime).getTime();
  const reqEnd = new Date(params.sterilizationEndTime || params.endTime).getTime();

  // 1. Strict Concurrency Check in Local Memory Store (including 15-minute sterilization buffer)
  const localConflict = tenantStore.appointments.find((a) => {
    if (a.clinic_id !== params.clinicId) return false;
    if (a.status === 'CANCELLED') return false;

    const existingStart = new Date(a.start_time).getTime();
    const existingEnd = new Date(a.sterilization_end_time || a.end_time).getTime();

    // Overlap condition
    return reqStart < existingEnd && reqEnd > existingStart;
  });

  if (localConflict) {
    const conflictEndTime = new Date(localConflict.sterilization_end_time || localConflict.end_time)
      .toLocaleTimeString('ar-JO', { hour: '2-digit', minute: '2-digit' });
    const conflictErr: any = new Error(
      `DOUBLE_BOOKING_CONFLICT: يتعارض الموعد مع حجز مسبق حتى الساعة ${conflictEndTime} شاملاً فترة التعقيم الإلزامية (15 دقيقة).`
    );
    conflictErr.code = 'DOUBLE_BOOKING_CONFLICT';
    conflictErr.conflictingAppointment = localConflict;
    throw conflictErr;
  }

  // 2. Strict Concurrency Check against Supabase Database (Overlap with 15-minute sterilization buffer)
  try {
    const { data: dbConflicts } = await supabase
      .from('appointments')
      .select('*')
      .eq('clinic_id', params.clinicId)
      .neq('status', 'CANCELLED')
      .lt('start_time', params.sterilizationEndTime)
      .gt('sterilization_end_time', params.startTime);

    if (Array.isArray(dbConflicts) && dbConflicts.length > 0) {
      const conflict = dbConflicts[0];
      const conflictEndTime = new Date(conflict.sterilization_end_time || conflict.end_time)
        .toLocaleTimeString('ar-JO', { hour: '2-digit', minute: '2-digit' });
      const conflictErr: any = new Error(
        `DOUBLE_BOOKING_CONFLICT: يتعارض الموعد مع حجز مسجل في قاعدة البيانات حتى الساعة ${conflictEndTime} شاملاً فترة التعقيم.`
      );
      conflictErr.code = 'DOUBLE_BOOKING_CONFLICT';
      conflictErr.conflictingAppointment = conflict;
      throw conflictErr;
    }
  } catch (err: any) {
    if (err?.code === 'DOUBLE_BOOKING_CONFLICT') {
      throw err;
    }
    // Database check fallback - memory check passed
  }

  const appointmentDate = params.startTime.split('T')[0];
  const appt: Appointment = {
    id: `appt-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
    clinic_id: params.clinicId,
    patient_id: params.patientId,
    patient_name: params.patientName,
    patient_phone: params.patientPhone,
    service_type: params.serviceType,
    appointment_date: appointmentDate,
    start_time: params.startTime,
    end_time: params.endTime,
    sterilization_end_time: params.sterilizationEndTime,
    status: 'CONFIRMED',
    google_calendar_event_id: params.googleCalendarEventId,
    notes: params.notes,
    is_emergency: !!params.isEmergency,
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString(),
  };

  tenantStore.appointments.push(appt);
  persistTenantStore();

  try {
    const { error } = await supabase.from('appointments').insert({
      id: appt.id,
      clinic_id: appt.clinic_id,
      patient_id: appt.patient_id,
      patient_name: appt.patient_name,
      patient_phone: appt.patient_phone,
      service_type: appt.service_type,
      appointment_date: appt.appointment_date,
      start_time: appt.start_time,
      end_time: appt.end_time,
      sterilization_end_time: appt.sterilization_end_time,
      status: 'CONFIRMED',
      notes: appt.notes,
      created_at: appt.created_at,
    });
    if (error) {
      if (
        error.code === '23P01' ||
        error.message?.includes('exclusion') ||
        error.message?.includes('no_overlapping_appointments')
      ) {
        // Rollback memory store addition if DB exclusion constraint rejected it
        tenantStore.appointments = tenantStore.appointments.filter((a) => a.id !== appt.id);
        persistTenantStore();
        const conflictErr: any = new Error(
          'DOUBLE_BOOKING_CONFLICT: رفضت قاعدة البيانات الحجز لوجود تعارض زمني نشط (PostgreSQL Exclusion Constraint).'
        );
        conflictErr.code = 'DOUBLE_BOOKING_CONFLICT';
        throw conflictErr;
      }
      console.warn('[Supabase] Appointments insert notice:', error.message);
    }
  } catch (err: any) {
    if (err?.code === 'DOUBLE_BOOKING_CONFLICT') {
      throw err;
    }
    console.warn('[Supabase] Appointment stored locally:', err);
  }

  return appt;
}

/**
 * Deduplication via Supabase: Check and mark webhook message as processed.
 * Prevents processing the same message twice upon Meta Webhook retries in Serverless.
 * Returns true if message was already processed (duplicate), false if new.
 */
export async function isAndMarkWebhookMessageProcessed(params: {
  messageId: string;
  senderPhone?: string;
  messageType?: string;
}): Promise<boolean> {
  const { messageId, senderPhone, messageType } = params;
  if (!messageId) return false;

  // 1. In-memory deduplication check
  const alreadyInStore = tenantStore.processed_messages.some((m) => m.message_id === messageId);
  if (alreadyInStore) {
    return true;
  }

  // 2. Direct atomic check and insertion in Supabase
  try {
    const { data: existing } = await supabase
      .from('processed_webhook_messages')
      .select('id')
      .eq('id', messageId)
      .maybeSingle();

    if (existing) {
      tenantStore.processed_messages.push({
        message_id: messageId,
        sender_phone: senderPhone,
        message_type: messageType,
        processed_at: new Date().toISOString(),
      });
      persistTenantStore();
      return true;
    }

    const { error: insertErr } = await supabase
      .from('processed_webhook_messages')
      .insert({
        id: messageId,
        sender_phone: senderPhone,
        message_type: messageType || 'text',
        processed_at: new Date().toISOString(),
      });

    if (insertErr) {
      if (
        insertErr.code === '23505' ||
        insertErr.message?.includes('duplicate key') ||
        insertErr.message?.includes('unique constraint')
      ) {
        return true;
      }
    }
  } catch (dbErr) {
    console.warn('[Supabase] processed_webhook_messages check fallback:', dbErr);
  }

  // Record in local persistent store
  tenantStore.processed_messages.push({
    message_id: messageId,
    sender_phone: senderPhone,
    message_type: messageType,
    processed_at: new Date().toISOString(),
  });

  if (tenantStore.processed_messages.length > 2000) {
    tenantStore.processed_messages = tenantStore.processed_messages.slice(-2000);
  }

  persistTenantStore();
  return false;
}

/**
 * Deduplication Table TTL Cleanup:
 * Removes webhook messages older than maxAgeHours (default 48 hours) from
 * processed_webhook_messages and tenant store to prevent database bloat.
 */
export async function cleanupOldProcessedMessages(maxAgeHours: number = 48): Promise<{
  deletedCount: number;
  remainingCount: number;
  cutoffTime: string;
}> {
  const cutoffMs = Date.now() - maxAgeHours * 60 * 60 * 1000;
  const cutoffTime = new Date(cutoffMs).toISOString();

  let memoryDeleted = 0;
  const initialMemCount = tenantStore.processed_messages.length;
  tenantStore.processed_messages = tenantStore.processed_messages.filter((m) => {
    const time = new Date(m.processed_at).getTime();
    return time >= cutoffMs;
  });
  memoryDeleted = initialMemCount - tenantStore.processed_messages.length;
  persistTenantStore();

  let dbDeleted = 0;
  try {
    const { error, count } = await supabase
      .from('processed_webhook_messages')
      .delete({ count: 'exact' })
      .lt('processed_at', cutoffTime);

    if (!error && typeof count === 'number') {
      dbDeleted = count;
    }
  } catch (err) {
    console.warn('[Supabase Cleanup] TTL cleanup notice:', err);
  }

  const finalDeleted = Math.max(memoryDeleted, dbDeleted);
  console.log(`[Deduplication TTL Cleanup] Purged ${finalDeleted} messages older than ${maxAgeHours} hours (cutoff: ${cutoffTime})`);

  return {
    deletedCount: finalDeleted,
    remainingCount: tenantStore.processed_messages.length,
    cutoffTime,
  };
}

/**
 * Dead-Letter Outbound Log: Record failed outbound WhatsApp dispatches for human reception follow-up
 */
export async function logFailedOutboundMessage(params: {
  clinicId?: string;
  recipientPhone: string;
  messageText: string;
  errorReason: string;
}): Promise<FailedOutboundMessage> {
  const clinicId = params.clinicId || CLINIC_CONFIG.id;
  const entry: FailedOutboundMessage = {
    id: `fail-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
    clinic_id: clinicId,
    recipient_phone: params.recipientPhone,
    message_text: params.messageText,
    error_reason: params.errorReason,
    status: 'PENDING_HUMAN_REVIEW',
    created_at: new Date().toISOString(),
  };

  tenantStore.failed_outbound_messages.push(entry);
  persistTenantStore();

  try {
    await supabase.from('failed_outbound_messages').insert({
      id: entry.id,
      clinic_id: entry.clinic_id,
      recipient_phone: entry.recipient_phone,
      message_text: entry.message_text,
      error_reason: entry.error_reason,
      status: entry.status,
      created_at: entry.created_at,
    });
    console.log(`[Dead-Letter Log] Successfully logged failed message to ${params.recipientPhone} in Supabase`);
  } catch (err) {
    console.warn('[Supabase] Failed outbound message stored locally in tenantStore:', err);
  }

  return entry;
}

/**
 * Update Appointment Status (supports CANCELLED, NO_SHOW, COMPLETED)
 */
export async function updateAppointmentStatus(
  appointmentId: string,
  clinicId: string,
  status: AppointmentStatus
): Promise<Appointment | null> {
  const appt = tenantStore.appointments.find((a) => a.id === appointmentId && a.clinic_id === clinicId);
  const now = new Date().toISOString();
  if (appt) {
    appt.status = status;
    appt.updated_at = now;
    persistTenantStore();
  }

  try {
    await supabase
      .from('appointments')
      .update({ status, updated_at: now })
      .eq('id', appointmentId)
      .eq('clinic_id', clinicId);
  } catch (err) {
    console.warn('[Supabase] Appointment status updated locally:', err);
  }

  return appt || null;
}

/**
 * Add patient to Smart Waitlist
 */
export async function addToWaitlist(params: {
  clinicId: string;
  patientId: string;
  patientName: string;
  patientPhone: string;
  requestedService: ServiceType;
  preferredDate: string;
  preferredTimeRange?: 'morning' | 'afternoon' | 'any';
}): Promise<WaitlistEntry> {
  const entry: WaitlistEntry = {
    id: `wait-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
    clinic_id: params.clinicId,
    patient_id: params.patientId,
    patient_name: params.patientName,
    patient_phone: params.patientPhone,
    requested_service: params.requestedService,
    preferred_date: params.preferredDate,
    preferred_time_range: params.preferredTimeRange || 'any',
    status: 'WAITING',
    created_at: new Date().toISOString(),
  };

  tenantStore.waitlist.push(entry);
  persistTenantStore();

  try {
    await supabase.from('waitlist').insert(entry);
  } catch (err) {
    console.warn('[Supabase] Waitlist entry stored locally:', err);
  }

  return entry;
}

/**
 * Query waitlist for matching slots (Used by Waitlist Sniper)
 */
export async function findNextWaitlistCandidate(
  clinicId: string,
  serviceType: ServiceType,
  dateString: string
): Promise<WaitlistEntry | null> {
  const targetDate = dateString.split('T')[0];
  const candidate = tenantStore.waitlist.find(
    (w) =>
      w.clinic_id === clinicId &&
      w.status === 'WAITING' &&
      w.preferred_date === targetDate &&
      w.requested_service === serviceType
  );

  return candidate || null;
}

/**
 * Store JoFotara Invoice
 */
export async function saveInvoice(invoice: Invoice): Promise<Invoice> {
  tenantStore.invoices.push(invoice);
  persistTenantStore();
  try {
    await supabase.from('invoices').insert(invoice);
  } catch (err) {
    console.warn('[Supabase] Invoice stored locally:', err);
  }
  return invoice;
}

/**
 * Query Clinic FAQs by semantic/keyword match
 */
export async function queryClinicFaq(clinicId: string, queryText: string): Promise<ClinicFaq[]> {
  const q = (queryText || '').toLowerCase().trim();
  const words = q.split(/\s+/).filter((w) => w.length > 1);

  // 1. Check local memory store
  const localMatches = tenantStore.clinic_faqs.filter((faq) => {
    if (faq.clinic_id !== clinicId) return false;
    const matchCategory = q.includes(faq.category.toLowerCase());
    const matchQ = faq.question_ar.toLowerCase().includes(q) || words.some((w) => faq.question_ar.toLowerCase().includes(w));
    const matchA = faq.answer_ar.toLowerCase().includes(q) || words.some((w) => faq.answer_ar.toLowerCase().includes(w));
    const matchKeyword = faq.keywords.some((k) => q.includes(k.toLowerCase()) || words.some((w) => k.toLowerCase().includes(w)));
    return matchCategory || matchQ || matchA || matchKeyword;
  });

  if (localMatches.length > 0) {
    return localMatches;
  }

  // 2. Query Supabase
  try {
    const { data } = await supabase
      .from('clinic_faqs')
      .select('*')
      .eq('clinic_id', clinicId);

    if (data && data.length > 0) {
      for (const row of data) {
        if (!tenantStore.clinic_faqs.some((f) => f.id === row.id)) {
          tenantStore.clinic_faqs.push(row as ClinicFaq);
        }
      }
      return (data as ClinicFaq[]).filter((faq) => {
        const matchCategory = q.includes(faq.category.toLowerCase());
        const matchQ = faq.question_ar.toLowerCase().includes(q) || words.some((w) => faq.question_ar.toLowerCase().includes(w));
        const matchA = faq.answer_ar.toLowerCase().includes(q) || words.some((w) => faq.answer_ar.toLowerCase().includes(w));
        const matchKeyword = faq.keywords.some((k) => q.includes(k.toLowerCase()) || words.some((w) => k.toLowerCase().includes(w)));
        return matchCategory || matchQ || matchA || matchKeyword;
      });
    }
  } catch (err) {
    console.warn('[Supabase] Clinic FAQ query failed, using default FAQs:', err);
  }

  return tenantStore.clinic_faqs.filter((faq) => faq.clinic_id === clinicId);
}

/**
 * Get or create Conversation State for checkpointing
 */
export async function getOrCreateConversation(
  clinicId: string,
  phoneNumber: string,
  patientName?: string
): Promise<ConversationState> {
  const normalizedPhone = (phoneNumber || '+962791234567').trim();

  let conv = tenantStore.conversations.find(
    (c) => c.clinic_id === clinicId && c.phone_number === normalizedPhone
  );

  if (!conv) {
    // Try supabase
    try {
      const { data } = await supabase
        .from('conversations')
        .select('*')
        .eq('clinic_id', clinicId)
        .eq('phone_number', normalizedPhone)
        .maybeSingle();

      if (data) {
        conv = data as ConversationState;
        tenantStore.conversations.push(conv);
      }
    } catch (err) {
      console.warn('[Supabase] Conversation fetch fallback:', err);
    }
  }

  if (!conv) {
    conv = {
      id: `conv-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
      clinic_id: clinicId,
      phone_number: normalizedPhone,
      patient_name: patientName,
      chat_history: [],
      updated_at: new Date().toISOString(),
    };
    tenantStore.conversations.push(conv);

    try {
      await supabase.from('conversations').upsert({
        id: conv.id,
        clinic_id: conv.clinic_id,
        phone_number: conv.phone_number,
        patient_name: conv.patient_name,
        chat_history: conv.chat_history,
        updated_at: conv.updated_at,
      });
    } catch (err) {
      console.warn('[Supabase] Conversation upsert error:', err);
    }
  } else if (patientName && !conv.patient_name) {
    conv.patient_name = patientName;
  }

  return conv;
}

/**
 * Append message to chat_history and checkpoint to Supabase
 */
export async function appendChatHistory(
  clinicId: string,
  phoneNumber: string,
  role: 'user' | 'model',
  text: string,
  toolCalls?: any[]
): Promise<ConversationState> {
  const conv = await getOrCreateConversation(clinicId, phoneNumber);
  const newMsg: ChatHistoryMessage = {
    role,
    text,
    timestamp: new Date().toISOString(),
    toolCalls: toolCalls && toolCalls.length > 0 ? toolCalls : undefined,
  };

  conv.chat_history.push(newMsg);
  conv.updated_at = new Date().toISOString();

  // Cap stored history in memory to prevent memory bloat (keep last 50 turns)
  if (conv.chat_history.length > 50) {
    conv.chat_history = conv.chat_history.slice(-50);
  }

  persistTenantStore();

  // Persist checkpoint to Supabase
  try {
    await supabase.from('conversations').upsert({
      id: conv.id,
      clinic_id: conv.clinic_id,
      phone_number: conv.phone_number,
      patient_name: conv.patient_name,
      chat_history: conv.chat_history,
      updated_at: conv.updated_at,
    });
  } catch (err) {
    console.warn('[Supabase] Checkpointing chat history to DB fallback:', err);
  }

  return conv;
}

/**
 * Fetch all appointments from Supabase with resilient tenantStore sync
 */
export async function getAllAppointments(clinicId?: string): Promise<Appointment[]> {
  try {
    const query = supabase
      .from('appointments')
      .select('*')
      .order('start_time', { ascending: false });

    if (clinicId) {
      query.eq('clinic_id', clinicId);
    }

    const { data, error } = await query;
    if (data && data.length > 0) {
      for (const row of data) {
        const existingIdx = tenantStore.appointments.findIndex((a) => a.id === row.id);
        if (existingIdx >= 0) {
          tenantStore.appointments[existingIdx] = {
            ...tenantStore.appointments[existingIdx],
            ...row,
          };
        } else {
          tenantStore.appointments.push(row as Appointment);
        }
      }
      persistTenantStore();
    }
  } catch (err) {
    console.warn('[Supabase] Fetching appointments notice:', err);
  }

  return clinicId
    ? tenantStore.appointments.filter((a) => a.clinic_id === clinicId)
    : tenantStore.appointments;
}

/**
 * Get Conversation History for phone
 */
export async function getConversationHistory(
  clinicId: string,
  phoneNumber: string
): Promise<ConversationState | null> {
  const normalizedPhone = (phoneNumber || '+962791234567').trim();

  // First check in-memory / hydrated store
  let conv = tenantStore.conversations.find(
    (c) => c.clinic_id === clinicId && c.phone_number === normalizedPhone
  );

  // If not found or empty, try Supabase
  if (!conv || conv.chat_history.length === 0) {
    try {
      const { data } = await supabase
        .from('conversations')
        .select('*')
        .eq('clinic_id', clinicId)
        .eq('phone_number', normalizedPhone)
        .maybeSingle();

      if (data) {
        if (!conv) {
          conv = data as ConversationState;
          tenantStore.conversations.push(conv);
        } else {
          conv.chat_history = data.chat_history || [];
          conv.patient_name = data.patient_name || conv.patient_name;
        }
        persistTenantStore();
      }
    } catch (err) {
      console.warn('[Supabase] Conversation history query notice:', err);
    }
  }

  return conv || null;
}

/**
 * Clear conversation history for phone (Start fresh chat)
 */
export async function clearConversationHistory(
  clinicId: string,
  phoneNumber: string
): Promise<boolean> {
  const normalizedPhone = (phoneNumber || '+962791234567').trim();
  const conv = tenantStore.conversations.find(
    (c) => c.clinic_id === clinicId && c.phone_number === normalizedPhone
  );

  if (conv) {
    conv.chat_history = [];
    conv.updated_at = new Date().toISOString();
  }

  persistTenantStore();

  try {
    if (conv) {
      await supabase
        .from('conversations')
        .update({ chat_history: [], updated_at: new Date().toISOString() })
        .eq('id', conv.id);
    }
  } catch (err) {
    console.warn('[Supabase] Clear conversation notice:', err);
  }

  return true;
}


```

---

## <a id="lib-jobs-no-show-recovery-ts"></a>📁 `lib/jobs/no-show-recovery.ts`

```typescript
// File: lib/jobs/no-show-recovery.ts
// NashmiOps Enterprise (MVP Edition) - No-Show Recovery Background Job

import { Appointment } from '@/types';
import { tenantStore } from '@/lib/db/supabase';
import { sendWhatsAppTextMessage } from '@/lib/whatsapp/client';

export interface RecoveryAction {
  appointmentId: string;
  patientName: string;
  patientPhone: string;
  missedTime: string;
  reengagementMessage: string;
  sentAt: string;
}

/**
 * Scan for appointments with status NO_SHOW.
 * Dispatch a polite re-engagement WhatsApp message 1 hour post missed slot.
 */
export async function processNoShowRecovery(): Promise<{
  processedCount: number;
  actions: RecoveryAction[];
}> {
  const now = Date.now();
  const oneHourMs = 3600000;
  const actions: RecoveryAction[] = [];

  const noShows = tenantStore.appointments.filter((appt) => {
    if (appt.status !== 'NO_SHOW') return false;
    const apptTime = new Date(appt.start_time).getTime();
    // At least 1 hour elapsed since the appointment start time
    return now >= apptTime + oneHourMs;
  });

  for (const appt of noShows) {
    const formattedTime = new Date(appt.start_time).toLocaleTimeString('ar-JO', {
      hour: '2-digit',
      minute: '2-digit',
      hour12: true,
    });

    const reengagementMessage = `مرحباً ${appt.patient_name} يا هلا فيك،
لاحظنا أنك ما قدرت تحضر موعدك اليوم الساعة ${formattedTime} في مركز نشمي لطب وجراحة الأسنان بعمان.
سلامتك وأسنانك تهمنا كثير! ولا تشيل هم، بنقدر نحدد لك موعد بديل ومجاني في الوقت اللي بناسبك.
شو رأيك نجدول لك موعد جديد بكرة أو أي يوم ثاني هالأسبوع؟ تفضل بالرد وسأساعدك فوراً. 🦷`;

    actions.push({
      appointmentId: appt.id,
      patientName: appt.patient_name,
      patientPhone: appt.patient_phone,
      missedTime: appt.start_time,
      reengagementMessage,
      sentAt: new Date().toISOString(),
    });

    console.log(`[No-Show Recovery] Dispatched re-engagement message to ${appt.patient_phone}`);

    // Send real WhatsApp message
    try {
      await sendWhatsAppTextMessage(appt.patient_phone, reengagementMessage);
    } catch (err) {
      console.warn(`[No-Show Recovery] Failed to send recovery message to ${appt.patient_phone}:`, err);
    }
  }

  return {
    processedCount: actions.length,
    actions,
  };
}

```

---

## <a id="lib-jobs-smart-reminders-ts"></a>📁 `lib/jobs/smart-reminders.ts`

```typescript
// File: lib/jobs/smart-reminders.ts
// NashmiOps Enterprise (MVP Edition) - Smart Reminders Worker

import { Appointment } from '@/types';
import { tenantStore } from '@/lib/db/supabase';
import { CLINIC_CONFIG, CLINICAL_SERVICES } from '@/lib/config/constants';
import { sendWhatsAppTextMessage } from '@/lib/whatsapp/client';

export interface ReminderNotification {
  type: '24H_PRE_REMINDER' | '2H_PRE_LOCATION_PIN';
  appointmentId: string;
  patientName: string;
  patientPhone: string;
  scheduledTime: string;
  messageText: string;
  sentAt: string;
}

/**
 * Smart Reminders Worker:
 * 1. 24-hour reminder before appointment.
 * 2. 2-hour pre-appointment reminder containing native Amman Google Maps location link.
 */
export async function processSmartReminders(): Promise<{
  remindersSent: ReminderNotification[];
}> {
  const now = Date.now();
  const remindersSent: ReminderNotification[] = [];

  const confirmedAppts = tenantStore.appointments.filter(
    (a) => a.status === 'CONFIRMED'
  );

  for (const appt of confirmedAppts) {
    const apptTime = new Date(appt.start_time).getTime();
    const diffHours = (apptTime - now) / (1000 * 60 * 60);

    const formattedTime = new Date(appt.start_time).toLocaleTimeString('ar-JO', {
      hour: '2-digit',
      minute: '2-digit',
      hour12: true,
    });
    const formattedDate = appt.start_time.split('T')[0];
    const serviceName =
      CLINICAL_SERVICES[appt.service_type]?.nameAr || 'كشف واستشارة';

    // 2-hour reminder window (between 1.5 and 2.5 hours before appointment)
    if (diffHours > 0 && diffHours <= 2.5 && diffHours >= 1.5) {
      const messageText = `مرحباً ${appt.patient_name} يا هلا فيك،
تذكير: موعدك لـ (${serviceName}) في مركز نشمي لطب وجراحة الأسنان اليوم الساعة ${formattedTime} (خلال ساعتين).
📍 موقع العيادة المباشر على خرائط جوجل:
${CLINIC_CONFIG.googleMapsUrl}
(عمان - الدوار السابع - مجمع النشامى الطبي - الطابق الثالث)
نتشرف بزيارتك ونتمنى لك دوام الصحة والعافية! 🦷`;

      remindersSent.push({
        type: '2H_PRE_LOCATION_PIN',
        appointmentId: appt.id,
        patientName: appt.patient_name,
        patientPhone: appt.patient_phone,
        scheduledTime: appt.start_time,
        messageText,
        sentAt: new Date().toISOString(),
      });

      // Send real WhatsApp message
      try {
        await sendWhatsAppTextMessage(appt.patient_phone, messageText);
      } catch (err) {
        console.warn(`[Smart Reminders] Failed to send 2H reminder to ${appt.patient_phone}:`, err);
      }
    }
    // 24-hour reminder window (between 23 and 25 hours before appointment)
    else if (diffHours > 23 && diffHours <= 25) {
      const messageText = `مرحباً ${appt.patient_name}،
تذكير بموعدك القادم غداً ${formattedDate} الساعة ${formattedTime} لدى مركز نشمي لطب الأسنان بعمان.
إذا كان كل شيء مناسب، موعدك مؤكد 100% ولا تحتاج لأي تأكيد إضافي. تفضل بإعلامنا إذا رغبت بتعديل الموعد. يا هلا فيك! 🦷`;

      remindersSent.push({
        type: '24H_PRE_REMINDER',
        appointmentId: appt.id,
        patientName: appt.patient_name,
        patientPhone: appt.patient_phone,
        scheduledTime: appt.start_time,
        messageText,
        sentAt: new Date().toISOString(),
      });

      // Send real WhatsApp message
      try {
        await sendWhatsAppTextMessage(appt.patient_phone, messageText);
      } catch (err) {
        console.warn(`[Smart Reminders] Failed to send 24H reminder to ${appt.patient_phone}:`, err);
      }
    }
  }

  return { remindersSent };
}

```

---

## <a id="lib-jobs-waitlist-sniper-ts"></a>📁 `lib/jobs/waitlist-sniper.ts`

```typescript
// File: lib/jobs/waitlist-sniper.ts
// NashmiOps Enterprise (MVP Edition) - Waitlist Sniper

import { Appointment, WaitlistEntry } from '@/types';
import { tenantStore } from '@/lib/db/supabase';
import { CLINIC_CONFIG, CLINICAL_SERVICES } from '@/lib/config/constants';
import { sendWhatsAppTextMessage } from '@/lib/whatsapp/client';

export interface SniperResult {
  triggered: boolean;
  cancelledAppointmentId: string;
  candidateFound: boolean;
  notifiedCandidate?: WaitlistEntry;
  metaTemplatePayload?: {
    to: string;
    templateName: string;
    language: string;
    messageText: string;
  };
}

/**
 * Waitlist Sniper: Autonomously triggered when an appointment is cancelled.
 * It immediately matches waiting patients and sends a Meta WhatsApp Utility Template.
 */
export async function triggerWaitlistSniper(
  cancelledAppt: Appointment
): Promise<SniperResult> {
  const apptDate = cancelledAppt.start_time.split('T')[0];
  const apptTime = new Date(cancelledAppt.start_time).toLocaleTimeString('ar-JO', {
    hour: '2-digit',
    minute: '2-digit',
    hour12: true,
  });

  // Find next waiting patient for this clinic, matching service or date
  const candidate = tenantStore.waitlist.find(
    (w) =>
      w.clinic_id === cancelledAppt.clinic_id &&
      w.status === 'WAITING' &&
      (w.preferred_date === apptDate || w.preferred_date <= apptDate)
  );

  if (!candidate) {
    return {
      triggered: true,
      cancelledAppointmentId: cancelledAppt.id,
      candidateFound: false,
    };
  }

  // Update candidate status
  candidate.status = 'NOTIFIED';
  candidate.notified_at = new Date().toISOString();

  const serviceName =
    CLINICAL_SERVICES[cancelledAppt.service_type]?.nameAr || 'كشف واستشارة';

  // Meta WhatsApp Utility Template Format (Jordanian Arabic)
  const messageText = `مرحباً ${candidate.patient_name} يا هلا فيك،
توفر موعد شاغر مبكر في مركز نشمي لطب وجراحة الأسنان بعمان!
🗓️ التاريخ: ${apptDate}
⏰ الوقت: ${apptTime}
🩺 الخدمة: ${serviceName}

إذا بتحب تأكد الموعد الآن، بس رد بـ "نعم أكد الموعد" وراح نسجله لك فوراً! 🦷`;

  const metaTemplatePayload = {
    to: candidate.patient_phone,
    templateName: 'waitlist_slot_notification_ar',
    language: 'ar',
    messageText,
  };

  console.log(`[Waitlist Sniper] Dispatched slot offer to ${candidate.patient_phone} for slot ${apptDate} ${apptTime}`);

  // Send real outbound WhatsApp message to candidate patient
  try {
    await sendWhatsAppTextMessage(candidate.patient_phone, messageText);
  } catch (outboundErr) {
    console.warn('[Waitlist Sniper] Failed to send outbound WhatsApp message:', outboundErr);
  }

  return {
    triggered: true,
    cancelledAppointmentId: cancelledAppt.id,
    candidateFound: true,
    notifiedCandidate: candidate,
    metaTemplatePayload,
  };
}

```

---

## <a id="lib-jofotara-client-ts"></a>📁 `lib/jofotara/client.ts`

```typescript
// File: lib/jofotara/client.ts
// NashmiOps Enterprise (MVP Edition) - ISTD JoFotara Network API Client
// Handles official HTTP transmission of UBL 2.1 XML to the Jordanian Income and Sales Tax Department (ISTD)
// Supports B2C Simplified Reporting & B2B Standard Clearance workflows with automatic Simulated Mode

import { InvoiceType } from '@/types';
import { CLINIC_CONFIG } from '@/lib/config/constants';

export interface JoFotaraSubmissionInput {
  invoiceNumber: string;
  invoiceType: InvoiceType;
  ublXml: string;
  invoiceUuid: string;
  invoiceHash: string;
  buyerName?: string;
  buyerTaxId?: string;
  totalAmount?: number;
}

export interface JoFotaraSubmissionResult {
  success: boolean;
  status: 'REPORTED' | 'CLEARED' | 'REJECTED' | 'ERROR';
  submissionId?: string;
  invoiceUuid: string;
  invoiceHash: string;
  endpointUsed: string;
  simulated: boolean;
  clearanceStatus?: string;
  validationErrors?: string[];
  message: string;
  responsePayload?: any;
}

/**
 * Resolve JoFotara ISTD API Configuration
 */
export function getJoFotaraConfig() {
  const baseUrl = process.env.JOFOTARA_API_BASE_URL;
  const clientSecret = process.env.JOFOTARA_CLIENT_SECRET;
  const clientId = process.env.JOFOTARA_CLIENT_ID || CLINIC_CONFIG.taxNumber;

  const isConfigured = Boolean(baseUrl && clientSecret && !clientSecret.startsWith('mock_'));

  return {
    baseUrl: baseUrl ? baseUrl.replace(/\/+$/, '') : 'https://preprod.jofotara.gov.jo/core/invoices',
    clientSecret,
    clientId,
    isSimulated: !isConfigured,
  };
}

/**
 * Submit UBL 2.1 Invoice to ISTD JoFotara:
 * - Reporting Route: B2C_SIMPLIFIED invoices (< 100 JOD or personal medical consultations)
 * - Clearance Route: B2B_STANDARD invoices (Mandatory Buyer Tax ID & pre-clearance requirement)
 */
export async function submitInvoiceToJoFotara(
  input: JoFotaraSubmissionInput
): Promise<JoFotaraSubmissionResult> {
  const config = getJoFotaraConfig();
  const isB2B = input.invoiceType === 'B2B_STANDARD';
  const targetRoute = isB2B ? '/clearance' : '/reporting';
  const fullEndpoint = `${config.baseUrl}${targetRoute}`;

  // 1. Automatic Simulated Mode when live ISTD credentials are not set
  if (config.isSimulated) {
    const simSubmissionId = `istd-sim-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`;
    const resultStatus = isB2B ? 'CLEARED' : 'REPORTED';
    
    console.log(`[JoFotara Client - Simulated Mode] Submitted ${input.invoiceType} invoice (${input.invoiceNumber}) to ${targetRoute}:`);
    console.log(`  UUID: ${input.invoiceUuid}`);
    console.log(`  Hash: ${input.invoiceHash.substring(0, 24)}...`);
    console.log(`  Assigned Submission ID: ${simSubmissionId}`);
    console.log(`  Status: ${resultStatus} 100% Valid UBL 2.1 XML`);

    return {
      success: true,
      status: resultStatus,
      submissionId: simSubmissionId,
      invoiceUuid: input.invoiceUuid,
      invoiceHash: input.invoiceHash,
      endpointUsed: fullEndpoint,
      simulated: true,
      clearanceStatus: isB2B ? 'CLEARED_BY_ISTD' : 'REPORTED_TO_ISTD',
      message: isB2B
        ? `تمت إجازة الفاتورة الضريبية القياسية (B2B Clearance) عبر محاكي بوابة الفوترة الوطنية (ISTD) بنجاح.`
        : `تم الإبلاغ الضريبي عن الفاتورة المبسطة (B2C Reporting) عبر محاكي بوابة الفوترة الوطنية (ISTD) بنجاح.`,
    };
  }

  // 2. Live HTTP POST to ISTD JoFotara Gateway
  try {
    const encodedXml = Buffer.from(input.ublXml, 'utf-8').toString('base64');
    const requestPayload = {
      invoice: encodedXml,
      invoiceHash: input.invoiceHash,
      uuid: input.invoiceUuid,
      invoiceNumber: input.invoiceNumber,
      invoiceType: input.invoiceType,
      sellerTaxId: CLINIC_CONFIG.taxNumber,
      buyerTaxId: input.buyerTaxId,
      timestamp: new Date().toISOString(),
    };

    const response = await fetch(fullEndpoint, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Client-Id': config.clientId,
        'Client-Secret': config.clientSecret!,
        Authorization: `Bearer ${config.clientSecret}`,
      },
      body: JSON.stringify(requestPayload),
    });

    const data = await response.json().catch(() => null);

    if (!response.ok) {
      console.warn(`[JoFotara Client] ISTD API HTTP ${response.status} Error on ${targetRoute}:`, data);
      return {
        success: false,
        status: response.status === 422 ? 'REJECTED' : 'ERROR',
        invoiceUuid: input.invoiceUuid,
        invoiceHash: input.invoiceHash,
        endpointUsed: fullEndpoint,
        simulated: false,
        validationErrors: data?.errors || [data?.message || `HTTP ${response.status} from ISTD Gateway`],
        responsePayload: data,
        message: `تعذر اعتماد الفاتورة لدى بوابة ضريبة الدخل (HTTP ${response.status}): ${data?.message || 'خطأ في معالجة الطلب'}`,
      };
    }

    const assignedStatus = isB2B ? 'CLEARED' : 'REPORTED';
    const submissionId = data?.submissionId || data?.id || `istd-live-${Date.now()}`;

    console.log(`[JoFotara Client] Successfully transmitted to ISTD (ID: ${submissionId}, Status: ${assignedStatus})`);

    return {
      success: true,
      status: assignedStatus,
      submissionId,
      invoiceUuid: input.invoiceUuid,
      invoiceHash: input.invoiceHash,
      endpointUsed: fullEndpoint,
      simulated: false,
      clearanceStatus: isB2B ? 'CLEARED' : 'REPORTED',
      responsePayload: data,
      message: isB2B
        ? `تمت إجازة وتصديق الفاتورة رسمياً من دائرة ضريبة الدخل والمبيعات الأردنية (ISTD Clearance ID: ${submissionId}).`
        : `تم تسجيل وإبلاغ دائرة ضريبة الدخل والمبيعات الأردنية بالفاتورة بنجاح (ISTD Reporting ID: ${submissionId}).`,
    };
  } catch (netErr: any) {
    console.error(`[JoFotara Client] Network exception transmitting to ${fullEndpoint}:`, netErr?.message || netErr);
    return {
      success: false,
      status: 'ERROR',
      invoiceUuid: input.invoiceUuid,
      invoiceHash: input.invoiceHash,
      endpointUsed: fullEndpoint,
      simulated: false,
      validationErrors: [netErr?.message || 'Network exception contacting ISTD gateway'],
      message: `خطأ اتصال بشبكة دائرة ضريبة الدخل والمبيعات: ${netErr?.message || 'انقطاع الاتصال'}`,
    };
  }
}

```

---

## <a id="lib-jofotara-xml-compiler-ts"></a>📁 `lib/jofotara/xml-compiler.ts`

```typescript
// File: lib/jofotara/xml-compiler.ts
// NashmiOps Enterprise (MVP Edition) - ISTD JoFotara Phase 2 UBL 2.1 XML Compiler

import crypto from 'crypto';
import { Invoice, InvoiceItem, InvoiceType } from '@/types';
import { CLINIC_CONFIG } from '@/lib/config/constants';

export interface JoFotaraCompileInput {
  invoiceNumber: string;
  invoiceType: InvoiceType;
  buyerName: string;
  buyerTaxId?: string; // Mandatory for B2B_STANDARD
  buyerNationalId?: string; // Optional for B2C_SIMPLIFIED
  items: InvoiceItem[];
  previousInvoiceHash?: string;
  issueDate?: string; // YYYY-MM-DD
  issueTime?: string; // HH:mm:ss
}

/**
 * Generate Tag-Length-Value (TLV) encoded Base64 QR code for JoFotara & Levant specifications
 * Tag 1: Seller Name
 * Tag 2: Seller Tax Registration Number
 * Tag 3: Timestamp (ISO 8601)
 * Tag 4: Invoice Total (including tax)
 * Tag 5: Tax Total
 */
export function generateJoFotaraTLV(params: {
  sellerName: string;
  sellerTaxId: string;
  timestamp: string;
  invoiceTotal: number;
  taxTotal: number;
}): string {
  const encodeTag = (tag: number, value: string): Buffer => {
    const valBuf = Buffer.from(value, 'utf8');
    const tagBuf = Buffer.from([tag]);
    const lenBuf = Buffer.from([valBuf.length]);
    return Buffer.concat([tagBuf, lenBuf, valBuf]);
  };

  const tag1 = encodeTag(1, params.sellerName);
  const tag2 = encodeTag(2, params.sellerTaxId);
  const tag3 = encodeTag(3, params.timestamp);
  const tag4 = encodeTag(4, params.invoiceTotal.toFixed(3));
  const tag5 = encodeTag(5, params.taxTotal.toFixed(3));

  const fullBuffer = Buffer.concat([tag1, tag2, tag3, tag4, tag5]);
  return fullBuffer.toString('base64');
}

/**
 * Compile UBL 2.1 XML for ISTD JoFotara Phase 2
 */
export function compileJoFotaraXML(input: JoFotaraCompileInput): {
  xml: string;
  uuid: string;
  invoiceHash: string;
  pih: string;
  tlvQrCode: string;
  subtotal: number;
  taxAmount: number;
  totalAmount: number;
  invoiceNumber?: string;
  invoiceType?: InvoiceType;
  issueDate?: string;
  issueTime?: string;
  buyerName?: string;
  buyerTaxId?: string;
  buyerNationalId?: string;
  items?: InvoiceItem[];
} {
  // 1. Validation Rules per Phase 2 mandate
  if (input.invoiceType === 'B2B_STANDARD') {
    if (!input.buyerTaxId || input.buyerTaxId.trim().length < 7) {
      throw new Error(
        'B2B Standard Tax Invoice requires a valid Buyer Tax ID (الرقم الضريبي للمشتري) per ISTD JoFotara regulations.'
      );
    }
  }

  // 2. Financial Calculations (JOD with 3 decimal places)
  let subtotal = 0;
  let taxAmount = 0;

  input.items.forEach((item) => {
    const itemSubtotal = item.unitPrice * item.quantity;
    const itemTax = itemSubtotal * item.taxRate;
    subtotal += itemSubtotal;
    taxAmount += itemTax;
  });

  subtotal = Math.round(subtotal * 1000) / 1000;
  taxAmount = Math.round(taxAmount * 1000) / 1000;
  const totalAmount = Math.round((subtotal + taxAmount) * 1000) / 1000;

  // Auto-branching: if total is < 100 JOD and no tax ID provided, it defaults safely to B2C Simplified
  const effectiveType: InvoiceType =
    input.invoiceType === 'B2B_STANDARD' ? 'B2B_STANDARD' : 'B2C_SIMPLIFIED';

  const uuid = crypto.randomUUID();
  const dateStr = input.issueDate || new Date().toISOString().split('T')[0];
  const timeStr = input.issueTime || new Date().toISOString().split('T')[1].split('.')[0];
  const timestampIso = `${dateStr}T${timeStr}Z`;

  // Cryptographic chaining: Previous Invoice Hash (PIH)
  const defaultPIH = 'NWZlY2ViNjAxOTEzMWIxMWNmMzQ1OGE3MDU4NDhhZGIxY2VmY2Q1NzcxN2FkNzhmNWQ5NzU0NzA1OWUyYzg2';
  const pih = input.previousInvoiceHash || defaultPIH;

  // TLV Base64 QR Code
  const tlvQrCode = generateJoFotaraTLV({
    sellerName: CLINIC_CONFIG.name,
    sellerTaxId: CLINIC_CONFIG.taxNumber,
    timestamp: timestampIso,
    invoiceTotal: totalAmount,
    taxTotal: taxAmount,
  });

  // 3. Construct UBL 2.1 XML with cbc, cac, ext namespaces
  const ublInvoiceTypeCode = effectiveType === 'B2C_SIMPLIFIED' ? '388' : '388';
  const ublProfileId = effectiveType === 'B2C_SIMPLIFIED' ? 'reporting:1.0' : 'clearance:1.0';

  const itemsXml = input.items
    .map((item, idx) => {
      const lineTotal = item.unitPrice * item.quantity;
      const lineTax = lineTotal * item.taxRate;
      return `
    <cac:InvoiceLine>
      <cbc:ID>${idx + 1}</cbc:ID>
      <cbc:InvoicedQuantity unitCode="EA">${item.quantity}</cbc:InvoicedQuantity>
      <cbc:LineExtensionAmount currencyID="JOD">${lineTotal.toFixed(3)}</cbc:LineExtensionAmount>
      <cac:TaxTotal>
        <cbc:TaxAmount currencyID="JOD">${lineTax.toFixed(3)}</cbc:TaxAmount>
        <cac:TaxSubtotal>
          <cbc:TaxableAmount currencyID="JOD">${lineTotal.toFixed(3)}</cbc:TaxableAmount>
          <cbc:TaxAmount currencyID="JOD">${lineTax.toFixed(3)}</cbc:TaxAmount>
          <cac:TaxCategory>
            <cbc:ID>${item.taxRate > 0 ? 'S' : 'Z'}</cbc:ID>
            <cbc:Percent>${(item.taxRate * 100).toFixed(2)}</cbc:Percent>
            <cac:TaxScheme>
              <cbc:ID>VAT</cbc:ID>
            </cac:TaxScheme>
          </cac:TaxCategory>
        </cac:TaxSubtotal>
      </cac:TaxTotal>
      <cac:Item>
        <cbc:Description>${item.name}</cbc:Description>
        <cbc:Name>${item.name}</cbc:Name>
      </cac:Item>
      <cac:Price>
        <cbc:PriceAmount currencyID="JOD">${item.unitPrice.toFixed(3)}</cbc:PriceAmount>
      </cac:Price>
    </cac:InvoiceLine>`;
    })
    .join('');

  const buyerPartyXml =
    effectiveType === 'B2B_STANDARD'
      ? `
    <cac:AccountingCustomerParty>
      <cac:Party>
        <cac:PartyIdentification>
          <cbc:ID schemeID="TIN">${input.buyerTaxId}</cbc:ID>
        </cac:PartyIdentification>
        <cac:PartyName>
          <cbc:Name>${input.buyerName}</cbc:Name>
        </cac:PartyName>
        <cac:PartyTaxScheme>
          <cbc:CompanyID>${input.buyerTaxId}</cbc:CompanyID>
          <cac:TaxScheme>
            <cbc:ID>VAT</cbc:ID>
          </cac:TaxScheme>
        </cac:PartyTaxScheme>
      </cac:Party>
    </cac:AccountingCustomerParty>`
      : `
    <cac:AccountingCustomerParty>
      <cac:Party>
        <cac:PartyName>
          <cbc:Name>${input.buyerName || 'مريض نقدي'}</cbc:Name>
        </cac:PartyName>
        ${
          input.buyerNationalId
            ? `<cac:PartyIdentification><cbc:ID schemeID="NAT">${input.buyerNationalId}</cbc:ID></cac:PartyIdentification>`
            : ''
        }
      </cac:Party>
    </cac:AccountingCustomerParty>`;

  const xml = `<?xml version="1.0" encoding="UTF-8"?>
<Invoice xmlns="urn:oasis:names:specification:ubl:schema:xsd:Invoice-2"
         xmlns:cac="urn:oasis:names:specification:ubl:schema:xsd:CommonAggregateComponents-2"
         xmlns:cbc="urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2"
         xmlns:ext="urn:oasis:names:specification:ubl:schema:xsd:CommonExtensionComponents-2">
  <ext:UBLExtensions>
    <ext:UBLExtension>
      <ext:ExtensionURI>urn:oasis:names:specification:ubl:dsig:enveloped:xades</ext:ExtensionURI>
      <ext:ExtensionContent>
        <sig:UBLDocumentSignatures xmlns:sig="urn:oasis:names:specification:ubl:schema:xsd:CommonSignatureComponents-2">
          <sac:SignatureInformation xmlns:sac="urn:oasis:names:specification:ubl:schema:xsd:SignatureAggregateComponents-2">
            <cbc:ID>urn:oasis:names:specification:ubl:signature:1</cbc:ID>
            <sbc:ReferencedSignatureID xmlns:sbc="urn:oasis:names:specification:ubl:schema:xsd:SignatureBasicComponents-2">urn:oasis:names:specification:ubl:signature:Invoice</sbc:ReferencedSignatureID>
          </sac:SignatureInformation>
        </sig:UBLDocumentSignatures>
      </ext:ExtensionContent>
    </ext:UBLExtension>
  </ext:UBLExtensions>
  <cbc:ProfileID>${ublProfileId}</cbc:ProfileID>
  <cbc:ID>${input.invoiceNumber}</cbc:ID>
  <cbc:UUID>${uuid}</cbc:UUID>
  <cbc:IssueDate>${dateStr}</cbc:IssueDate>
  <cbc:IssueTime>${timeStr}</cbc:IssueTime>
  <cbc:InvoiceTypeCode name="0111110">${ublInvoiceTypeCode}</cbc:InvoiceTypeCode>
  <cbc:DocumentCurrencyCode>JOD</cbc:DocumentCurrencyCode>
  <cbc:TaxCurrencyCode>JOD</cbc:TaxCurrencyCode>

  <!-- Cryptographic Chaining: Previous Invoice Hash (PIH) -->
  <cac:AdditionalDocumentReference>
    <cbc:ID>PIH</cbc:ID>
    <cac:Attachment>
      <cac:EmbeddedDocumentBinaryObject mimeCode="text/plain">${pih}</cac:EmbeddedDocumentBinaryObject>
    </cac:Attachment>
  </cac:AdditionalDocumentReference>

  <!-- Embedded Cryptographic TLV QR Code -->
  <cac:AdditionalDocumentReference>
    <cbc:ID>QR</cbc:ID>
    <cac:Attachment>
      <cac:EmbeddedDocumentBinaryObject mimeCode="text/plain">${tlvQrCode}</cac:EmbeddedDocumentBinaryObject>
    </cac:Attachment>
  </cac:AdditionalDocumentReference>

  <!-- Seller Party (Nashmi Dental Clinic) -->
  <cac:AccountingSupplierParty>
    <cac:Party>
      <cac:PartyIdentification>
        <cbc:ID schemeID="TIN">${CLINIC_CONFIG.taxNumber}</cbc:ID>
      </cac:PartyIdentification>
      <cac:PartyName>
        <cbc:Name>${CLINIC_CONFIG.name}</cbc:Name>
      </cac:PartyName>
      <cac:PostalAddress>
        <cbc:CityName>Amman</cbc:CityName>
        <cbc:CountrySubentity>Amman Governorate</cbc:CountrySubentity>
        <cac:Country>
          <cbc:IdentificationCode>JO</cbc:IdentificationCode>
        </cac:Country>
      </cac:PostalAddress>
      <cac:PartyTaxScheme>
        <cbc:CompanyID>${CLINIC_CONFIG.taxNumber}</cbc:CompanyID>
        <cac:TaxScheme>
          <cbc:ID>VAT</cbc:ID>
        </cac:TaxScheme>
      </cac:PartyTaxScheme>
    </cac:Party>
  </cac:AccountingSupplierParty>

  <!-- Buyer Party -->
  ${buyerPartyXml}

  <!-- Legal Monetary Total -->
  <cac:TaxTotal>
    <cbc:TaxAmount currencyID="JOD">${taxAmount.toFixed(3)}</cbc:TaxAmount>
  </cac:TaxTotal>
  <cac:LegalMonetaryTotal>
    <cbc:LineExtensionAmount currencyID="JOD">${subtotal.toFixed(3)}</cbc:LineExtensionAmount>
    <cbc:TaxExclusiveAmount currencyID="JOD">${subtotal.toFixed(3)}</cbc:TaxExclusiveAmount>
    <cbc:TaxInclusiveAmount currencyID="JOD">${totalAmount.toFixed(3)}</cbc:TaxInclusiveAmount>
    <cbc:PayableAmount currencyID="JOD">${totalAmount.toFixed(3)}</cbc:PayableAmount>
  </cac:LegalMonetaryTotal>

  <!-- Invoice Lines -->
  ${itemsXml}
</Invoice>`;

  // 4. Compute SHA-256 Hash of canonicalized XML for cryptographic tamper-proofing
  const invoiceHash = crypto.createHash('sha256').update(xml, 'utf8').digest('hex');

  return {
    xml,
    uuid,
    invoiceHash,
    pih,
    tlvQrCode,
    subtotal,
    taxAmount,
    totalAmount,
    invoiceNumber: input.invoiceNumber,
    invoiceType: effectiveType,
    issueDate: dateStr,
    issueTime: timeStr,
    buyerName: input.buyerName,
    buyerTaxId: input.buyerTaxId,
    buyerNationalId: input.buyerNationalId,
    items: input.items,
  };
}

```

---

## <a id="lib-whatsapp-client-ts"></a>📁 `lib/whatsapp/client.ts`

```typescript
// File: lib/whatsapp/client.ts
// NashmiOps Enterprise (MVP Edition) - Meta WhatsApp Cloud API Client
// Outbound Messaging, Real Voice Note (Audio) Fetching, and Media Transformation

import { logFailedOutboundMessage } from '@/lib/db/supabase';

export interface WhatsAppSendResult {
  success: boolean;
  messageId?: string;
  recipient: string;
  error?: string;
  simulated?: boolean;
}

/**
 * Format recipient phone number for Meta WhatsApp Cloud API (e.g. 962791234567 without '+')
 */
export function formatMetaRecipientPhone(phone: string): string {
  let clean = phone.replace(/[^\d]/g, '');
  if (clean.startsWith('00')) {
    clean = clean.substring(2);
  }
  // Convert local Jordan 07XXXXXXXX to 9627XXXXXXXX
  if (clean.startsWith('07') && clean.length === 10) {
    clean = `962${clean.substring(1)}`;
  }
  return clean;
}

/**
 * Send WhatsApp Text Message via Meta Cloud API v21.0
 */
export async function sendWhatsAppTextMessage(
  to: string,
  messageText: string
): Promise<WhatsAppSendResult> {
  const token =
    process.env.META_WHATSAPP_ACCESS_TOKEN ||
    process.env.META_WHATSAPP_TOKEN;

  const phoneNumberId =
    process.env.META_WHATSAPP_PHONE_NUMBER_ID ||
    process.env.META_PHONE_NUMBER_ID ||
    '962790000000';

  const recipient = formatMetaRecipientPhone(to);

  if (!token || token.startsWith('mock_')) {
    console.log(
      `[WhatsApp Client - Simulated Mode] Dispatching text to ${recipient} via PhoneID ${phoneNumberId}:\n"${messageText.substring(0, 100)}..."`
    );
    return {
      success: true,
      messageId: `wamid.simulated.${Date.now()}`,
      recipient,
      simulated: true,
    };
  }

  const endpoint = `https://graph.facebook.com/v21.0/${phoneNumberId}/messages`;

  try {
    const payload = {
      messaging_product: 'whatsapp',
      recipient_type: 'individual',
      to: recipient,
      type: 'text',
      text: {
        preview_url: false,
        body: messageText,
      },
    };

    const res = await fetch(endpoint, {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${token}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(payload),
    });

    const data = await res.json().catch(() => null);

    if (!res.ok) {
      const errorMsg = data?.error?.message || `HTTP error ${res.status}`;
      console.warn(`[WhatsApp Client] Meta API error HTTP ${res.status}:`, data);

      // Dead-Letter Handling: Log failed dispatch for receptionist review
      await logFailedOutboundMessage({
        recipientPhone: recipient,
        messageText,
        errorReason: `Meta API HTTP ${res.status}: ${errorMsg}`,
      }).catch((logErr) => console.warn('[WhatsApp Client] Dead-letter logging notice:', logErr));

      return {
        success: false,
        recipient,
        error: errorMsg,
      };
    }

    const messageId = data?.messages?.[0]?.id;
    console.log(`[WhatsApp Client] Message sent successfully (ID: ${messageId}) to ${recipient}`);

    return {
      success: true,
      messageId,
      recipient,
    };
  } catch (err: any) {
    const errorMsg = err?.message || 'Network exception sending WhatsApp message';
    console.error(`[WhatsApp Client] Network error sending message to ${recipient}:`, errorMsg);

    // Dead-Letter Handling: Log failed dispatch for receptionist review
    await logFailedOutboundMessage({
      recipientPhone: recipient,
      messageText,
      errorReason: `Network Exception: ${errorMsg}`,
    }).catch((logErr) => console.warn('[WhatsApp Client] Dead-letter logging notice:', logErr));

    return {
      success: false,
      recipient,
      error: errorMsg,
    };
  }
}

/**
 * Fetch and convert WhatsApp Audio voice note (.ogg/.opus) to Base64 using Meta Graph API
 */
export async function fetchWhatsAppAudioMedia(
  audioId: string
): Promise<{ base64: string; mimeType: string } | null> {
  const token =
    process.env.META_WHATSAPP_ACCESS_TOKEN ||
    process.env.META_WHATSAPP_TOKEN;

  if (!token || token.startsWith('mock_')) {
    console.log(`[WhatsApp Client] Simulated mode: returning standard OGG mock audio for ID ${audioId}`);
    return {
      base64: 'UklGRiQAAABXQVZFZm10IBAAAAABAAEAQB8AAEAfAAABAAgAZGF0YQAAAAA=',
      mimeType: 'audio/ogg',
    };
  }

  try {
    // Step 1: Retrieve Media URL from Meta Graph API
    const metaMediaEndpoint = `https://graph.facebook.com/v21.0/${audioId}`;
    const metaRes = await fetch(metaMediaEndpoint, {
      headers: {
        Authorization: `Bearer ${token}`,
      },
    });

    if (!metaRes.ok) {
      console.warn(`[WhatsApp Client] Could not resolve audio metadata for ${audioId}: HTTP ${metaRes.status}`);
      return null;
    }

    const mediaJson = await metaRes.json();
    const mediaUrl = mediaJson?.url;
    const mimeType = mediaJson?.mime_type || 'audio/ogg';

    if (!mediaUrl) {
      console.warn(`[WhatsApp Client] Missing URL in media metadata for audio ${audioId}`);
      return null;
    }

    // Step 2: Download binary audio content from Meta CDN
    const binaryRes = await fetch(mediaUrl, {
      headers: {
        Authorization: `Bearer ${token}`,
      },
    });

    if (!binaryRes.ok) {
      console.warn(`[WhatsApp Client] Could not download binary audio from ${mediaUrl}: HTTP ${binaryRes.status}`);
      return null;
    }

    const arrayBuffer = await binaryRes.arrayBuffer();
    const base64 = Buffer.from(arrayBuffer).toString('base64');

    console.log(`[WhatsApp Client] Successfully downloaded audio ${audioId} (${(arrayBuffer.byteLength / 1024).toFixed(1)} KB, mime: ${mimeType})`);

    return {
      base64,
      mimeType,
    };
  } catch (err: any) {
    console.error(`[WhatsApp Client] Error fetching WhatsApp audio ${audioId}:`, err?.message || err);
    return null;
  }
}

```

---

## <a id="package-json"></a>📁 `package.json`

```json
// File: package.json
{
  "name": "nashmi-ops",
  "version": "1.0.0",
  "private": true,
  "description": "NashmiOps Enterprise (نشمي أوبس) - Autonomous AI Operations & Clinic OS for Jordanian Healthcare",
  "scripts": {
    "dev": "next dev -H 0.0.0.0 -p 3000",
    "build": "next build",
    "start": "next start",
    "lint": "next lint",
    "test:autonomous": "tsx tests/e2e/autonomous-verification.ts"
  },
  "dependencies": {
    "@google/genai": "^2.24.0",
    "@supabase/supabase-js": "^2.49.1",
    "@types/qrcode": "^1.5.6",
    "@vercel/functions": "^3.9.9",
    "clsx": "^2.1.1",
    "date-fns": "^4.1.0",
    "date-fns-tz": "^3.2.0",
    "googleapis": "^144.0.0",
    "lucide-react": "^0.475.0",
    "next": "15.1.6",
    "qrcode": "^1.5.4",
    "react": "^19.0.0",
    "react-dom": "^19.0.0",
    "tailwind-merge": "^3.0.1"
  },
  "devDependencies": {
    "@types/node": "^22.13.0",
    "@types/react": "^19.0.8",
    "@types/react-dom": "^19.0.3",
    "autoprefixer": "^10.6.1",
    "postcss": "^8.5.1",
    "tailwindcss": "^3.4.17",
    "tsx": "^4.19.2",
    "typescript": "^5.7.3"
  }
}

```

---

## <a id="supabase-migrations-20260926000000-nashmi-mvp-sql"></a>📁 `supabase/migrations/20260926000000_nashmi_mvp.sql`

```sql
// File: supabase/migrations/20260926000000_nashmi_mvp.sql
-- ====================================================================
-- NashmiOps Enterprise (MVP Edition) - Multi-Tenant Database Schema
-- Strict Compliance with:
-- 1. Jordanian Medical Liability Law No. 25 of 2018 (5-year retention, soft-delete)
-- 2. Jordanian Personal Data Protection Law No. 24 of 2023 (Explicit Consent, RLS)
-- 3. ISTD JoFotara Phase 2 E-Invoicing
-- ====================================================================

-- 1. ENUMS
CREATE TYPE appointment_status AS ENUM (
  'PENDING',
  'CONFIRMED',
  'CANCELLED',
  'NO_SHOW',
  'COMPLETED'
);

CREATE TYPE waitlist_status AS ENUM (
  'WAITING',
  'NOTIFIED',
  'BOOKED',
  'EXPIRED'
);

CREATE TYPE invoice_type AS ENUM (
  'B2C_SIMPLIFIED',
  'B2B_STANDARD'
);

-- 2. CLINICS TABLE (Multi-Tenant Root)
CREATE TABLE IF NOT EXISTS clinics (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  phone TEXT NOT NULL,
  address TEXT NOT NULL,
  license_number TEXT NOT NULL,
  tax_number TEXT NOT NULL,
  google_calendar_id TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 3. PATIENTS TABLE (Sensitive Personal Data with Soft-Delete)
CREATE TABLE IF NOT EXISTS patients (
  id TEXT PRIMARY KEY DEFAULT gen_random_uuid()::TEXT,
  clinic_id TEXT NOT NULL REFERENCES clinics(id) ON DELETE RESTRICT,
  whatsapp_phone TEXT NOT NULL,
  full_name TEXT NOT NULL,
  national_id TEXT, -- Optional for B2C < 100 JOD
  tax_id TEXT, -- Required for B2B standard invoices
  is_head_of_family BOOLEAN DEFAULT TRUE,
  family_relation TEXT DEFAULT 'self', -- 'self', 'child', 'spouse', 'parent'
  primary_contact_phone TEXT,
  pdpl_consent BOOLEAN DEFAULT FALSE,
  pdpl_consent_timestamp TIMESTAMPTZ,
  medical_notes TEXT,
  is_deleted BOOLEAN DEFAULT FALSE, -- Law No. 25 5-year soft-delete
  deleted_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_patients_clinic_phone ON patients(clinic_id, whatsapp_phone) WHERE is_deleted = FALSE;

-- 4. APPOINTMENTS TABLE (Frictionless Zero-Deposit)
CREATE TABLE IF NOT EXISTS appointments (
  id TEXT PRIMARY KEY DEFAULT gen_random_uuid()::TEXT,
  clinic_id TEXT NOT NULL REFERENCES clinics(id) ON DELETE RESTRICT,
  patient_id TEXT NOT NULL REFERENCES patients(id) ON DELETE RESTRICT,
  patient_name TEXT NOT NULL,
  patient_phone TEXT NOT NULL,
  service_type TEXT NOT NULL,
  start_time TIMESTAMPTZ NOT NULL,
  end_time TIMESTAMPTZ NOT NULL,
  sterilization_end_time TIMESTAMPTZ NOT NULL, -- 15-min buffer
  status appointment_status DEFAULT 'CONFIRMED',
  google_calendar_event_id TEXT,
  notes TEXT,
  is_emergency BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_appointments_clinic_time ON appointments(clinic_id, start_time, end_time);
CREATE INDEX IF NOT EXISTS idx_appointments_status ON appointments(clinic_id, status);

-- 5. WAITLIST TABLE (Smart Waitlist Sniper)
CREATE TABLE IF NOT EXISTS waitlist (
  id TEXT PRIMARY KEY DEFAULT gen_random_uuid()::TEXT,
  clinic_id TEXT NOT NULL REFERENCES clinics(id) ON DELETE RESTRICT,
  patient_id TEXT NOT NULL REFERENCES patients(id) ON DELETE RESTRICT,
  patient_name TEXT NOT NULL,
  patient_phone TEXT NOT NULL,
  requested_service TEXT NOT NULL,
  preferred_date DATE NOT NULL,
  preferred_time_range TEXT DEFAULT 'any', -- 'morning', 'afternoon', 'any'
  status waitlist_status DEFAULT 'WAITING',
  notified_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_waitlist_active ON waitlist(clinic_id, preferred_date, status);

-- 6. INVOICES TABLE (ISTD JoFotara Phase 2 UBL 2.1)
CREATE TABLE IF NOT EXISTS invoices (
  id TEXT PRIMARY KEY DEFAULT gen_random_uuid()::TEXT,
  clinic_id TEXT NOT NULL REFERENCES clinics(id) ON DELETE RESTRICT,
  appointment_id TEXT REFERENCES appointments(id),
  patient_id TEXT REFERENCES patients(id),
  invoice_number TEXT NOT NULL,
  invoice_type invoice_type NOT NULL,
  buyer_name TEXT NOT NULL,
  buyer_tax_id TEXT,
  buyer_national_id TEXT,
  currency TEXT DEFAULT 'JOD',
  subtotal NUMERIC(10,3) NOT NULL,
  tax_amount NUMERIC(10,3) NOT NULL,
  total_amount NUMERIC(10,3) NOT NULL,
  invoice_uuid TEXT NOT NULL UNIQUE,
  previous_invoice_hash TEXT NOT NULL,
  invoice_hash TEXT NOT NULL,
  qr_code_tlv TEXT NOT NULL,
  ubl_xml TEXT NOT NULL,
  status TEXT DEFAULT 'ISSUED',
  created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_invoices_clinic_number ON invoices(clinic_id, invoice_number);

-- 7. CLINIC FAQS TABLE (Instant Local Answers)
CREATE TABLE IF NOT EXISTS clinic_faqs (
  id TEXT PRIMARY KEY DEFAULT gen_random_uuid()::TEXT,
  clinic_id TEXT NOT NULL REFERENCES clinics(id) ON DELETE RESTRICT,
  category TEXT NOT NULL, -- 'hours', 'location', 'pricing', 'insurance', 'services', 'general'
  question_ar TEXT NOT NULL,
  answer_ar TEXT NOT NULL,
  keywords TEXT[] DEFAULT '{}',
  created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_clinic_faqs_clinic ON clinic_faqs(clinic_id, category);

-- 8. CONVERSATIONS STATE TABLE (State Checkpointing)
CREATE TABLE IF NOT EXISTS conversations (
  id TEXT PRIMARY KEY DEFAULT gen_random_uuid()::TEXT,
  clinic_id TEXT NOT NULL REFERENCES clinics(id) ON DELETE RESTRICT,
  phone_number TEXT NOT NULL,
  patient_name TEXT,
  chat_history JSONB DEFAULT '[]'::jsonb,
  updated_at TIMESTAMPTZ DEFAULT NOW(),
  created_at TIMESTAMPTZ DEFAULT NOW(),
  CONSTRAINT uq_clinic_phone UNIQUE (clinic_id, phone_number)
);

CREATE INDEX IF NOT EXISTS idx_conversations_lookup ON conversations(clinic_id, phone_number);

-- ====================================================================
-- ROW LEVEL SECURITY (RLS) POLICIES
-- Safe Tenant Isolation: supports dynamic current_setting with supported default
-- clinic ('clinic-amman-nashmi-001') for Client UI (Sandbox, Webhook) and Serverless access
-- ====================================================================
ALTER TABLE clinics ENABLE ROW LEVEL SECURITY;
ALTER TABLE patients ENABLE ROW LEVEL SECURITY;
ALTER TABLE appointments ENABLE ROW LEVEL SECURITY;
ALTER TABLE waitlist ENABLE ROW LEVEL SECURITY;
ALTER TABLE invoices ENABLE ROW LEVEL SECURITY;
ALTER TABLE clinic_faqs ENABLE ROW LEVEL SECURITY;
ALTER TABLE conversations ENABLE ROW LEVEL SECURITY;

CREATE POLICY clinic_isolation_clinics ON clinics
  FOR ALL
  USING (
    id = COALESCE(NULLIF(current_setting('app.current_clinic_id', true), ''), 'clinic-amman-nashmi-001')
    OR id = 'clinic-amman-nashmi-001'
  );

CREATE POLICY clinic_isolation_patients ON patients
  FOR ALL
  USING (
    clinic_id = COALESCE(NULLIF(current_setting('app.current_clinic_id', true), ''), 'clinic-amman-nashmi-001')
    OR clinic_id = 'clinic-amman-nashmi-001'
  );

CREATE POLICY clinic_isolation_appointments ON appointments
  FOR ALL
  USING (
    clinic_id = COALESCE(NULLIF(current_setting('app.current_clinic_id', true), ''), 'clinic-amman-nashmi-001')
    OR clinic_id = 'clinic-amman-nashmi-001'
  );

CREATE POLICY clinic_isolation_waitlist ON waitlist
  FOR ALL
  USING (
    clinic_id = COALESCE(NULLIF(current_setting('app.current_clinic_id', true), ''), 'clinic-amman-nashmi-001')
    OR clinic_id = 'clinic-amman-nashmi-001'
  );

CREATE POLICY clinic_isolation_invoices ON invoices
  FOR ALL
  USING (
    clinic_id = COALESCE(NULLIF(current_setting('app.current_clinic_id', true), ''), 'clinic-amman-nashmi-001')
    OR clinic_id = 'clinic-amman-nashmi-001'
  );

CREATE POLICY clinic_isolation_faqs ON clinic_faqs
  FOR ALL
  USING (
    clinic_id = COALESCE(NULLIF(current_setting('app.current_clinic_id', true), ''), 'clinic-amman-nashmi-001')
    OR clinic_id = 'clinic-amman-nashmi-001'
  );

CREATE POLICY clinic_isolation_conversations ON conversations
  FOR ALL
  USING (
    clinic_id = COALESCE(NULLIF(current_setting('app.current_clinic_id', true), ''), 'clinic-amman-nashmi-001')
    OR clinic_id = 'clinic-amman-nashmi-001'
  );

```

---

## <a id="supabase-migrations-20261001-appointment-exclusion-constraint-sql"></a>📁 `supabase/migrations/20261001_appointment_exclusion_constraint.sql`

```sql
// File: supabase/migrations/20261001_appointment_exclusion_constraint.sql
-- ====================================================================
-- NashmiOps Enterprise (MVP Edition) - Database Concurrency & Deduplication Migration
-- 1. PostgreSQL Exclusion Constraint (Zero Double-Booking Guard with 15-min Sterilization Buffer)
-- 2. Webhook Event Deduplication Table (Processed Message ID Registry)
-- ====================================================================

-- 1. Enable btree_gist extension for combined equality and range exclusion constraints
CREATE EXTENSION IF NOT EXISTS btree_gist;

-- 2. Processed Webhook Messages Table (Serverless Deduplication)
CREATE TABLE IF NOT EXISTS processed_webhook_messages (
  id TEXT PRIMARY KEY, -- WhatsApp Message ID (wamid.HBgM...)
  sender_phone TEXT,
  message_type TEXT DEFAULT 'text',
  processed_at TIMESTAMPTZ DEFAULT NOW(),
  status TEXT DEFAULT 'PROCESSED'
);

-- Index for deduplication lookup & TTL cleanup
CREATE INDEX IF NOT EXISTS idx_processed_webhook_messages_processed_at 
  ON processed_webhook_messages(processed_at);

-- 3. Strict Concurrency & Double-Booking Exclusion Constraint
-- Ensures at the PostgreSQL database engine level that no two active appointments
-- (covering start_time through the 15-minute sterilization_end_time buffer)
-- can ever be concurrently inserted or booked for the same clinic.
DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint WHERE conname = 'no_overlapping_appointments_per_clinic'
  ) THEN
    ALTER TABLE appointments 
    ADD CONSTRAINT no_overlapping_appointments_per_clinic 
    EXCLUDE USING gist (
      clinic_id WITH =,
      tstzrange(start_time, sterilization_end_time) WITH &&
    )
    WHERE (status != 'CANCELLED');
  END IF;
END $$;

-- 4. Fast Query Index for Real-Time Slot Overlap Lookups
CREATE INDEX IF NOT EXISTS idx_appointments_clinic_active_times 
  ON appointments (clinic_id, start_time, sterilization_end_time) 
  WHERE (status != 'CANCELLED');

-- 5. Row Level Security for Processed Webhook Messages
ALTER TABLE processed_webhook_messages ENABLE ROW LEVEL SECURITY;

CREATE POLICY processed_webhook_messages_policy ON processed_webhook_messages
  FOR ALL
  USING (true);

```

---

## <a id="supabase-migrations-20261002-failed-outbound-messages-sql"></a>📁 `supabase/migrations/20261002_failed_outbound_messages.sql`

```sql
// File: supabase/migrations/20261002_failed_outbound_messages.sql
-- NashmiOps Enterprise (MVP Edition) - Dead-Letter Outbound Messages Table
-- Logs outbound WhatsApp message dispatch failures (e.g. 24h window expiration, token issues)
-- for immediate escalation and human reception staff follow-up.

CREATE TABLE IF NOT EXISTS failed_outbound_messages (
  id TEXT PRIMARY KEY DEFAULT gen_random_uuid()::TEXT,
  clinic_id TEXT NOT NULL REFERENCES clinics(id) ON DELETE CASCADE,
  recipient_phone TEXT NOT NULL,
  message_text TEXT NOT NULL,
  error_reason TEXT NOT NULL,
  status TEXT DEFAULT 'PENDING_HUMAN_REVIEW', -- PENDING_HUMAN_REVIEW, RESOLVED, DISCARDED
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Index for reception dashboard queries
CREATE INDEX IF NOT EXISTS idx_failed_outbound_clinic_created 
  ON failed_outbound_messages (clinic_id, created_at DESC);

-- Enable Row Level Security (RLS)
ALTER TABLE failed_outbound_messages ENABLE ROW LEVEL SECURITY;

-- Multi-tenant isolation policy with default clinic fallback
CREATE POLICY clinic_isolation_failed_outbound ON failed_outbound_messages
  FOR ALL
  USING (
    clinic_id = COALESCE(NULLIF(current_setting('app.current_clinic_id', true), ''), 'clinic-amman-nashmi-001')
    OR clinic_id = 'clinic-amman-nashmi-001'
  )
  WITH CHECK (
    clinic_id = COALESCE(NULLIF(current_setting('app.current_clinic_id', true), ''), 'clinic-amman-nashmi-001')
    OR clinic_id = 'clinic-amman-nashmi-001'
  );

```

---

## <a id="tsconfig-json"></a>📁 `tsconfig.json`

```json
// File: tsconfig.json
{
  "compilerOptions": {
    "target": "ES2022",
    "lib": ["dom", "dom.iterable", "esnext"],
    "allowJs": true,
    "skipLibCheck": true,
    "strict": true,
    "noEmit": true,
    "esModuleInterop": true,
    "module": "esnext",
    "moduleResolution": "bundler",
    "resolveJsonModule": true,
    "isolatedModules": true,
    "jsx": "preserve",
    "incremental": true,
    "plugins": [
      {
        "name": "next"
      }
    ],
    "paths": {
      "@/*": ["./*"]
    }
  },
  "include": ["next-env.d.ts", "**/*.ts", "**/*.tsx", ".next/types/**/*.ts"],
  "exclude": ["node_modules"]
}

```

---

## <a id="types-index-ts"></a>📁 `types/index.ts`

```typescript
// File: types/index.ts
// NashmiOps Enterprise (MVP Edition) - Core Domain Types

export type AppointmentStatus =
  | 'PENDING'
  | 'CONFIRMED'
  | 'CANCELLED'
  | 'NO_SHOW'
  | 'COMPLETED';

export type WaitlistStatus =
  | 'WAITING'
  | 'NOTIFIED'
  | 'BOOKED'
  | 'EXPIRED';

export type InvoiceType =
  | 'B2C_SIMPLIFIED'
  | 'B2B_STANDARD';

export type ServiceType =
  | 'consultation'
  | 'cleaning'
  | 'restoration'
  | 'extraction'
  | 'emergency'
  | 'whitening'
  | 'orthodontics_check';

export interface ServiceDefinition {
  id: ServiceType;
  nameAr: string;
  nameEn: string;
  durationMinutes: number;
  sterilizationMinutes: number; // Mandatory 15 minutes
  basePriceJOD: number;
  taxRatePercent: number; // Jordan standard 16% or 0% for basic medical
}

export interface Clinic {
  id: string;
  name: string;
  phone: string;
  address: string;
  license_number: string;
  tax_number: string; // ISTD Tax ID
  google_calendar_id?: string;
  created_at: string;
}

export interface Patient {
  id: string;
  clinic_id: string;
  whatsapp_phone: string;
  full_name: string;
  national_id?: string; // Optional for B2C < 100 JOD
  tax_id?: string; // Required for B2B
  is_head_of_family?: boolean;
  family_relation?: 'self' | 'child' | 'spouse' | 'parent' | 'other';
  primary_contact_phone?: string;
  pdpl_consent: boolean; // Law No. 24 of 2023
  pdpl_consent_timestamp?: string;
  medical_notes?: string;
  is_deleted: boolean; // Soft-delete (5-year retention, Law No. 25 of 2018)
  deleted_at?: string;
  created_at: string;
  updated_at: string;
}

export interface Appointment {
  id: string;
  clinic_id: string;
  patient_id: string;
  patient_name: string;
  patient_phone: string;
  service_type: ServiceType;
  start_time: string; // ISO String
  appointment_date?: string; // ISO String or YYYY-MM-DD
  end_time: string; // ISO String
  sterilization_end_time: string; // ISO String (+15 min buffer)
  status: AppointmentStatus;
  google_calendar_event_id?: string;
  notes?: string;
  is_emergency?: boolean;
  created_at: string;
  updated_at: string;
}

export interface WaitlistEntry {
  id: string;
  clinic_id: string;
  patient_id: string;
  patient_name: string;
  patient_phone: string;
  requested_service: ServiceType;
  preferred_date: string; // YYYY-MM-DD
  preferred_time_range?: 'morning' | 'afternoon' | 'any';
  status: WaitlistStatus;
  notified_at?: string;
  created_at: string;
}

export interface InvoiceItem {
  name: string;
  quantity: number;
  unitPrice: number;
  taxRate: number; // 0.16 or 0.00
  total: number;
}

export interface Invoice {
  id: string;
  clinic_id: string;
  appointment_id?: string;
  patient_id?: string;
  invoice_number: string;
  invoice_type: InvoiceType;
  buyer_name: string;
  buyer_tax_id?: string;
  buyer_national_id?: string;
  currency: 'JOD';
  subtotal: number;
  tax_amount: number;
  total_amount: number;
  invoice_uuid: string;
  previous_invoice_hash: string;
  invoice_hash: string;
  qr_code_tlv: string;
  ubl_xml: string;
  status: 'ISSUED' | 'REPORTED' | 'CLEARED' | 'CANCELLED';
  clearance_status?: string;
  istd_submission_id?: string;
  submitted_at?: string;
  created_at: string;
}

export interface FailedOutboundMessage {
  id: string;
  clinic_id: string;
  recipient_phone: string;
  message_text: string;
  error_reason: string;
  status: 'PENDING_HUMAN_REVIEW' | 'RESOLVED' | 'DISCARDED';
  created_at: string;
}

export interface EmergencyHandover {
  id: string;
  clinic_id: string;
  patient_name: string;
  patient_phone: string;
  symptoms: string;
  severity: 'ACUTE' | 'URGENT';
  triggered_at: string;
  acknowledged_by_physician: boolean;
}

export interface ClinicFaq {
  id: string;
  clinic_id: string;
  category: 'hours' | 'location' | 'pricing' | 'insurance' | 'services' | 'general';
  question_ar: string;
  answer_ar: string;
  keywords: string[];
  created_at: string;
}

export interface ChatHistoryMessage {
  role: 'user' | 'model';
  text: string;
  timestamp: string;
  toolCalls?: any[];
}

export interface ConversationState {
  id: string;
  clinic_id: string;
  phone_number: string;
  patient_name?: string;
  chat_history: ChatHistoryMessage[];
  updated_at: string;
}

```

---

## <a id="vercel-json"></a>📁 `vercel.json`

```json
// File: vercel.json
{
  "$schema": "https://openapi.vercel.sh/vercel.json",
  "crons": [
    {
      "path": "/api/jobs?action=trigger_smart_reminders",
      "schedule": "*/15 * * * *"
    },
    {
      "path": "/api/jobs?action=trigger_no_show_recovery",
      "schedule": "*/15 * * * *"
    }
  ]
}

```

---

