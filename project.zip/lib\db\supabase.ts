// NashmiOps Enterprise (MVP Edition) - Database Layer & Multi-Tenant Store

import { createClient, SupabaseClient } from '@supabase/supabase-js';
import {
  Clinic,
  Patient,
  Appointment,
  WaitlistEntry,
  Invoice,
  AppointmentStatus,
  WaitlistStatus,
  ServiceType,
  ClinicFaq,
  ConversationState,
  ChatHistoryMessage,
  FailedOutboundMessage,
} from '@/types';
import { CLINIC_CONFIG } from '@/lib/config/constants';
import { loadPersistentData, savePersistentData } from '@/lib/db/disk-store';

const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL;
const supabaseKey =
  process.env.SUPABASE_SERVICE_ROLE_KEY ||
  process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY;

if (!supabaseUrl || !supabaseKey) {
  console.error('[Security] CRITICAL: Supabase credentials (NEXT_PUBLIC_SUPABASE_URL / SUPABASE_SERVICE_ROLE_KEY) missing from environment!');
}

export const supabase: SupabaseClient = createClient(
  supabaseUrl || 'https://placeholder.supabase.co',
  supabaseKey || 'placeholder-service-key'
);

// ====================================================================
// RESILIENT MULTI-TENANT IN-MEMORY SYNC STORE (Crash-Proof Fallback)
// ====================================================================
class TenantMemoryStore {
  clinics: Clinic[] = [
    {
      id: CLINIC_CONFIG.id,
      name: CLINIC_CONFIG.name,
      phone: CLINIC_CONFIG.phone,
      address: CLINIC_CONFIG.address,
      license_number: CLINIC_CONFIG.licenseNumber,
      tax_number: CLINIC_CONFIG.taxNumber,
      google_calendar_id: process.env.GOOGLE_CALENDAR_ID,
      created_at: new Date().toISOString(),
    },
  ];

  patients: Patient[] = [
    {
      id: 'patient-demo-001',
      clinic_id: CLINIC_CONFIG.id,
      whatsapp_phone: '+962791234567',
      full_name: 'أحمد التميمي',
      national_id: '9901020304',
      is_head_of_family: true,
      family_relation: 'self',
      pdpl_consent: true,
      pdpl_consent_timestamp: new Date().toISOString(),
      is_deleted: false,
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
    },
    {
      id: 'patient-demo-002',
      clinic_id: CLINIC_CONFIG.id,
      whatsapp_phone: '+962799887766',
      full_name: 'سارة عبد الله',
      national_id: '9951020305',
      is_head_of_family: true,
      family_relation: 'self',
      pdpl_consent: true,
      pdpl_consent_timestamp: new Date().toISOString(),
      is_deleted: false,
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
    },
  ];

  appointments: Appointment[] = [
    {
      id: 'appt-demo-001',
      clinic_id: CLINIC_CONFIG.id,
      patient_id: 'patient-demo-001',
      patient_name: 'أحمد التميمي',
      patient_phone: '+962791234567',
      service_type: 'consultation',
      start_time: new Date(Date.now() + 3600000 * 24).toISOString(), // Tomorrow
      end_time: new Date(Date.now() + 3600000 * 24 + 1800000).toISOString(),
      sterilization_end_time: new Date(Date.now() + 3600000 * 24 + 2700000).toISOString(),
      status: 'CONFIRMED',
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
    },
  ];

  waitlist: WaitlistEntry[] = [
    {
      id: 'wait-demo-001',
      clinic_id: CLINIC_CONFIG.id,
      patient_id: 'patient-demo-002',
      patient_name: 'سارة عبد الله',
      patient_phone: '+962799887766',
      requested_service: 'cleaning',
      preferred_date: new Date().toISOString().split('T')[0],
      preferred_time_range: 'any',
      status: 'WAITING',
      created_at: new Date().toISOString(),
    },
  ];

  invoices: Invoice[] = [];

  clinic_faqs: ClinicFaq[] = [
    {
      id: 'faq-hours',
      clinic_id: CLINIC_CONFIG.id,
      category: 'hours',
      question_ar: 'ما هي أوقات دوام وساعات العمل في العيادة؟',
      answer_ar: 'نستقبلكم يومياً من السبت إلى الخميس من الساعة 9:00 صباحاً حتى 9:00 مساءً. يوم الجمعة عطلة أسبوعية.',
      keywords: ['دوام', 'ساعات', 'اوقات', 'متى', 'فاتحين', 'تسكير', 'الجمعة', 'السبت'],
      created_at: new Date().toISOString(),
    },
    {
      id: 'faq-location',
      clinic_id: CLINIC_CONFIG.id,
      category: 'location',
      question_ar: 'أين موقع مركز نشمي وهل تتوفر مواقف سيارات؟',
      answer_ar: 'موقعنا في عمان، الشميساني - مقابل المستشفى التخصصي. يتوفر لدينا مواقف سيارات مجانية خاصة بالمراجعين مع خدمة فاليه مجانية لراحتكم.',
      keywords: ['موقع', 'مكان', 'وين', 'عنوان', 'باركنج', 'مواقف', 'فاليه', 'صفة', 'سيارة', 'الشميساني'],
      created_at: new Date().toISOString(),
    },
    {
      id: 'faq-insurance',
      clinic_id: CLINIC_CONFIG.id,
      category: 'insurance',
      question_ar: 'ما هي شركات وشبكات التأمين الطبي المعتمدة لديكم؟',
      answer_ar: 'معتمدون لدى كبرى شركات التأمين في الأردن: نات هيلث (NatHealth)، ميدنت (MedNet)، الشرق العربي للتأمين، GIG، والأولى للتأمين، بنسب تغطية تصل من 80% إلى 100% حسب فئة بطاقتك.',
      keywords: ['تأمين', 'شبكة', 'نات هيلث', 'ميدنت', 'الشرق العربي', 'gig', 'تغطية', 'بطاقة'],
      created_at: new Date().toISOString(),
    },
    {
      id: 'faq-pricing',
      clinic_id: CLINIC_CONFIG.id,
      category: 'pricing',
      question_ar: 'كم أسعار الكشفية والعلاجات وتنظيف الأسنان؟',
      answer_ar: 'الكشفية والاستشارة مع خطة العلاج 15-20 دينار (تُخصم من قيمة المعالجة عند البدء). تنظيف وتلميع الأسنان يبدأ من 25 دينار، وتبييض الأسنان بالليزر يبدأ من 80 دينار، والحشوات التجميلية تبدأ من 30 دينار. ولا يوجد أي رسوم عربون أو دفعة مسبقة للحجز.',
      keywords: ['سعر', 'اسعار', 'كشفية', 'تكلفة', 'تنظيف', 'تبييض', 'حشوة', 'كم يكلف', 'عربون', 'فلوس'],
      created_at: new Date().toISOString(),
    },
    {
      id: 'faq-services',
      clinic_id: CLINIC_CONFIG.id,
      category: 'services',
      question_ar: 'ما هي الخدمات والإجراءات الطبية المتوفرة في المركز؟',
      answer_ar: 'نقدم خدمات طب وجراحة الأسنان الشاملة: زراعة الأسنان الرقمية، تقويم الأسنان الشفاف والمعدني، ابتسامة هوليود والعدسات الخزفية، علاج العصب والجذور بجلسة واحدة، طب أسنان الأطفال، وتنظيف وتبييض الأسنان.',
      keywords: ['خدمات', 'علاج', 'زراعة', 'تقويم', 'ابتسامة', 'هوليود', 'عصب', 'أطفال', 'تجميل'],
      created_at: new Date().toISOString(),
    },
  ];

  conversations: ConversationState[] = [];
  processed_messages: Array<{ message_id: string; sender_phone?: string; message_type?: string; processed_at: string }> = [];
  failed_outbound_messages: FailedOutboundMessage[] = [];
  private isHydrated = false;

  constructor() {
    this.hydrateFromDisk();
  }

  hydrateFromDisk() {
    if (this.isHydrated) return;
    try {
      const disk = loadPersistentData();
      if (disk) {
        if (Array.isArray(disk.clinics) && disk.clinics.length > 0) this.clinics = disk.clinics;
        if (Array.isArray(disk.patients) && disk.patients.length > 0) this.patients = disk.patients;
        if (Array.isArray(disk.appointments) && disk.appointments.length > 0) this.appointments = disk.appointments;
        if (Array.isArray(disk.waitlist) && disk.waitlist.length > 0) this.waitlist = disk.waitlist;
        if (Array.isArray(disk.invoices) && disk.invoices.length > 0) this.invoices = disk.invoices;
        if (Array.isArray(disk.clinic_faqs) && disk.clinic_faqs.length > 0) this.clinic_faqs = disk.clinic_faqs;
        if (Array.isArray(disk.conversations) && disk.conversations.length > 0) this.conversations = disk.conversations;
        if (Array.isArray(disk.processed_messages) && disk.processed_messages.length > 0) this.processed_messages = disk.processed_messages;
        if (Array.isArray(disk.failed_outbound_messages) && disk.failed_outbound_messages.length > 0) this.failed_outbound_messages = disk.failed_outbound_messages;
        console.log(`[TenantStore] Hydrated from disk: ${this.appointments.length} appointments, ${this.conversations.length} conversations, ${this.processed_messages.length} processed msgs, ${this.failed_outbound_messages.length} failed msgs`);
      }
      this.isHydrated = true;
    } catch (err) {
      console.warn('[TenantStore] Error hydrating from disk:', err);
    }
  }
}

export const tenantStore = new TenantMemoryStore();

export function persistTenantStore(): void {
  try {
    savePersistentData({
      clinics: tenantStore.clinics,
      patients: tenantStore.patients,
      appointments: tenantStore.appointments,
      waitlist: tenantStore.waitlist,
      invoices: tenantStore.invoices,
      clinic_faqs: tenantStore.clinic_faqs,
      conversations: tenantStore.conversations,
      processed_messages: tenantStore.processed_messages,
      failed_outbound_messages: tenantStore.failed_outbound_messages,
    });
  } catch (err) {
    console.warn('[TenantStore] Error persisting to disk:', err);
  }
}

// ====================================================================
// MULTI-TENANT REPOSITORY METHODS
// ====================================================================

/**
 * Find or create a patient with family profile support and PDPL consent check.
 */
export async function findOrCreatePatient(params: {
  clinicId: string;
  phone: string;
  fullName: string;
  nationalId?: string;
  familyRelation?: 'self' | 'child' | 'spouse' | 'parent';
  primaryContactPhone?: string;
}): Promise<{ patient: Patient; isNew: boolean }> {
  const normalizedPhone = params.phone.trim();
  const name = params.fullName.trim();

  // 1. Search in local store
  let existing = tenantStore.patients.find(
    (p) =>
      p.clinic_id === params.clinicId &&
      p.whatsapp_phone === normalizedPhone &&
      p.full_name.toLowerCase() === name.toLowerCase() &&
      !p.is_deleted
  );

  // If name differs but phone is same, might be a family member profile!
  if (!existing && params.familyRelation && params.familyRelation !== 'self') {
    existing = tenantStore.patients.find(
      (p) =>
        p.clinic_id === params.clinicId &&
        p.whatsapp_phone === normalizedPhone &&
        p.full_name.toLowerCase() === name.toLowerCase() &&
        !p.is_deleted
    );
  }

  if (existing) {
    return { patient: existing, isNew: false };
  }

  // 2. Query Supabase
  try {
    const { data } = await supabase
      .from('patients')
      .select('*')
      .eq('clinic_id', params.clinicId)
      .eq('whatsapp_phone', normalizedPhone)
      .eq('full_name', name)
      .eq('is_deleted', false)
      .maybeSingle();

    if (data) {
      tenantStore.patients.push(data as Patient);
      return { patient: data as Patient, isNew: false };
    }
  } catch (err) {
    console.warn('[Supabase] Falling back to memory store for patient lookup:', err);
  }

  // 3. Create new Patient
  const newPatient: Patient = {
    id: `pat-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
    clinic_id: params.clinicId,
    whatsapp_phone: normalizedPhone,
    full_name: name,
    national_id: params.nationalId,
    is_head_of_family: !params.familyRelation || params.familyRelation === 'self',
    family_relation: params.familyRelation || 'self',
    primary_contact_phone: params.primaryContactPhone || normalizedPhone,
    pdpl_consent: false,
    is_deleted: false,
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString(),
  };

  tenantStore.patients.push(newPatient);
  persistTenantStore();

  try {
    await supabase.from('patients').insert(newPatient);
  } catch (err) {
    console.warn('[Supabase] Patient insert mirrored locally:', err);
  }

  return { patient: newPatient, isNew: true };
}

/**
 * Record PDPL Law No. 24 of 2023 Consent
 */
export async function recordPdplConsent(
  patientId: string,
  clinicId: string,
  granted: boolean
): Promise<boolean> {
  const patient = tenantStore.patients.find((p) => p.id === patientId && p.clinic_id === clinicId);
  const now = new Date().toISOString();
  if (patient) {
    patient.pdpl_consent = granted;
    patient.pdpl_consent_timestamp = now;
    patient.updated_at = now;
  }

  try {
    await supabase
      .from('patients')
      .update({
        pdpl_consent: granted,
        pdpl_consent_timestamp: now,
        updated_at: now,
      })
      .eq('id', patientId)
      .eq('clinic_id', clinicId);
  } catch (err) {
    console.warn('[Supabase] PDPL consent updated in memory:', err);
  }

  return true;
}

/**
 * Soft-Delete Patient (Jordanian Medical Liability Law No. 25 of 2018 - 5-year retention)
 */
export async function softDeletePatient(patientId: string, clinicId: string): Promise<boolean> {
  const patient = tenantStore.patients.find((p) => p.id === patientId && p.clinic_id === clinicId);
  const now = new Date().toISOString();
  if (patient) {
    patient.is_deleted = true;
    patient.deleted_at = now;
    patient.updated_at = now;
  }

  try {
    await supabase
      .from('patients')
      .update({
        is_deleted: true,
        deleted_at: now,
        updated_at: now,
      })
      .eq('id', patientId)
      .eq('clinic_id', clinicId);
  } catch (err) {
    console.warn('[Supabase] Soft-delete updated in memory:', err);
  }

  return true;
}

/**
 * Create Appointment (Frictionless Zero-Deposit with Concurrency Conflict Guard)
 */
export async function createAppointment(params: {
  clinicId: string;
  patientId: string;
  patientName: string;
  patientPhone: string;
  serviceType: ServiceType;
  startTime: string;
  endTime: string;
  sterilizationEndTime: string;
  googleCalendarEventId?: string;
  notes?: string;
  isEmergency?: boolean;
}): Promise<Appointment> {
  const reqStart = new Date(params.startTime).getTime();
  const reqEnd = new Date(params.sterilizationEndTime || params.endTime).getTime();

  // 1. Strict Concurrency Check in Local Memory Store (including 15-minute sterilization buffer)
  const localConflict = tenantStore.appointments.find((a) => {
    if (a.clinic_id !== params.clinicId) return false;
    if (a.status === 'CANCELLED') return false;

    const existingStart = new Date(a.start_time).getTime();
    const existingEnd = new Date(a.sterilization_end_time || a.end_time).getTime();

    // Overlap condition
    return reqStart < existingEnd && reqEnd > existingStart;
  });

  if (localConflict) {
    const conflictEndTime = new Date(localConflict.sterilization_end_time || localConflict.end_time)
      .toLocaleTimeString('ar-JO', { hour: '2-digit', minute: '2-digit' });
    const conflictErr: any = new Error(
      `DOUBLE_BOOKING_CONFLICT: يتعارض الموعد مع حجز مسبق حتى الساعة ${conflictEndTime} شاملاً فترة التعقيم الإلزامية (15 دقيقة).`
    );
    conflictErr.code = 'DOUBLE_BOOKING_CONFLICT';
    conflictErr.conflictingAppointment = localConflict;
    throw conflictErr;
  }

  // 2. Strict Concurrency Check against Supabase Database (Overlap with 15-minute sterilization buffer)
  try {
    const { data: dbConflicts } = await supabase
      .from('appointments')
      .select('*')
      .eq('clinic_id', params.clinicId)
      .neq('status', 'CANCELLED')
      .lt('start_time', params.sterilizationEndTime)
      .gt('sterilization_end_time', params.startTime);

    if (Array.isArray(dbConflicts) && dbConflicts.length > 0) {
      const conflict = dbConflicts[0];
      const conflictEndTime = new Date(conflict.sterilization_end_time || conflict.end_time)
        .toLocaleTimeString('ar-JO', { hour: '2-digit', minute: '2-digit' });
      const conflictErr: any = new Error(
        `DOUBLE_BOOKING_CONFLICT: يتعارض الموعد مع حجز مسجل في قاعدة البيانات حتى الساعة ${conflictEndTime} شاملاً فترة التعقيم.`
      );
      conflictErr.code = 'DOUBLE_BOOKING_CONFLICT';
      conflictErr.conflictingAppointment = conflict;
      throw conflictErr;
    }
  } catch (err: any) {
    if (err?.code === 'DOUBLE_BOOKING_CONFLICT') {
      throw err;
    }
    // Database check fallback - memory check passed
  }

  const appointmentDate = params.startTime.split('T')[0];
  const appt: Appointment = {
    id: `appt-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
    clinic_id: params.clinicId,
    patient_id: params.patientId,
    patient_name: params.patientName,
    patient_phone: params.patientPhone,
    service_type: params.serviceType,
    appointment_date: appointmentDate,
    start_time: params.startTime,
    end_time: params.endTime,
    sterilization_end_time: params.sterilizationEndTime,
    status: 'CONFIRMED',
    google_calendar_event_id: params.googleCalendarEventId,
    notes: params.notes,
    is_emergency: !!params.isEmergency,
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString(),
  };

  tenantStore.appointments.push(appt);
  persistTenantStore();

  try {
    const { error } = await supabase.from('appointments').insert({
      id: appt.id,
      clinic_id: appt.clinic_id,
      patient_id: appt.patient_id,
      patient_name: appt.patient_name,
      patient_phone: appt.patient_phone,
      service_type: appt.service_type,
      appointment_date: appt.appointment_date,
      start_time: appt.start_time,
      end_time: appt.end_time,
      sterilization_end_time: appt.sterilization_end_time,
      status: 'CONFIRMED',
      notes: appt.notes,
      created_at: appt.created_at,
    });
    if (error) {
      if (
        error.code === '23P01' ||
        error.message?.includes('exclusion') ||
        error.message?.includes('no_overlapping_appointments')
      ) {
        // Rollback memory store addition if DB exclusion constraint rejected it
        tenantStore.appointments = tenantStore.appointments.filter((a) => a.id !== appt.id);
        persistTenantStore();
        const conflictErr: any = new Error(
          'DOUBLE_BOOKING_CONFLICT: رفضت قاعدة البيانات الحجز لوجود تعارض زمني نشط (PostgreSQL Exclusion Constraint).'
        );
        conflictErr.code = 'DOUBLE_BOOKING_CONFLICT';
        throw conflictErr;
      }
      console.warn('[Supabase] Appointments insert notice:', error.message);
    }
  } catch (err: any) {
    if (err?.code === 'DOUBLE_BOOKING_CONFLICT') {
      throw err;
    }
    console.warn('[Supabase] Appointment stored locally:', err);
  }

  return appt;
}

/**
 * Deduplication via Supabase: Check and mark webhook message as processed.
 * Prevents processing the same message twice upon Meta Webhook retries in Serverless.
 * Returns true if message was already processed (duplicate), false if new.
 */
export async function isAndMarkWebhookMessageProcessed(params: {
  messageId: string;
  senderPhone?: string;
  messageType?: string;
}): Promise<boolean> {
  const { messageId, senderPhone, messageType } = params;
  if (!messageId) return false;

  // 1. In-memory deduplication check
  const alreadyInStore = tenantStore.processed_messages.some((m) => m.message_id === messageId);
  if (alreadyInStore) {
    return true;
  }

  // 2. Direct atomic check and insertion in Supabase
  try {
    const { data: existing } = await supabase
      .from('processed_webhook_messages')
      .select('id')
      .eq('id', messageId)
      .maybeSingle();

    if (existing) {
      tenantStore.processed_messages.push({
        message_id: messageId,
        sender_phone: senderPhone,
        message_type: messageType,
        processed_at: new Date().toISOString(),
      });
      persistTenantStore();
      return true;
    }

    const { error: insertErr } = await supabase
      .from('processed_webhook_messages')
      .insert({
        id: messageId,
        sender_phone: senderPhone,
        message_type: messageType || 'text',
        processed_at: new Date().toISOString(),
      });

    if (insertErr) {
      if (
        insertErr.code === '23505' ||
        insertErr.message?.includes('duplicate key') ||
        insertErr.message?.includes('unique constraint')
      ) {
        return true;
      }
    }
  } catch (dbErr) {
    console.warn('[Supabase] processed_webhook_messages check fallback:', dbErr);
  }

  // Record in local persistent store
  tenantStore.processed_messages.push({
    message_id: messageId,
    sender_phone: senderPhone,
    message_type: messageType,
    processed_at: new Date().toISOString(),
  });

  if (tenantStore.processed_messages.length > 2000) {
    tenantStore.processed_messages = tenantStore.processed_messages.slice(-2000);
  }

  persistTenantStore();
  return false;
}

/**
 * Deduplication Table TTL Cleanup:
 * Removes webhook messages older than maxAgeHours (default 48 hours) from
 * processed_webhook_messages and tenant store to prevent database bloat.
 */
export async function cleanupOldProcessedMessages(maxAgeHours: number = 48): Promise<{
  deletedCount: number;
  remainingCount: number;
  cutoffTime: string;
}> {
  const cutoffMs = Date.now() - maxAgeHours * 60 * 60 * 1000;
  const cutoffTime = new Date(cutoffMs).toISOString();

  let memoryDeleted = 0;
  const initialMemCount = tenantStore.processed_messages.length;
  tenantStore.processed_messages = tenantStore.processed_messages.filter((m) => {
    const time = new Date(m.processed_at).getTime();
    return time >= cutoffMs;
  });
  memoryDeleted = initialMemCount - tenantStore.processed_messages.length;
  persistTenantStore();

  let dbDeleted = 0;
  try {
    const { error, count } = await supabase
      .from('processed_webhook_messages')
      .delete({ count: 'exact' })
      .lt('processed_at', cutoffTime);

    if (!error && typeof count === 'number') {
      dbDeleted = count;
    }
  } catch (err) {
    console.warn('[Supabase Cleanup] TTL cleanup notice:', err);
  }

  const finalDeleted = Math.max(memoryDeleted, dbDeleted);
  console.log(`[Deduplication TTL Cleanup] Purged ${finalDeleted} messages older than ${maxAgeHours} hours (cutoff: ${cutoffTime})`);

  return {
    deletedCount: finalDeleted,
    remainingCount: tenantStore.processed_messages.length,
    cutoffTime,
  };
}

/**
 * Dead-Letter Outbound Log: Record failed outbound WhatsApp dispatches for human reception follow-up
 */
export async function logFailedOutboundMessage(params: {
  clinicId?: string;
  recipientPhone: string;
  messageText: string;
  errorReason: string;
}): Promise<FailedOutboundMessage> {
  const clinicId = params.clinicId || CLINIC_CONFIG.id;
  const entry: FailedOutboundMessage = {
    id: `fail-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
    clinic_id: clinicId,
    recipient_phone: params.recipientPhone,
    message_text: params.messageText,
    error_reason: params.errorReason,
    status: 'PENDING_HUMAN_REVIEW',
    created_at: new Date().toISOString(),
  };

  tenantStore.failed_outbound_messages.push(entry);
  persistTenantStore();

  try {
    await supabase.from('failed_outbound_messages').insert({
      id: entry.id,
      clinic_id: entry.clinic_id,
      recipient_phone: entry.recipient_phone,
      message_text: entry.message_text,
      error_reason: entry.error_reason,
      status: entry.status,
      created_at: entry.created_at,
    });
    console.log(`[Dead-Letter Log] Successfully logged failed message to ${params.recipientPhone} in Supabase`);
  } catch (err) {
    console.warn('[Supabase] Failed outbound message stored locally in tenantStore:', err);
  }

  return entry;
}

/**
 * Update Appointment Status (supports CANCELLED, NO_SHOW, COMPLETED)
 */
export async function updateAppointmentStatus(
  appointmentId: string,
  clinicId: string,
  status: AppointmentStatus
): Promise<Appointment | null> {
  const appt = tenantStore.appointments.find((a) => a.id === appointmentId && a.clinic_id === clinicId);
  const now = new Date().toISOString();
  if (appt) {
    appt.status = status;
    appt.updated_at = now;
    persistTenantStore();
  }

  try {
    await supabase
      .from('appointments')
      .update({ status, updated_at: now })
      .eq('id', appointmentId)
      .eq('clinic_id', clinicId);
  } catch (err) {
    console.warn('[Supabase] Appointment status updated locally:', err);
  }

  return appt || null;
}

/**
 * Add patient to Smart Waitlist
 */
export async function addToWaitlist(params: {
  clinicId: string;
  patientId: string;
  patientName: string;
  patientPhone: string;
  requestedService: ServiceType;
  preferredDate: string;
  preferredTimeRange?: 'morning' | 'afternoon' | 'any';
}): Promise<WaitlistEntry> {
  const entry: WaitlistEntry = {
    id: `wait-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
    clinic_id: params.clinicId,
    patient_id: params.patientId,
    patient_name: params.patientName,
    patient_phone: params.patientPhone,
    requested_service: params.requestedService,
    preferred_date: params.preferredDate,
    preferred_time_range: params.preferredTimeRange || 'any',
    status: 'WAITING',
    created_at: new Date().toISOString(),
  };

  tenantStore.waitlist.push(entry);
  persistTenantStore();

  try {
    await supabase.from('waitlist').insert(entry);
  } catch (err) {
    console.warn('[Supabase] Waitlist entry stored locally:', err);
  }

  return entry;
}

/**
 * Query waitlist for matching slots (Used by Waitlist Sniper)
 */
export async function findNextWaitlistCandidate(
  clinicId: string,
  serviceType: ServiceType,
  dateString: string
): Promise<WaitlistEntry | null> {
  const targetDate = dateString.split('T')[0];
  const candidate = tenantStore.waitlist.find(
    (w) =>
      w.clinic_id === clinicId &&
      w.status === 'WAITING' &&
      w.preferred_date === targetDate &&
      w.requested_service === serviceType
  );

  return candidate || null;
}

/**
 * Store JoFotara Invoice
 */
export async function saveInvoice(invoice: Invoice): Promise<Invoice> {
  tenantStore.invoices.push(invoice);
  persistTenantStore();
  try {
    await supabase.from('invoices').insert(invoice);
  } catch (err) {
    console.warn('[Supabase] Invoice stored locally:', err);
  }
  return invoice;
}

/**
 * Query Clinic FAQs by semantic/keyword match
 */
export async function queryClinicFaq(clinicId: string, queryText: string): Promise<ClinicFaq[]> {
  const q = (queryText || '').toLowerCase().trim();
  const words = q.split(/\s+/).filter((w) => w.length > 1);

  // 1. Check local memory store
  const localMatches = tenantStore.clinic_faqs.filter((faq) => {
    if (faq.clinic_id !== clinicId) return false;
    const matchCategory = q.includes(faq.category.toLowerCase());
    const matchQ = faq.question_ar.toLowerCase().includes(q) || words.some((w) => faq.question_ar.toLowerCase().includes(w));
    const matchA = faq.answer_ar.toLowerCase().includes(q) || words.some((w) => faq.answer_ar.toLowerCase().includes(w));
    const matchKeyword = faq.keywords.some((k) => q.includes(k.toLowerCase()) || words.some((w) => k.toLowerCase().includes(w)));
    return matchCategory || matchQ || matchA || matchKeyword;
  });

  if (localMatches.length > 0) {
    return localMatches;
  }

  // 2. Query Supabase
  try {
    const { data } = await supabase
      .from('clinic_faqs')
      .select('*')
      .eq('clinic_id', clinicId);

    if (data && data.length > 0) {
      for (const row of data) {
        if (!tenantStore.clinic_faqs.some((f) => f.id === row.id)) {
          tenantStore.clinic_faqs.push(row as ClinicFaq);
        }
      }
      return (data as ClinicFaq[]).filter((faq) => {
        const matchCategory = q.includes(faq.category.toLowerCase());
        const matchQ = faq.question_ar.toLowerCase().includes(q) || words.some((w) => faq.question_ar.toLowerCase().includes(w));
        const matchA = faq.answer_ar.toLowerCase().includes(q) || words.some((w) => faq.answer_ar.toLowerCase().includes(w));
        const matchKeyword = faq.keywords.some((k) => q.includes(k.toLowerCase()) || words.some((w) => k.toLowerCase().includes(w)));
        return matchCategory || matchQ || matchA || matchKeyword;
      });
    }
  } catch (err) {
    console.warn('[Supabase] Clinic FAQ query failed, using default FAQs:', err);
  }

  return tenantStore.clinic_faqs.filter((faq) => faq.clinic_id === clinicId);
}

/**
 * Get or create Conversation State for checkpointing
 */
export async function getOrCreateConversation(
  clinicId: string,
  phoneNumber: string,
  patientName?: string
): Promise<ConversationState> {
  const normalizedPhone = (phoneNumber || '+962791234567').trim();

  let conv = tenantStore.conversations.find(
    (c) => c.clinic_id === clinicId && c.phone_number === normalizedPhone
  );

  if (!conv) {
    // Try supabase
    try {
      const { data } = await supabase
        .from('conversations')
        .select('*')
        .eq('clinic_id', clinicId)
        .eq('phone_number', normalizedPhone)
        .maybeSingle();

      if (data) {
        conv = data as ConversationState;
        tenantStore.conversations.push(conv);
      }
    } catch (err) {
      console.warn('[Supabase] Conversation fetch fallback:', err);
    }
  }

  if (!conv) {
    conv = {
      id: `conv-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
      clinic_id: clinicId,
      phone_number: normalizedPhone,
      patient_name: patientName,
      chat_history: [],
      updated_at: new Date().toISOString(),
    };
    tenantStore.conversations.push(conv);

    try {
      await supabase.from('conversations').upsert({
        id: conv.id,
        clinic_id: conv.clinic_id,
        phone_number: conv.phone_number,
        patient_name: conv.patient_name,
        chat_history: conv.chat_history,
        updated_at: conv.updated_at,
      });
    } catch (err) {
      console.warn('[Supabase] Conversation upsert error:', err);
    }
  } else if (patientName && !conv.patient_name) {
    conv.patient_name = patientName;
  }

  return conv;
}

/**
 * Append message to chat_history and checkpoint to Supabase
 */
export async function appendChatHistory(
  clinicId: string,
  phoneNumber: string,
  role: 'user' | 'model',
  text: string,
  toolCalls?: any[]
): Promise<ConversationState> {
  const conv = await getOrCreateConversation(clinicId, phoneNumber);
  const newMsg: ChatHistoryMessage = {
    role,
    text,
    timestamp: new Date().toISOString(),
    toolCalls: toolCalls && toolCalls.length > 0 ? toolCalls : undefined,
  };

  conv.chat_history.push(newMsg);
  conv.updated_at = new Date().toISOString();

  // Cap stored history in memory to prevent memory bloat (keep last 50 turns)
  if (conv.chat_history.length > 50) {
    conv.chat_history = conv.chat_history.slice(-50);
  }

  persistTenantStore();

  // Persist checkpoint to Supabase
  try {
    await supabase.from('conversations').upsert({
      id: conv.id,
      clinic_id: conv.clinic_id,
      phone_number: conv.phone_number,
      patient_name: conv.patient_name,
      chat_history: conv.chat_history,
      updated_at: conv.updated_at,
    });
  } catch (err) {
    console.warn('[Supabase] Checkpointing chat history to DB fallback:', err);
  }

  return conv;
}

/**
 * Fetch all appointments from Supabase with resilient tenantStore sync
 */
export async function getAllAppointments(clinicId?: string): Promise<Appointment[]> {
  try {
    const query = supabase
      .from('appointments')
      .select('*')
      .order('start_time', { ascending: false });

    if (clinicId) {
      query.eq('clinic_id', clinicId);
    }

    const { data, error } = await query;
    if (data && data.length > 0) {
      for (const row of data) {
        const existingIdx = tenantStore.appointments.findIndex((a) => a.id === row.id);
        if (existingIdx >= 0) {
          tenantStore.appointments[existingIdx] = {
            ...tenantStore.appointments[existingIdx],
            ...row,
          };
        } else {
          tenantStore.appointments.push(row as Appointment);
        }
      }
      persistTenantStore();
    }
  } catch (err) {
    console.warn('[Supabase] Fetching appointments notice:', err);
  }

  return clinicId
    ? tenantStore.appointments.filter((a) => a.clinic_id === clinicId)
    : tenantStore.appointments;
}

/**
 * Get Conversation History for phone
 */
export async function getConversationHistory(
  clinicId: string,
  phoneNumber: string
): Promise<ConversationState | null> {
  const normalizedPhone = (phoneNumber || '+962791234567').trim();

  // First check in-memory / hydrated store
  let conv = tenantStore.conversations.find(
    (c) => c.clinic_id === clinicId && c.phone_number === normalizedPhone
  );

  // If not found or empty, try Supabase
  if (!conv || conv.chat_history.length === 0) {
    try {
      const { data } = await supabase
        .from('conversations')
        .select('*')
        .eq('clinic_id', clinicId)
        .eq('phone_number', normalizedPhone)
        .maybeSingle();

      if (data) {
        if (!conv) {
          conv = data as ConversationState;
          tenantStore.conversations.push(conv);
        } else {
          conv.chat_history = data.chat_history || [];
          conv.patient_name = data.patient_name || conv.patient_name;
        }
        persistTenantStore();
      }
    } catch (err) {
      console.warn('[Supabase] Conversation history query notice:', err);
    }
  }

  return conv || null;
}

/**
 * Clear conversation history for phone (Start fresh chat)
 */
export async function clearConversationHistory(
  clinicId: string,
  phoneNumber: string
): Promise<boolean> {
  const normalizedPhone = (phoneNumber || '+962791234567').trim();
  const conv = tenantStore.conversations.find(
    (c) => c.clinic_id === clinicId && c.phone_number === normalizedPhone
  );

  if (conv) {
    conv.chat_history = [];
    conv.updated_at = new Date().toISOString();
  }

  persistTenantStore();

  try {
    if (conv) {
      await supabase
        .from('conversations')
        .update({ chat_history: [], updated_at: new Date().toISOString() })
        .eq('id', conv.id);
    }
  } catch (err) {
    console.warn('[Supabase] Clear conversation notice:', err);
  }

  return true;
}

