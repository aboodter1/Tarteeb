'use client';

import React, { useState, useEffect, useRef } from 'react';
import {
  Send,
  Mic,
  Bot,
  User,
  Shield,
  FileCode,
  Calendar,
  Crosshair,
  Bell,
  RefreshCw,
  AlertTriangle,
  CheckCircle2,
  ExternalLink,
  QrCode,
  Sparkles,
  RotateCcw,
} from 'lucide-react';
import { CLINIC_CONFIG, CLINICAL_SERVICES } from '@/lib/config/constants';
import { InvoiceViewer } from '@/components/invoice-viewer';
import { supabaseBrowser } from '@/lib/db/supabase-browser';

interface ChatMessage {
  id: string;
  sender: 'user' | 'bot' | 'system';
  text: string;
  isVoice?: boolean;
  time: string;
  isEmergency?: boolean;
}

export default function SandboxPage() {
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: 'm1',
      sender: 'bot',
      text: 'يا هلا والله فيك في مركز نشمي لطب وجراحة الأسنان في عمان 🦷 تفضل يا غالي، كيف بقدر أساعدك بموعدك أو استفسارك اليوم؟',
      time: '10:00 ص',
    },
  ]);
  const [inputText, setInputText] = useState('');
  const [isRecording, setIsRecording] = useState(false);
  const [loading, setLoading] = useState(false);
  const [activeTab, setActiveTab] = useState<'tools' | 'database' | 'jofotara' | 'jobs'>('tools');
  const [telemetry, setTelemetry] = useState<any>({
    toolCalls: [],
    database: { appointments: [], patients: [], waitlist: [], invoices: [] },
    latestXml: '',
    latestQr: '',
    latestInvoiceMeta: null,
    jobsLog: [],
  });
  const [isMounted, setIsMounted] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    setIsMounted(true);
    fetchTelemetry();
    fetchChatHistory();
    executeJobAction('test_jofotara', { invoiceType: 'B2C_SIMPLIFIED' });

    // Supabase Realtime Subscription on appointments table
    let channel: any = null;
    try {
      channel = supabaseBrowser
        .channel('realtime-appointments-sandbox')
        .on(
          'postgres_changes',
          { event: '*', schema: 'public', table: 'appointments' },
          () => {
            fetchTelemetry();
          }
        )
        .subscribe();
    } catch (realtimeErr) {
      console.warn('[Sandbox Realtime] Subscription error, relying on poll fallback:', realtimeErr);
    }

    // Polling fallback every 3.5 seconds for instant synchrony
    const pollInterval = setInterval(() => {
      fetchTelemetry();
    }, 3500);

    return () => {
      if (channel) {
        supabaseBrowser.removeChannel(channel);
      }
      clearInterval(pollInterval);
    };
  }, []);

  const fetchChatHistory = async () => {
    try {
      const res = await fetch('/api/history?phone=+962791234567');
      const data = await res.json();
      if (data.success && Array.isArray(data.chat_history) && data.chat_history.length > 0) {
        const formatted: ChatMessage[] = data.chat_history.map((m: any, idx: number) => ({
          id: `h-${idx}-${m.timestamp || Date.now()}`,
          sender: m.role === 'user' ? 'user' : 'bot',
          text: m.text,
          time: m.timestamp
            ? new Date(m.timestamp).toLocaleTimeString('ar-JO', { hour: '2-digit', minute: '2-digit' })
            : '10:00 ص',
        }));
        setMessages(formatted);
      }
    } catch (err) {
      console.warn('[Sandbox] Failed to hydrate chat history:', err);
    }
  };

  const handleResetChat = async () => {
    try {
      await fetch('/api/history?phone=+962791234567', { method: 'DELETE' });
      setMessages([
        {
          id: `m-reset-${Date.now()}`,
          sender: 'bot',
          text: 'يا هلا والله فيك في مركز نشمي لطب وجراحة الأسنان في عمان 🦷 تفضل يا غالي، كيف بقدر أساعدك بموعدك أو استفسارك اليوم؟',
          time: new Date().toLocaleTimeString('ar-JO', { hour: '2-digit', minute: '2-digit' }),
        },
      ]);
    } catch (err) {
      console.warn('[Sandbox] Failed to reset chat history:', err);
    }
  };

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, loading]);

  const fetchTelemetry = async () => {
    try {
      const res = await fetch('/api/jobs');
      const data = await res.json();
      setTelemetry((prev: any) => ({
        ...prev,
        database: data,
      }));
    } catch (err) {
      console.warn('Failed to fetch telemetry:', err);
    }
  };

  // Safety Watchdog: Guarantee loading indicator NEVER hangs longer than 10 seconds under any circumstances
  useEffect(() => {
    if (!loading) return;
    const watchdog = setTimeout(() => {
      console.warn('[Sandbox Watchdog] Auto-clearing hung loading state');
      setLoading(false);
    }, 10000);
    return () => clearTimeout(watchdog);
  }, [loading]);

  const handleSendMessage = async (customText?: string, isVoice = false) => {
    const textToSend = customText || inputText.trim();
    if (!textToSend || loading) return;

    const userMsg: ChatMessage = {
      id: `u-${Date.now()}`,
      sender: 'user',
      text: isVoice ? `🎤 [رسالة صوتية] "${textToSend}"` : textToSend,
      isVoice,
      time: new Date().toLocaleTimeString('ar-JO', { hour: '2-digit', minute: '2-digit' }),
    };

    setMessages((prev) => [...prev, userMsg]);
    setInputText('');
    setLoading(true);

    const controller = new AbortController();
    const clientTimeout = setTimeout(() => {
      controller.abort();
    }, 14000);

    const isGreeting = /(?:السلام|سلام|مرحبا|صباح|مساء|يعطيك|هلا|أهلا|اهلا)/.test(textToSend);

    try {
      const res = await fetch('/api/clean-chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: textToSend,
          audioBase64: isVoice ? 'UklGRiQAAABXQVZFZm10IBAAAAABAAEAQB8AAEAfAAABAAgAZGF0YQAAAAA=' : undefined,
          phone: '+962791234567',
          history: messages.map((m) => ({
            role: m.sender === 'user' ? 'user' : 'model',
            text: m.text,
          })),
        }),
        signal: controller.signal,
      });

      clearTimeout(clientTimeout);

      let data: any = {};
      try {
        data = await res.json();
      } catch {
        data = {};
      }

      const nameMatch = textToSend.match(/(?:أنا|اسمي|معك|لـ|للمريض|الأخ|السيد)\s+([^\s،.]+)/);
      const detectedName = nameMatch ? nameMatch[1] : '';
      const greeting = detectedName ? `أهلاً بك يا ${detectedName}` : 'أهلاً بك يا غالي';
      const fallbackText = isGreeting
        ? 'وعليكم السلام ورحمة الله، يا هلا والله فيك في مركز نشمي لطب وجراحة الأسنان بعمان! تفضل يا غالي، كيف بقدر أساعدك بموعدك أو استفسارك اليوم؟'
        : `${greeting}، غلبتك صار خطأ بسيط بالاتصال، ممكن تعيدلي طلبك بعد إذنك؟`;

      const botMsg: ChatMessage = {
        id: `b-${Date.now()}`,
        sender: 'bot',
        text: data.reply || fallbackText,
        time: new Date().toLocaleTimeString('ar-JO', { hour: '2-digit', minute: '2-digit' }),
        isEmergency: data.isEmergency,
      };

      setMessages((prev) => [...prev, botMsg]);

      // Update telemetry
      if (data.toolCalls && data.toolCalls.length > 0) {
        setTelemetry((prev: any) => ({
          ...prev,
          toolCalls: [...data.toolCalls, ...prev.toolCalls],
        }));
      }

      await fetchTelemetry();
    } catch (err: any) {
      clearTimeout(clientTimeout);
      console.warn('[Sandbox Client Error/Timeout]:', err?.message || err);

      const nameMatch = textToSend.match(/(?:أنا|اسمي|معك|لـ|للمريض|الأخ|السيد)\s+([^\s،.]+)/);
      const detectedName = nameMatch ? nameMatch[1] : '';
      const greeting = detectedName ? `أهلاً بك يا ${detectedName}` : 'أهلاً بك يا غالي';
      const fallbackText = isGreeting
        ? 'وعليكم السلام ورحمة الله، يا هلا والله فيك في مركز نشمي لطب وجراحة الأسنان بعمان! تفضل يا غالي، كيف بقدر أساعدك بموعدك أو استفسارك اليوم؟'
        : `${greeting}، غلبتك صار خطأ بسيط بالاتصال، ممكن تعيدلي طلبك بعد إذنك؟`;

      setMessages((prev) => [
        ...prev,
        {
          id: `b-${Date.now()}`,
          sender: 'bot',
          text: fallbackText,
          time: new Date().toLocaleTimeString('ar-JO', { hour: '2-digit', minute: '2-digit' }),
        },
      ]);
    } finally {
      setLoading(false);
    }
  };

  const executeJobAction = async (action: string, payload?: any) => {
    try {
      const res = await fetch('/api/jobs', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action, payload }),
      });
      const data = await res.json();
      setTelemetry((prev: any) => ({
        ...prev,
        jobsLog: [{ action, timestamp: new Date().toISOString(), result: data.result || data.compileRes }, ...prev.jobsLog],
        latestXml: data.compileRes?.xml || prev.latestXml,
        latestQr: data.compileRes?.tlvQrCode || prev.latestQr,
        latestInvoiceMeta: data.compileRes || prev.latestInvoiceMeta,
      }));
      await fetchTelemetry();
    } catch (err) {
      console.error('Job trigger error:', err);
    }
  };

  return (
    <div dir="rtl" className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans">
      {/* Top Header */}
      <header className="px-6 py-3.5 border-b border-slate-800 bg-slate-900/90 backdrop-blur sticky top-0 z-50 flex items-center justify-between no-print">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-emerald-600 to-teal-400 flex items-center justify-center font-bold text-white shadow-md shadow-emerald-600/30">
            🦷
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="font-bold text-base md:text-lg">NashmiOps Enterprise (MVP Edition)</h1>
              <span className="text-[10px] bg-emerald-500/10 text-emerald-400 border border-emerald-500/30 px-2 py-0.5 rounded-full font-mono">
                عمان - الأردن 🇯🇴
              </span>
            </div>
            <p className="text-xs text-slate-400">
              بيئة المحاكاة التفاعلية (Dual-Pane Sandbox) | نظام تشغيل العيادات الذكي
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={fetchTelemetry}
            className="flex items-center gap-1.5 text-xs text-slate-300 hover:text-white bg-slate-800/80 px-3 py-1.5 rounded-lg border border-slate-700 transition"
          >
            <RefreshCw className="w-3.5 h-3.5" />
            <span>تحديث البيانات</span>
          </button>
        </div>
      </header>

      {/* Main Dual-Pane Container */}
      <main className="flex-1 grid grid-cols-1 lg:grid-cols-12 overflow-hidden h-[calc(100vh-65px)]">
        {/* LEFT PANE: WhatsApp Simulator (5 cols on desktop) */}
        <section className="lg:col-span-5 flex flex-col border-b lg:border-b-0 lg:border-l border-slate-800 bg-slate-950 no-print">
          {/* WhatsApp Header Simulation */}
          <div className="px-4 py-3 bg-slate-900/80 border-b border-slate-800 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="relative">
                <div className="w-10 h-10 rounded-full bg-emerald-700 flex items-center justify-center text-white font-bold text-sm">
                  نشمي
                </div>
                <span className="absolute bottom-0 left-0 w-3 h-3 bg-emerald-500 border-2 border-slate-900 rounded-full"></span>
              </div>
              <div>
                <div className="flex items-center gap-1.5">
                  <h2 className="text-sm font-semibold text-white">{CLINIC_CONFIG.name}</h2>
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                </div>
                <p className="text-[11px] text-slate-400">متصل الآن عبر واتساب الأعمال • عمان</p>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={handleResetChat}
                title="بدء محادثة جديدة ومسح السجل"
                className="flex items-center gap-1 text-[11px] text-slate-300 hover:text-rose-400 bg-slate-800 hover:bg-slate-700/80 px-2 py-1 rounded border border-slate-700 transition"
              >
                <RotateCcw className="w-3 h-3" />
                <span>محادثة جديدة</span>
              </button>
              <span className="text-[10px] text-slate-400 bg-slate-800 px-2 py-1 rounded">
                +962 7 9000 0000
              </span>
            </div>
          </div>

          {/* Quick Scenario Chips */}
          <div className="p-2.5 bg-slate-900/40 border-b border-slate-800/60 overflow-x-auto flex gap-2 text-xs">
            <button
              onClick={() => handleSendMessage('مرحبا، بدي احجز موعد كشف واستشارة بكرة بعد الظهر')}
              className="whitespace-nowrap px-2.5 py-1 rounded-full bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 transition"
            >
              🩺 حجز موعد كشف
            </button>
            <button
              onClick={() =>
                handleSendMessage('مرحبا يا دكتور، عندي نزيف مستمر في اللثة مع ورم كبير في خدي ومش قادر اتنفس كويس', false)
              }
              className="whitespace-nowrap px-2.5 py-1 rounded-full bg-red-950/40 hover:bg-red-900/50 text-red-300 border border-red-800/40 transition flex items-center gap-1"
            >
              <AlertTriangle className="w-3 h-3 text-red-400" />
              <span>🚨 اختبار طوارئ قانون 25</span>
            </button>
            <button
              onClick={() =>
                handleSendMessage('بدي احجز موعد تنظيف أسنان لابني عمره 10 سنوات واسمه كرم التميمي', false)
              }
              className="whitespace-nowrap px-2.5 py-1 rounded-full bg-blue-950/40 hover:bg-blue-900/50 text-blue-300 border border-blue-800/40 transition"
            >
              👨‍👩‍👧 حجز لابني (عائلة)
            </button>
            <button
              onClick={() =>
                handleSendMessage('بدي الغي موعدي بكرة لانه عندي ظرف طارئ', false)
              }
              className="whitespace-nowrap px-2.5 py-1 rounded-full bg-amber-950/40 hover:bg-amber-900/50 text-amber-300 border border-amber-800/40 transition"
            >
              ❌ إلغاء موعد (قناص)
            </button>
            <button
              onClick={() =>
                handleSendMessage('أنا شركة استشارات، بدي فاتورة ضريبية رسمية للشركة باسم شركة الأمل ورقمها الضريبي 102938475', false)
              }
              className="whitespace-nowrap px-2.5 py-1 rounded-full bg-teal-950/40 hover:bg-teal-900/50 text-teal-300 border border-teal-800/40 transition"
            >
              📜 فاتورة JoFotara B2B
            </button>
          </div>

          {/* Messages Feed */}
          <div className="flex-1 overflow-y-auto p-4 space-y-3 bg-[radial-gradient(#1e293b_1px,transparent_1px)] [background-size:16px_16px]">
            {messages.map((msg) => {
              const isUser = msg.sender === 'user';
              return (
                <div
                  key={msg.id}
                  className={`flex items-end gap-2 ${isUser ? 'flex-row-reverse' : 'flex-row'}`}
                >
                  <div
                    className={`w-7 h-7 rounded-full flex items-center justify-center text-xs shrink-0 ${
                      isUser
                        ? 'bg-blue-600 text-white'
                        : msg.isEmergency
                        ? 'bg-red-600 text-white animate-pulse'
                        : 'bg-emerald-600 text-white'
                    }`}
                  >
                    {isUser ? <User className="w-3.5 h-3.5" /> : <Bot className="w-3.5 h-3.5" />}
                  </div>

                  <div
                    className={`max-w-[85%] rounded-2xl px-3.5 py-2.5 text-xs md:text-sm leading-relaxed shadow-sm ${
                      isUser
                        ? 'bg-emerald-700 text-white rounded-bl-none'
                        : msg.isEmergency
                        ? 'bg-red-950/80 border border-red-700 text-red-100 rounded-br-none'
                        : 'bg-slate-900 border border-slate-800 text-slate-200 rounded-br-none'
                    }`}
                  >
                    <p className="whitespace-pre-wrap">{msg.text}</p>
                    <span
                      suppressHydrationWarning={true}
                      className={`block text-[10px] mt-1 text-left opacity-60 ${
                        isUser ? 'text-emerald-200' : 'text-slate-400'
                      }`}
                    >
                      {isMounted ? msg.time : ''}
                    </span>
                  </div>
                </div>
              );
            })}

            {loading && (
              <div className="flex items-center gap-2 text-slate-400 text-xs">
                <Sparkles className="w-4 h-4 animate-spin text-emerald-400" />
                <span>نشمي يكتب الآن...</span>
              </div>
            )}
            <div ref={messagesEndRef} />
          </div>

          {/* Input Area */}
          <div className="p-3 border-t border-slate-800 bg-slate-900/90 flex items-center gap-2">
            <button
              onClick={() => handleSendMessage('يا هلا دكتور، بسجل صوتي عشان أسأل عن موعد تنظيف أسنان الأربعاء الجاي', true)}
              title="إرسال رسالة صوتية تجريبية"
              className="p-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-emerald-400 border border-slate-700 transition shrink-0"
            >
              <Mic className="w-4 h-4" />
            </button>

            <textarea
              rows={1}
              value={inputText}
              onChange={(e) => setInputText(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === 'Enter' && !e.shiftKey) {
                  e.preventDefault();
                  handleSendMessage();
                }
              }}
              placeholder="اكتب رسالة واتساب كالمريض..."
              className="flex-1 bg-slate-950 border border-slate-700 focus:border-emerald-500 rounded-xl px-3.5 py-2 text-xs md:text-sm text-slate-100 outline-none resize-none"
            />

            <button
              onClick={() => handleSendMessage()}
              disabled={!inputText.trim() || loading}
              className="p-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 disabled:opacity-40 text-white transition shrink-0"
            >
              <Send className="w-4 h-4 -rotate-90" />
            </button>
          </div>
        </section>

        {/* RIGHT PANE: Live Telemetry & Control Center (7 cols on desktop) */}
        <section className="lg:col-span-7 flex flex-col bg-slate-900/50 overflow-hidden">
          {/* Tabs Navigation */}
          <div className="flex items-center border-b border-slate-800 bg-slate-900 px-4 pt-2 no-print">
            <button
              onClick={() => setActiveTab('tools')}
              className={`flex items-center gap-1.5 px-4 py-2.5 text-xs font-semibold border-b-2 transition ${
                activeTab === 'tools'
                  ? 'border-emerald-500 text-emerald-400 bg-slate-800/40'
                  : 'border-transparent text-slate-400 hover:text-slate-200'
              }`}
            >
              <Sparkles className="w-3.5 h-3.5" />
              <span>أدوات Gemini (Tool Calls)</span>
            </button>

            <button
              onClick={() => setActiveTab('database')}
              className={`flex items-center gap-1.5 px-4 py-2.5 text-xs font-semibold border-b-2 transition ${
                activeTab === 'database'
                  ? 'border-emerald-500 text-emerald-400 bg-slate-800/40'
                  : 'border-transparent text-slate-400 hover:text-slate-200'
              }`}
            >
              <Calendar className="w-3.5 h-3.5" />
              <span>قاعدة بيانات Supabase (RLS)</span>
              {telemetry.database?.appointments?.length > 0 && (
                <span className="text-[10px] bg-emerald-500/20 text-emerald-300 px-1.5 py-0.2 rounded-full font-mono">
                  {telemetry.database.appointments.length}
                </span>
              )}
            </button>

            <button
              onClick={() => setActiveTab('jofotara')}
              className={`flex items-center gap-1.5 px-4 py-2.5 text-xs font-semibold border-b-2 transition ${
                activeTab === 'jofotara'
                  ? 'border-emerald-500 text-emerald-400 bg-slate-800/40'
                  : 'border-transparent text-slate-400 hover:text-slate-200'
              }`}
            >
              <FileCode className="w-3.5 h-3.5" />
              <span>الفوترة الوطنية JoFotara</span>
            </button>

            <button
              onClick={() => setActiveTab('jobs')}
              className={`flex items-center gap-1.5 px-4 py-2.5 text-xs font-semibold border-b-2 transition ${
                activeTab === 'jobs'
                  ? 'border-emerald-500 text-emerald-400 bg-slate-800/40'
                  : 'border-transparent text-slate-400 hover:text-slate-200'
              }`}
            >
              <Crosshair className="w-3.5 h-3.5" />
              <span>المهام الذكية (Waitlist & Recovery)</span>
            </button>
          </div>

          {/* Tab Content Display */}
          <div className="flex-1 overflow-y-auto p-4 md:p-6 space-y-4">
            {/* TAB 1: Gemini Tool Calls */}
            {activeTab === 'tools' && (
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <h3 className="text-sm font-bold text-slate-200 flex items-center gap-2">
                    <Sparkles className="w-4 h-4 text-emerald-400" />
                    <span>سجل استدعاء أدوات الذكاء الاصطناعي (Function Declarations)</span>
                  </h3>
                  <span className="text-[11px] text-slate-400">
                    النموذج: gemini-3.5-flash / gemini-2.5-flash
                  </span>
                </div>

                {telemetry.toolCalls.length === 0 ? (
                  <div className="bg-slate-900 border border-slate-800 rounded-xl p-6 text-center text-slate-400 text-xs">
                    لم يتم تنفيذ أي استدعاء أدوات حتى الآن. جرب إرسال رسالة حجز أو إلغاء في لوحة المحادثة على اليمين!
                  </div>
                ) : (
                  telemetry.toolCalls.map((call: any, idx: number) => (
                    <div
                      key={idx}
                      className="bg-slate-900/90 border border-slate-800 rounded-xl p-4 space-y-2 text-xs font-mono"
                    >
                      <div className="flex items-center justify-between text-emerald-400 font-semibold border-b border-slate-800 pb-2">
                        <span>Tool: {call.name}()</span>
                        <span className="text-[10px] text-slate-400 bg-slate-800 px-2 py-0.5 rounded">
                          Success
                        </span>
                      </div>
                      <div>
                        <span className="text-slate-400 block mb-1">Arguments:</span>
                        <pre className="bg-slate-950 p-2.5 rounded-lg text-slate-300 overflow-x-auto">
                          {JSON.stringify(call.args, null, 2)}
                        </pre>
                      </div>
                      <div>
                        <span className="text-slate-400 block mb-1">Execution Result:</span>
                        <pre className="bg-slate-950 p-2.5 rounded-lg text-emerald-300 overflow-x-auto">
                          {JSON.stringify(call.result, null, 2)}
                        </pre>
                      </div>
                    </div>
                  ))
                )}
              </div>
            )}

            {/* TAB 2: Supabase Multi-Tenant RLS */}
            {activeTab === 'database' && (
              <div className="space-y-6">
                {/* Appointments Section */}
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <h4 className="text-xs font-bold text-slate-200 flex items-center gap-1.5">
                      <Calendar className="w-3.5 h-3.5 text-emerald-400" />
                      <span>جدول المواعيد (appointments) - شاملاً فترة التعقيم الإلزامية 15 دقيقة</span>
                    </h4>
                    <span className="text-[10px] text-slate-400 font-mono">
                      Clinic ID: {CLINIC_CONFIG.id}
                    </span>
                  </div>

                  <div className="bg-slate-900 border border-slate-800 rounded-xl overflow-x-auto">
                    <table className="w-full text-right text-xs">
                      <thead className="bg-slate-950/80 text-slate-400 border-b border-slate-800">
                        <tr>
                          <th className="p-2.5">المريض</th>
                          <th className="p-2.5">الخدمة</th>
                          <th className="p-2.5">وقت البدء</th>
                          <th className="p-2.5">نهاية التعقيم</th>
                          <th className="p-2.5">الحالة</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-800 text-slate-300">
                        {telemetry.database.appointments.map((appt: any) => (
                          <tr key={appt.id} className="hover:bg-slate-800/40">
                            <td className="p-2.5 font-medium text-white">{appt.patient_name}</td>
                            <td className="p-2.5 text-slate-400">{appt.service_type}</td>
                            <td className="p-2.5 font-mono text-[11px]">
                              {new Date(appt.start_time).toLocaleString('ar-JO')}
                            </td>
                            <td className="p-2.5 font-mono text-[11px] text-amber-400">
                              {new Date(appt.sterilization_end_time || appt.end_time).toLocaleTimeString(
                                'ar-JO'
                              )}
                            </td>
                            <td className="p-2.5">
                              <span
                                className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                                  appt.status === 'CONFIRMED'
                                    ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/30'
                                    : appt.status === 'CANCELLED'
                                    ? 'bg-red-500/10 text-red-400 border border-red-500/30'
                                    : 'bg-amber-500/10 text-amber-400 border border-amber-500/30'
                                }`}
                              >
                                {appt.status}
                              </span>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>

                {/* Waitlist Section */}
                <div className="space-y-3">
                  <h4 className="text-xs font-bold text-slate-200 flex items-center gap-1.5">
                    <Crosshair className="w-3.5 h-3.5 text-teal-400" />
                    <span>قائمة الانتظار الذكية (waitlist)</span>
                  </h4>

                  <div className="bg-slate-900 border border-slate-800 rounded-xl overflow-x-auto">
                    <table className="w-full text-right text-xs">
                      <thead className="bg-slate-950/80 text-slate-400 border-b border-slate-800">
                        <tr>
                          <th className="p-2.5">المريض</th>
                          <th className="p-2.5">الهاتف</th>
                          <th className="p-2.5">الخدمة</th>
                          <th className="p-2.5">التاريخ المفضل</th>
                          <th className="p-2.5">الحالة</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-800 text-slate-300">
                        {telemetry.database.waitlist.map((wait: any) => (
                          <tr key={wait.id}>
                            <td className="p-2.5 text-white">{wait.patient_name}</td>
                            <td className="p-2.5 font-mono">{wait.patient_phone}</td>
                            <td className="p-2.5">{wait.requested_service}</td>
                            <td className="p-2.5 font-mono">{wait.preferred_date}</td>
                            <td className="p-2.5">
                              <span className="px-2 py-0.5 rounded-full text-[10px] bg-teal-500/10 text-teal-300 border border-teal-500/30">
                                {wait.status}
                              </span>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            )}

            {/* TAB 3: JoFotara Phase 2 UBL 2.1 */}
            {activeTab === 'jofotara' && (
              <div className="space-y-4">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-slate-900 border border-slate-800 p-4 rounded-xl no-print">
                  <div>
                    <h3 className="text-sm font-bold text-slate-200">
                      محرك الفوترة الإلكترونية الوطنية JoFotara (Phase 2)
                    </h3>
                    <p className="text-xs text-slate-400">
                      معاينة بصرية كاملة للفاتورة مع طباعة رسمية وتوليد XML مطابق لمعيار UBL 2.1 ورمز TLV QR
                    </p>
                  </div>

                  <div className="flex gap-2">
                    <button
                      onClick={() => executeJobAction('test_jofotara', { invoiceType: 'B2C_SIMPLIFIED' })}
                      className="px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold shadow-sm transition active:scale-95"
                    >
                      توليد B2C مبسطة
                    </button>
                    <button
                      onClick={() =>
                        executeJobAction('test_jofotara', {
                          invoiceType: 'B2B_STANDARD',
                          buyerName: 'شركة النماء الطبية',
                          buyerTaxId: '109283746',
                        })
                      }
                      className="px-3 py-1.5 rounded-lg bg-teal-600 hover:bg-teal-500 text-white text-xs font-semibold shadow-sm transition active:scale-95"
                    >
                      توليد B2B معتمدة
                    </button>
                  </div>
                </div>

                {telemetry.latestXml ? (
                  <InvoiceViewer
                    xml={telemetry.latestXml}
                    metadata={telemetry.latestInvoiceMeta}
                  />
                ) : (
                  <div className="bg-slate-900 border border-slate-800 rounded-xl p-8 text-center text-slate-400 text-xs no-print">
                    اضغط على &quot;توليد B2C مبسطة&quot; أو &quot;توليد B2B معتمدة&quot; لمعاينة الفاتورة أو كود الـ XML الناتج فوراً!
                  </div>
                )}
              </div>
            )}

            {/* TAB 4: Autonomous Background Jobs */}
            {activeTab === 'jobs' && (
              <div className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                  <div className="bg-slate-900 border border-slate-800 p-4 rounded-xl space-y-2">
                    <div className="flex items-center justify-between">
                      <h4 className="font-bold text-xs text-white">Waitlist Sniper</h4>
                      <Crosshair className="w-4 h-4 text-emerald-400" />
                    </div>
                    <p className="text-[11px] text-slate-400 leading-relaxed">
                      عند إلغاء موعد، يقنص أقرب مريض في قائمة الانتظار ويرسل له قالب واتساب فوري لملء الشاغر.
                    </p>
                    <button
                      onClick={() => executeJobAction('trigger_waitlist_sniper')}
                      className="w-full mt-2 bg-emerald-600/20 hover:bg-emerald-600/30 text-emerald-300 border border-emerald-500/30 text-xs font-semibold py-1.5 rounded-lg transition"
                    >
                      تشغيل القناص فوراً
                    </button>
                  </div>

                  <div className="bg-slate-900 border border-slate-800 p-4 rounded-xl space-y-2">
                    <div className="flex items-center justify-between">
                      <h4 className="font-bold text-xs text-white">No-Show Recovery</h4>
                      <RefreshCw className="w-4 h-4 text-amber-400" />
                    </div>
                    <p className="text-[11px] text-slate-400 leading-relaxed">
                      يرصد المواعيد الفائتة ويرسل رسالة إعادة تفعيل لطيفة بعد ساعة لإعادة جدولة الموعد مجاناً.
                    </p>
                    <button
                      onClick={() => executeJobAction('trigger_no_show_recovery')}
                      className="w-full mt-2 bg-amber-600/20 hover:bg-amber-600/30 text-amber-300 border border-amber-500/30 text-xs font-semibold py-1.5 rounded-lg transition"
                    >
                      معالجة الغائبين (No-Show)
                    </button>
                  </div>

                  <div className="bg-slate-900 border border-slate-800 p-4 rounded-xl space-y-2">
                    <div className="flex items-center justify-between">
                      <h4 className="font-bold text-xs text-white">Smart Reminders</h4>
                      <Bell className="w-4 h-4 text-blue-400" />
                    </div>
                    <p className="text-[11px] text-slate-400 leading-relaxed">
                      يرسل تذكير قبل 24 ساعة، وتذكير قبل ساعتين يتضمن رابط خرائط جوجل المباشر لعيادة الدوار السابع.
                    </p>
                    <button
                      onClick={() => executeJobAction('trigger_smart_reminders')}
                      className="w-full mt-2 bg-blue-600/20 hover:bg-blue-600/30 text-blue-300 border border-blue-500/30 text-xs font-semibold py-1.5 rounded-lg transition"
                    >
                      فحص التذكيرات الذكية
                    </button>
                  </div>
                </div>

                {/* Job Execution Logs */}
                <div className="space-y-2">
                  <h4 className="text-xs font-bold text-slate-300">سجل تشغيل المهام بالخلفية:</h4>
                  {telemetry.jobsLog.length === 0 ? (
                    <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 text-center text-slate-400 text-xs">
                      اضغط على أحد أزرار تشغيل المهام بالأعلى لمعاينة نتيجته المباشرة هنا!
                    </div>
                  ) : (
                    telemetry.jobsLog.map((log: any, idx: number) => (
                      <div
                        key={idx}
                        className="bg-slate-950 border border-slate-800 p-3 rounded-xl text-xs font-mono space-y-1.5"
                      >
                        <div className="flex items-center justify-between text-slate-400 text-[11px]">
                          <span className="text-emerald-400 font-bold">{log.action}</span>
                          <span>{new Date(log.timestamp).toLocaleTimeString('ar-JO')}</span>
                        </div>
                        <pre className="text-slate-300 overflow-x-auto text-[11px]">
                          {JSON.stringify(log.result, null, 2)}
                        </pre>
                      </div>
                    ))
                  )}
                </div>
              </div>
            )}
          </div>
        </section>
      </main>
    </div>
  );
}
